package com.sitetime.app

import android.content.Context
import androidx.core.content.edit
import java.time.ZoneId

/** Earliest time of day (minutes) a new stop can be logged, and when "Done for today" ends. */
const val DAY_START_MIN = 4 * 60

fun nextMorning(now: Long): Long {
    val zone = ZoneId.systemDefault()
    return now.toLocalDate().plusDays(1).atTime(DAY_START_MIN / 60, 0).atZone(zone).toInstant().toEpochMilli()
}

/**
 * Turns a stream of location fixes into "stays": periods where you stayed within
 * [Prefs.radiusM] of one spot for at least [Prefs.minStayMin] minutes.
 *
 * State is saved to SharedPreferences after every fix, so a stay survives the
 * service being restarted by the system.
 */
class StayDetector(ctx: Context) {
    private val app = ctx.applicationContext
    private val p = app.getSharedPreferences("detector", Context.MODE_PRIVATE)
    private val db = Db.get(app)

    private var hasCand = p.getBoolean("hasCand", false)
    private var aLat = Double.fromBits(p.getLong("aLat", 0L))
    private var aLng = Double.fromBits(p.getLong("aLng", 0L))
    private var n = p.getInt("n", 0)
    private var first = p.getLong("first", 0L)
    private var last = p.getLong("last", 0L)
    private var away = p.getInt("away", 0)
    private var suppressed = p.getBoolean("suppressed", false)
    // Whether the current place has counted as a real stop, and whether it's an ignored/off-hours place.
    private var reached = p.getBoolean("reached", false)
    private var ignoredHere = p.getBoolean("ignoredHere", false)
    // Where and when you last left a real stop: the start of a possible drive.
    private var depTime = p.getLong("depTime", 0L)
    private var depIgnored = p.getBoolean("depIgnored", true)
    private var depLabel = p.getString("depLabel", "") ?: ""
    // Name of the place you're stopped at (also for ignored places, e.g. "Home").
    private var placeName = p.getString("placeName", "") ?: ""
    var activeId = p.getLong("activeId", -1L)
        private set

    companion object {
        private const val MAX_ACCURACY_M = 250f          // ignore fixes worse than this
        private const val MAX_GAP_MS = 60 * 60_000L      // no fixes for an hour = start fresh
        private const val JUMP_M = 1000f                 // one fix this far away ends a stay at once
    }

    fun onLocation(lat: Double, lng: Double, accuracy: Float, time: Long) {
        if (time < Prefs.pausedUntil(app)) {
            // "Done for today": ignore everything until tomorrow morning.
            if (hasCand || activeId >= 0) finish()
            save()
            return
        }
        if (accuracy > MAX_ACCURACY_M) return
        val minStayMs = Prefs.minStayMin(app) * 60_000L
        val radius = Prefs.radiusM(app).toFloat()

        if (!hasCand) {
            startCandidate(lat, lng, time)
        } else if (time - last > MAX_GAP_MS) {
            finish()
            startCandidate(lat, lng, time)
        } else {
            val d = distanceM(aLat, aLng, lat, lng)
            if (d <= radius) {
                away = 0
                // Drift the centre point towards the average of fixes for a steadier location.
                n = minOf(n + 1, 20)
                aLat += (lat - aLat) / n
                aLng += (lng - aLng) / n
                last = time
                if (activeId >= 0) {
                    val cur = db.entry(activeId)
                    if (cur == null || !cur.ongoing) {
                        // You deleted this stop or set its end time yourself: leave it alone.
                        activeId = -1
                        suppressed = true
                    } else {
                        db.setEntryEnd(activeId, last, ongoing = true)
                    }
                } else if (!suppressed && last - first >= minStayMs) {
                    val site = db.findSiteFor(aLat, aLng)
                    reached = true
                    ignoredHere = site?.ignored == true || !inWorkWindow(first)
                    placeName = site?.name ?: UNNAMED
                    checkDrive(arrive = first, here = site?.name ?: UNNAMED, site = site)
                    if (ignoredHere) {
                        suppressed = true
                    } else {
                        activeId = db.insertEntry(
                            Entry(
                                id = 0, siteId = site?.id, label = site?.name ?: UNNAMED,
                                lat = aLat, lng = aLng, start = first, end = last,
                                ongoing = true, note = "",
                                category = site?.category ?: Prefs.defaultCategory(app),
                            )
                        )
                    }
                }
            } else {
                away++
                // Need two fixes in a row outside the radius (or one big jump) so a
                // single bad reading doesn't end the stay.
                if (away >= 2 || d > JUMP_M) {
                    finish()
                    startCandidate(lat, lng, time)
                }
            }
        }
        save()
    }

    /**
     * You just arrived somewhere and stayed. Decide whether the drive here counts:
     *  - between two work places: recorded, and you're asked Parts run / Travel;
     *  - from home/church/etc. (the morning commute): not counted, and your workday starts now,
     *    unless you tapped "Start work" before leaving, or this place is set to count the morning drive.
     */
    private fun checkDrive(arrive: Long, here: String, site: Site?) {
        val depart = depTime
        depTime = 0L
        val today = arrive.toLocalDate().toString()
        val started = Prefs.workDay(app) == today
        val arrivedAlready = Prefs.arrivedDay(app) == today
        if (depart > 0 && !ignoredHere && Drives.inRange(depart, arrive)) {
            val from = depLabel.ifBlank { "last stop" }
            if (!depIgnored) {
                val id = db.addDrive(depart, arrive, from, here)
                if (Prefs.askDrives(app)) Drives.ask(app, id, depart, arrive, from, here)
            } else if (!arrivedAlready) {
                val manual = started && Prefs.workStartManual(app)
                val siteRule = !started && site?.morningTravel == true
                if (manual || siteRule) {
                    val s = if (manual) maxOf(depart, Prefs.workStartMs(app)) else depart
                    if (arrive - s >= 60_000L) {
                        val id = db.addDrive(s, arrive, from, here)
                        Drives.log(app, id, Drives.TRAVEL)
                    }
                }
            }
        }
        if (!ignoredHere) {
            if (!arrivedAlready) Prefs.setArrivedDay(app, today)
            if (!started) Prefs.setWorkStart(app, today, arrive, manual = false)
        }
    }

    /** "Start work": your workday starts now, so the drive to your first job counts as travel. */
    fun startWork(now: Long) {
        Prefs.setPausedUntil(app, 0L)
        Prefs.setWorkStart(app, now.toLocalDate().toString(), now, manual = true)
        db.touch()
    }

    /** New places are only logged between 4:00 AM and the cutoff time. */
    private fun inWorkWindow(ms: Long): Boolean {
        val z = ms.toZoned()
        val m = z.hour * 60 + z.minute
        return m >= DAY_START_MIN && (!Prefs.cutoffOn(app) || m < Prefs.cutoffMin(app))
    }

    /**
     * "Done for today": ends the current stop right now (if you're still there) and stops
     * logging anything until tomorrow morning, so the drive home and evening stops never count.
     */
    fun endDay(now: Long) {
        // If you've already started driving away, end at the last moment you were still there.
        val endAt = if (away > 0) last else maxOf(last, now)
        if (activeId >= 0) db.setEntryEnd(activeId, endAt, ongoing = false)
        activeId = -1
        hasCand = false
        suppressed = false
        reached = false
        ignoredHere = false
        depTime = 0L
        away = 0
        Prefs.setPausedUntil(app, nextMorning(now))
        save()
        db.touch()
    }

    fun resume() {
        Prefs.setPausedUntil(app, 0L)
        db.touch()
    }

    /** Close the current stay, e.g. when tracking is switched off. */
    fun stop() {
        finish()
        save()
    }

    fun status(): String = when {
        System.currentTimeMillis() < Prefs.pausedUntil(app) -> "Done for today. Resumes at 4:00 AM."
        activeId >= 0 -> db.entry(activeId)?.let { "At ${it.label} since ${fmtTime(it.start)}" }
            ?: "At a place you removed"
        hasCand && suppressed -> "At an ignored place"
        hasCand && last - first >= 60_000L ->
            "Stopped since ${fmtTime(first)} — logs after ${Prefs.minStayMin(app)} min"
        hasCand -> "On the move"
        else -> "Waiting for location…"
    }

    private fun startCandidate(lat: Double, lng: Double, time: Long) {
        hasCand = true
        aLat = lat
        aLng = lng
        n = 1
        first = time
        last = time
        away = 0
        suppressed = false
        reached = false
        ignoredHere = false
        activeId = -1
    }

    private fun finish() {
        if (reached) {
            // Leaving a real stop: remember it as the start of a possible drive.
            depTime = last
            depIgnored = ignoredHere
            depLabel = (if (activeId >= 0) db.entry(activeId)?.label else null) ?: placeName
        }
        reached = false
        ignoredHere = false
        if (activeId >= 0) db.setEntryEnd(activeId, last, ongoing = false)
        activeId = -1
        hasCand = false
        suppressed = false
        away = 0
    }

    private fun save() = p.edit {
        putBoolean("hasCand", hasCand)
        putLong("aLat", aLat.toRawBits())
        putLong("aLng", aLng.toRawBits())
        putInt("n", n)
        putLong("first", first)
        putLong("last", last)
        putInt("away", away)
        putBoolean("suppressed", suppressed)
        putLong("activeId", activeId)
        putBoolean("reached", reached)
        putBoolean("ignoredHere", ignoredHere)
        putLong("depTime", depTime)
        putBoolean("depIgnored", depIgnored)
        putString("depLabel", depLabel)
        putString("placeName", placeName)
    }
}
