package com.sitetime.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import org.json.JSONObject
import java.io.File
import java.util.zip.ZipInputStream

/** Where the signature picture goes, in the form's own (unscaled) points. */
class SigPos(val col0: Int, val colOffPt: Float, val row0: Int, val rowOffPt: Float, val wPt: Float, val hPt: Float)

/**
 * Draws the timesheet form as a PDF straight from the Excel template's own geometry
 * (form_layout.json is extracted from timesheet_template.xlsx), so the PDF lines up
 * with the spreadsheet: same column widths, row heights, borders, slanted headers and logo.
 */
object FormPdf {
    private const val COLS = "ABCDEFGHIJKLMNOPQRSTUVW"
    private const val PAGE_W = 792f // US Letter, landscape, in points
    private const val PAGE_H = 612f

    private class FCell(
        val text: String?, val bd: Map<Char, Float>, val font: String, val size: Float,
        val bold: Boolean, val italic: Boolean, val h: String?, val v: String?, val rot: Int, val wrap: Boolean,
    )

    private class Layout(
        val cols: FloatArray, val rows: Map<Int, Float>, val cells: Map<Int, FCell>,
        val merges: List<IntArray>, val logo: LongArray, val mLeft: Float, val mTop: Float, val mRight: Float,
        val pages: List<IntArray>,
    ) {
        fun rowH(r: Int) = rows[r] ?: 15f
    }

    private var cached: Layout? = null

    private fun layout(ctx: Context): Layout = cached ?: run {
        val o = JSONObject(ctx.assets.open("form_layout.json").bufferedReader().readText())
        val ca = o.getJSONArray("cols")
        val cols = FloatArray(ca.length()) { ca.getDouble(it).toFloat() }
        val ro = o.getJSONObject("rows")
        val rows = HashMap<Int, Float>()
        ro.keys().forEach { k -> rows[k.toInt()] = ro.getDouble(k).toFloat() }
        val cells = HashMap<Int, FCell>()
        val arr = o.getJSONArray("cells")
        for (i in 0 until arr.length()) {
            val e = arr.getJSONObject(i)
            val bd = HashMap<Char, Float>()
            e.optJSONObject("bd")?.let { b -> b.keys().forEach { k -> bd[k[0]] = b.getDouble(k).toFloat() } }
            val f = e.getJSONArray("f")
            cells[e.getInt("r") * 100 + e.getInt("c")] = FCell(
                text = if (e.has("t")) e.getString("t") else null,
                bd = bd, font = f.getString(0), size = f.getDouble(1).toFloat(),
                bold = f.getBoolean(2), italic = f.getBoolean(3),
                h = if (e.has("h")) e.getString("h") else null,
                v = if (e.has("v")) e.getString("v") else null,
                rot = e.optInt("rot", 0), wrap = e.optBoolean("wrap", false),
            )
        }
        val ma = o.getJSONArray("merges")
        val merges = (0 until ma.length()).map { i -> ma.getJSONArray(i).let { m -> IntArray(4) { m.getInt(it) } } }
        val la = o.getJSONArray("logo")
        val logo = LongArray(6) { la.getLong(it) }
        val mg = o.getJSONObject("margins")
        val pa = o.getJSONArray("pages")
        val pages = (0 until pa.length()).map { i -> pa.getJSONArray(i).let { p -> intArrayOf(p.getInt(0), p.getInt(1)) } }
        Layout(
            cols, rows, cells, merges, logo,
            mg.getDouble("left").toFloat(), mg.getDouble("top").toFloat(), mg.getDouble("right").toFloat(), pages,
        ).also { cached = it }
    }

    /** Signature: centred over the SIGN HERE line (P..W), sitting just on the line at the bottom of row 65. */
    fun signaturePosition(ctx: Context, bmpW: Int, bmpH: Int): SigPos {
        val l = layout(ctx)
        var hPt = 34f
        var wPt = hPt * bmpW / bmpH
        if (wPt > 288f) {
            hPt = hPt * 288f / wPt
            wPt = 288f
        }
        val spanStart = (0 until 15).sumOf { l.cols[it].toDouble() }.toFloat()
        val spanW = (15 until 23).sumOf { l.cols[it].toDouble() }.toFloat()
        val x = spanStart + (spanW - wPt) / 2f
        var c = 0
        var acc = 0f
        while (c < 22 && acc + l.cols[c] <= x) { acc += l.cols[c]; c++ }
        val colOff = x - acc
        val yTop = (1..65).sumOf { l.rowH(it).toDouble() }.toFloat() + 2f - hPt
        var r = 1
        var accY = 0f
        while (accY + l.rowH(r) <= yTop) { accY += l.rowH(r); r++ }
        return SigPos(c, colOff, r - 1, yTop - accY, wPt, hPt)
    }

    private fun templateLogo(ctx: Context): Bitmap? = try {
        ZipInputStream(ctx.assets.open("timesheet_template.xlsx")).use { zin ->
            var bmp: Bitmap? = null
            while (true) {
                val e = zin.nextEntry ?: break
                if (e.name == "xl/media/image1.jpg") {
                    bmp = BitmapFactory.decodeStream(zin)
                    break
                }
            }
            bmp
        }
    } catch (_: Exception) {
        null
    }

    /**
     * @param values cell reference -> (text to show, is it a number). Numbers right-align like Excel's General format.
     */
    fun render(
        ctx: Context, file: File, values: Map<String, Pair<String, Boolean>>, hidden: Set<Int>,
        showWeekend: Boolean, signature: Bitmap?, sigPos: SigPos?,
    ) {
        val l = layout(ctx)
        val s = (PAGE_W - l.mLeft - l.mRight) / l.cols.sum()
        val colX = FloatArray(24)
        colX[0] = l.mLeft
        for (i in 0 until 23) colX[i + 1] = colX[i] + l.cols[i] * s

        fun mergeOf(r: Int, c: Int) = l.merges.firstOrNull { r in it[0]..it[2] && c in it[1]..it[3] }

        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK }
        val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.SQUARE
        }
        val logo = templateLogo(ctx)
        val doc = PdfDocument()
        var pageNo = 1
        for (pg in l.pages) {
            val a = pg[0]
            val b = pg[1]
            if (a >= 78 && !showWeekend) continue
            val page = doc.startPage(PdfDocument.PageInfo.Builder(PAGE_W.toInt(), PAGE_H.toInt(), pageNo++).create())
            val cv: Canvas = page.canvas
            val rowY = HashMap<Int, Float>()
            var y = l.mTop
            for (r in a..b) {
                rowY[r] = y
                if (r !in hidden) y += l.rowH(r) * s
            }
            rowY[b + 1] = y
            val pageBottom = y

            // ---- text ----
            for (r in a..b) {
                if (r in hidden) continue
                for (c in 1..23) {
                    val e = l.cells[r * 100 + c]
                    val v = values["${COLS[c - 1]}$r"]
                    val txt = v?.first ?: e?.text ?: continue
                    if (txt.isBlank()) continue
                    val m = mergeOf(r, c)
                    if (m != null && (m[0] != r || m[1] != c)) continue
                    val calibri = e?.font?.contains("Calibri") == true
                    val size = e?.size ?: 10f
                    textPaint.typeface = Typeface.create(
                        Typeface.SANS_SERIF,
                        when {
                            e?.bold == true && e.italic -> Typeface.BOLD_ITALIC
                            e?.bold == true -> Typeface.BOLD
                            e?.italic == true -> Typeface.ITALIC
                            else -> Typeface.NORMAL
                        },
                    )
                    textPaint.textSize = size * s * (if (calibri) 0.9f else 1f)
                    val x0: Float
                    val y0: Float
                    val x1: Float
                    val y1: Float
                    if (m != null) {
                        x0 = colX[m[1] - 1]; y0 = rowY[m[0]] ?: continue
                        x1 = colX[m[3]]; y1 = rowY[m[2] + 1] ?: pageBottom
                    } else {
                        x0 = colX[c - 1]; y0 = rowY[r] ?: continue
                        x1 = colX[c]; y1 = rowY[r + 1] ?: pageBottom
                    }
                    val rot = e?.rot ?: 0
                    if (rot != 0) {
                        // Slanted header labels: run up-right from the bottom of the cell, like Excel.
                        val avail = (y1 - y0) / 0.866f + 10f * s
                        val lines = if (e?.wrap == true) wrapWords(txt, textPaint, avail) else listOf(txt)
                        val lh = size * s * 1.15f
                        val asc = -textPaint.fontMetrics.ascent
                        lines.forEachIndexed { i, ln ->
                            val off = (i - (lines.size - 1) / 2f) * lh
                            val thh = textPaint.textSize * 1.3f
                            val ax = (x0 + x1) / 2f - 0.25f * lh + off * 0.866f - 3f * s
                            cv.save()
                            cv.translate(ax + thh * 0.866f, y1 - 2f * s)
                            cv.rotate(-rot.toFloat())
                            cv.drawText(ln, 1f, asc - thh, textPaint)
                            cv.restore()
                        }
                        continue
                    }
                    val tw = textPaint.measureText(txt)
                    val hz = e?.h ?: if (v?.second == true) "right" else "left"
                    val pad = 2f * s
                    val tx = when (hz) {
                        "center", "centerContinuous" -> (x0 + x1) / 2f - tw / 2f
                        "right" -> x1 - pad - tw
                        else -> x0 + pad
                    }
                    val fm = textPaint.fontMetrics
                    val asc = -fm.ascent
                    val desc = fm.descent
                    val baseline = when (e?.v) {
                        "center" -> (y0 + y1) / 2f + (asc - desc) / 2f
                        "top" -> y0 + s + asc
                        else -> y1 - s - desc * 0.7f
                    }
                    cv.drawText(txt, tx, baseline, textPaint)
                }
            }

            // ---- borders ----
            for (r in a..b) {
                if (r in hidden) continue
                for (c in 1..23) {
                    val e = l.cells[r * 100 + c] ?: continue
                    if (e.bd.isEmpty()) continue
                    val m = mergeOf(r, c)
                    val x0 = colX[c - 1]
                    val x1 = colX[c]
                    val y0 = rowY[r] ?: continue
                    val y1 = rowY[r + 1] ?: pageBottom
                    // Rotated cells get slanted side borders (60° header row).
                    val dx = if (e.rot != 0) (y1 - y0) / Math.tan(Math.toRadians(e.rot.toDouble())).toFloat() else 0f
                    for ((side, w) in e.bd) {
                        if (m != null) {
                            if (side == 'l' && c != m[1]) continue
                            if (side == 'r' && c != m[3]) continue
                            if (side == 't' && r != m[0]) continue
                            if (side == 'b' && r != m[2]) continue
                        }
                        linePaint.strokeWidth = w * s
                        when (side) {
                            'l' -> cv.drawLine(x0, y1, x0 + dx, y0, linePaint)
                            'r' -> cv.drawLine(x1, y1, x1 + dx, y0, linePaint)
                            't' -> cv.drawLine(x0 + dx, y0, x1 + dx, y0, linePaint)
                            'b' -> cv.drawLine(x0, y1, x1, y1, linePaint)
                        }
                    }
                }
            }

            // ---- pictures ----
            val imgPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
            if (logo != null) {
                val lr = l.logo[2].toInt() + 1
                rowY[lr]?.let { top ->
                    val lx = colX[l.logo[0].toInt()] + l.logo[1] / 12700f * s
                    val ly = top + l.logo[3] / 12700f * s
                    cv.drawBitmap(logo, null, RectF(lx, ly, lx + l.logo[4] / 12700f * s, ly + l.logo[5] / 12700f * s), imgPaint)
                }
            }
            if (signature != null && sigPos != null) {
                rowY[sigPos.row0 + 1]?.let { top ->
                    val sx = colX[sigPos.col0] + sigPos.colOffPt * s
                    val sy = top + sigPos.rowOffPt * s
                    cv.drawBitmap(signature, null, RectF(sx, sy, sx + sigPos.wPt * s, sy + sigPos.hPt * s), imgPaint)
                }
            }
            doc.finishPage(page)
        }
        file.outputStream().use { doc.writeTo(it) }
        doc.close()
    }

    private fun wrapWords(text: String, p: Paint, avail: Float): List<String> {
        val out = mutableListOf<String>()
        var cur = ""
        for (w in text.split(" ").filter { it.isNotEmpty() }) {
            val t = if (cur.isEmpty()) w else "$cur $w"
            if (p.measureText(t) > avail && cur.isNotEmpty()) {
                out.add(cur)
                cur = w
            } else {
                cur = t
            }
        }
        if (cur.isNotEmpty()) out.add(cur)
        return out
    }
}
