package com.sitetime.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import org.json.JSONObject
import java.io.File
import java.util.zip.ZipInputStream

/** Where the signature picture goes, in the form's own (unscaled) points. */
class SigPos(val col0: Int, val colOffPt: Float, val row0: Int, val rowOffPt: Float, val wPt: Float, val hPt: Float)

/**
 * Draws the timesheet form as a PDF straight from the Excel template's own geometry
 * (form_layout.json is extracted from timesheet_template.xlsx), so the PDF lines up
 * with the spreadsheet: same column widths, row heights, borders, slanted headers and logo.
 */
object FormPdf {
    private const val COLS = "ABCDEFGHIJKLMNOPQRSTUVW"
    private const val PAGE_W = 792f // US Letter, landscape, in points
    private const val PAGE_H = 612f

    private class FCell(
        val text: String?, val bd: Map<Char, Float>, val font: String, val size: Float,
        val bold: Boolean, val italic: Boolean, val h: String?, val v: String?, val rot: Int, val wrap: Boolean,
    )

    private class Layout(
        val cols: FloatArray, val rows: Map<Int, Float>, val cells: Map<Int, FCell>,
        val merges: List<IntArray>, val logo: LongArray, val mLeft: Float, val mTop: Float, val mRight: Float,
        val pages: List<IntArray>,
    ) {
        fun rowH(r: Int) = rows[r] ?: 15f
    }

    private var cached: Layout? = null

    private fun layout(ctx: Context): Layout = cached ?: run {
        val o = JSONObject(ctx.assets.open("form_layout.json").bufferedReader().readText())
        val ca = o.getJSONArray("cols")
        val cols = FloatArray(ca.length()) { ca.getDouble(it).toFloat() }
        val ro = o.getJSONObject("rows")
        val rows = HashMap<Int, Float>()
        ro.keys().forEach { k -> rows[k.toInt()] = ro.getDouble(k).toFloat() }
        val cells = HashMap<Int, FCell>()
        val arr = o.getJSONArray("cells")
        for (i in 0 until arr.length()) {
            val e = arr.getJSONObject(i)
            val bd = HashMap<Char, Float>()
            e.optJSONObject("bd")?.let { b -> b.keys().forEach { k -> bd[k[0]] = b.getDouble(k).toFloat() } }
            val f = e.getJSONArray("f")
            cells[e.getInt("r") * 100 + e.getInt("c")] = FCell(
                text = if (e.has("t")) e.getString("t") else null,
                bd = bd, font = f.getString(0), size = f.getDouble(1).toFloat(),
                bold = f.getBoolean(2), italic = f.getBoolean(3),
                h = if (e.has("h")) e.getString("h") else null,
                v = if (e.has("v")) e.getString("v") else null,
                rot = e.optInt("rot", 0), wrap = e.optBoolean("wrap", false),
            )
        }
        val ma = o.getJSONArray("merges")
        val merges = (0 until ma.length()).map { i -> ma.getJSONArray(i).let { m -> IntArray(4) { m.getInt(it) } } }
        val la = o.getJSONArray("logo")
        val logo = LongArray(6) { la.getLong(it) }
        val mg = o.getJSONObject("margins")
        val pa = o.getJSONArray("pages")
        val pages = (0 until pa.length()).map { i -> pa.getJSONArray(i).let { p -> intArrayOf(p.getInt(0), p.getInt(1)) } }
        Layout(
            cols, rows, cells, merges, logo,
            mg.getDouble("left").toFloat(), mg.getDouble("top").toFloat(), mg.getDouble("right").toFloat(), pages,
        ).also { cached = it }
    }

    /**
     * Signature: centred on the SIGN HERE line (P..W), dipping a little below the line like a real
     * signature. Only lightly stretched, so it keeps its handwritten look.
     */
    fun signaturePosition(ctx: Context, bmpW: Int, bmpH: Int): SigPos {
        val l = layout(ctx)
        val spanStart = (0 until 15).sumOf { l.cols[it].toDouble() }.toFloat()
        val spanW = (15 until 23).sumOf { l.cols[it].toDouble() }.toFloat()
        val aspect = bmpW.toFloat() / bmpH.coerceAtLeast(1)
        // A bit larger than the drawing, stretched at most 15% so it still looks like handwriting.
        var hPt = 44f
        var wPt = hPt * aspect
        val maxW = spanW * 0.9f
        if (wPt < spanW * 0.6f) wPt = minOf(spanW * 0.6f, wPt * 1.15f)
        if (wPt > maxW) {
            hPt *= maxW / wPt
            wPt = maxW
        }
        val x = spanStart + (spanW - wPt) / 2f
        var c = 0
        var acc = 0f
        while (c < 22 && acc + l.cols[c] <= x) { acc += l.cols[c]; c++ }
        val colOff = x - acc
        val lineY = (1..65).sumOf { l.rowH(it).toDouble() }.toFloat()
        val yTop = lineY + 7f - hPt
        var r = 1
        var accY = 0f
        while (accY + l.rowH(r) <= yTop) { accY += l.rowH(r); r++ }
        return SigPos(c, colOff, r - 1, yTop - accY, wPt, hPt)
    }

    private fun templateLogo(ctx: Context): Bitmap? = try {
        ZipInputStream(ctx.assets.open("timesheet_template.xlsx")).use { zin ->
            var bmp: Bitmap? = null
            while (true) {
                val e = zin.nextEntry ?: break
                if (e.name == "xl/media/image1.jpg") {
                    bmp = BitmapFactory.decodeStream(zin)
                    break
                }
            }
            bmp
        }
    } catch (_: Exception) {
        null
    }

    /**
     * Draws the form centred on landscape Letter pages with 0.4" margins. Columns are squeezed to
     * fit the width; rows are stretched to fill the height (the slanted header row keeps its natural
     * shape so the labels stay inside it). Text keeps normal proportions.
     *
     * @param values cell reference -> (text to show, is it a number). Numbers right-align like Excel's General format.
     */
    fun render(
        ctx: Context, file: File, values: Map<String, Pair<String, Boolean>>, hidden: Set<Int>,
        showWeekend: Boolean, signature: Bitmap?, sigPos: SigPos?,
    ) {
        val l = layout(ctx)
        val m = l.mLeft
        val pages = l.pages.filter { !(it[0] >= 78 && !showWeekend) }
        val headerRows = l.cells.entries.filter { it.value.rot != 0 }.map { it.key / 100 }.toSet()

        val sx = (PAGE_W - 2 * m) / l.cols.sum()
        var sy = Float.MAX_VALUE
        for (pg in pages) {
            var hdr = 0f
            var other = 0f
            for (r in pg[0]..pg[1]) {
                if (r in hidden) continue
                if (r in headerRows) hdr += l.rowH(r) else other += l.rowH(r)
            }
            if (other > 0f) sy = minOf(sy, (PAGE_H - 2 * m - hdr * sx) / other)
        }
        if (sy == Float.MAX_VALUE || sy < sx) sy = sx
        fun rs(r: Int) = if (r in headerRows) sx else sy
        val s = sx // text scale

        val colX = FloatArray(24)
        colX[0] = (PAGE_W - l.cols.sum() * sx) / 2f
        for (i in 0 until 23) colX[i + 1] = colX[i] + l.cols[i] * sx

        fun mergeOf(r: Int, c: Int) = l.merges.firstOrNull { r in it[0]..it[2] && c in it[1]..it[3] }

        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK }
        val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.SQUARE
        }
        val imgPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
        val logo = templateLogo(ctx)
        val doc = PdfDocument()
        var pageNo = 1
        for (pg in pages) {
            val a = pg[0]
            val b = pg[1]
            val page = doc.startPage(PdfDocument.PageInfo.Builder(PAGE_W.toInt(), PAGE_H.toInt(), pageNo++).create())
            val cv: Canvas = page.canvas
            var contentH = 0f
            for (r in a..b) if (r !in hidden) contentH += l.rowH(r) * rs(r)
            val rowY = HashMap<Int, Float>()
            var y = (PAGE_H - contentH) / 2f
            for (r in a..b) {
                rowY[r] = y
                if (r !in hidden) y += l.rowH(r) * rs(r)
            }
            rowY[b + 1] = y
            val pageBottom = y

            // ---- text ----
            for (r in a..b) {
                if (r in hidden) continue
                for (c in 1..23) {
                    val e = l.cells[r * 100 + c]
                    val v = values["${COLS[c - 1]}$r"]
                    val txt = v?.first ?: e?.text ?: continue
                    if (txt.isBlank()) continue
                    val mg = mergeOf(r, c)
                    if (mg != null && (mg[0] != r || mg[1] != c)) continue
                    val calibri = e?.font?.contains("Calibri") == true
                    val size = e?.size ?: 10f
                    textPaint.typeface = Typeface.create(
                        Typeface.SANS_SERIF,
                        when {
                            e?.bold == true && e.italic -> Typeface.BOLD_ITALIC
                            e?.bold == true -> Typeface.BOLD
                            e?.italic == true -> Typeface.ITALIC
                            else -> Typeface.NORMAL
                        },
                    )
                    textPaint.textSize = size * s * (if (calibri) 0.9f else 1f)
                    val x0: Float
                    val y0: Float
                    val x1: Float
                    val y1: Float
                    if (mg != null) {
                        x0 = colX[mg[1] - 1]; y0 = rowY[mg[0]] ?: continue
                        x1 = colX[mg[3]]; y1 = rowY[mg[2] + 1] ?: pageBottom
                    } else {
                        x0 = colX[c - 1]; y0 = rowY[r] ?: continue
                        x1 = colX[c]; y1 = rowY[r + 1] ?: pageBottom
                    }
                    val rot = e?.rot ?: 0
                    if (rot != 0) {
                        // Slanted header labels: run up-right from the bottom of the cell, kept inside the header row.
                        val avail = (y1 - y0 - 8f * s) / 0.866f
                        val lines = if (e?.wrap == true) wrapWords(txt, textPaint, avail) else listOf(txt)
                        val lh = size * s * 1.15f
                        val asc = -textPaint.fontMetrics.ascent
                        cv.save()
                        cv.clipRect(0f, y0, PAGE_W, y1)
                        lines.forEachIndexed { i, ln ->
                            val off = (i - (lines.size - 1) / 2f) * lh
                            val thh = textPaint.textSize * 1.3f
                            val ax = (x0 + x1) / 2f - 0.25f * lh + off * 0.866f - 3f * s
                            val ay = (y1 - 2f * s) - (lines.size - 1) / 2f * lh * 0.5f + off * 0.5f
                            cv.save()
                            cv.translate(ax + thh * 0.866f, ay)
                            cv.rotate(-rot.toFloat())
                            cv.drawText(ln, 1f, asc - thh, textPaint)
                            cv.restore()
                        }
                        cv.restore()
                        continue
                    }
                    val pad = 2f * s
                    if (e?.wrap == true && textPaint.measureText(txt) > x1 - x0 - 2 * pad) {
                        // Long text (e.g. notes): wrap inside the box, shrinking a little if it still won't fit.
                        var lines = wrapWords(txt, textPaint, x1 - x0 - 2 * pad)
                        while (lines.size * textPaint.textSize * 1.15f > y1 - y0 - 2 * pad && textPaint.textSize > size * s * 0.55f) {
                            textPaint.textSize *= 0.9f
                            lines = wrapWords(txt, textPaint, x1 - x0 - 2 * pad)
                        }
                        val lineH = textPaint.textSize * 1.15f
                        val ascW = -textPaint.fontMetrics.ascent
                        var by = when (e.v) {
                            "top" -> y0 + pad + ascW
                            "bottom", null -> y1 - pad - textPaint.fontMetrics.descent - (lines.size - 1) * lineH
                            else -> (y0 + y1) / 2f - lines.size * lineH / 2f + ascW
                        }
                        for (ln in lines) {
                            cv.drawText(ln, x0 + pad, by, textPaint)
                            by += lineH
                        }
                        continue
                    }
                    val tw = textPaint.measureText(txt)
                    val hz = e?.h ?: if (v?.second == true) "right" else "left"
                    val tx = when (hz) {
                        "center", "centerContinuous" -> (x0 + x1) / 2f - tw / 2f
                        "right" -> x1 - pad - tw
                        else -> x0 + pad
                    }
                    val fm = textPaint.fontMetrics
                    val asc = -fm.ascent
                    val desc = fm.descent
                    val baseline = when (e?.v) {
                        "center" -> (y0 + y1) / 2f + (asc - desc) / 2f
                        "top" -> y0 + s + asc
                        else -> y1 - s - desc * 0.7f
                    }
                    cv.drawText(txt, tx, baseline, textPaint)
                }
            }

            // ---- pictures (before borders, so lines stay on top) ----
            if (logo != null) {
                val lr = l.logo[2].toInt() + 1
                rowY[lr]?.let { top ->
                    val lx = colX[l.logo[0].toInt()] + l.logo[1] / 12700f * sx
                    val ly = top + l.logo[3] / 12700f * rs(lr)
                    cv.drawBitmap(logo, null, RectF(lx, ly, lx + l.logo[4] / 12700f * sx, ly + l.logo[5] / 12700f * sx), imgPaint)
                }
            }
            if (signature != null && sigPos != null) {
                val sr = sigPos.row0 + 1
                rowY[sr]?.let { top ->
                    val sxPos = colX[sigPos.col0] + sigPos.colOffPt * sx
                    val bottom = top + (sigPos.rowOffPt + sigPos.hPt) * rs(sr)
                    val w = sigPos.wPt * sx
                    val h = sigPos.hPt * sx
                    cv.drawBitmap(signature, null, RectF(sxPos, bottom - h, sxPos + w, bottom), imgPaint)
                }
            }

            // ---- borders ----
            for (r in a..b) {
                if (r in hidden) continue
                for (c in 1..23) {
                    val e = l.cells[r * 100 + c] ?: continue
                    if (e.bd.isEmpty()) continue
                    val mg = mergeOf(r, c)
                    val x0 = colX[c - 1]
                    val x1 = colX[c]
                    val y0 = rowY[r] ?: continue
                    val y1 = rowY[r + 1] ?: pageBottom
                    // Rotated cells get slanted side borders (60° header row).
                    val dx = if (e.rot != 0) (y1 - y0) / Math.tan(Math.toRadians(e.rot.toDouble())).toFloat() else 0f
                    for ((side, w) in e.bd) {
                        if (mg != null) {
                            if (side == 'l' && c != mg[1]) continue
                            if (side == 'r' && c != mg[3]) continue
                            if (side == 't' && r != mg[0]) continue
                            if (side == 'b' && r != mg[2]) continue
                        }
                        // A floor on line weight so thin borders don't fade out on paper.
                        linePaint.strokeWidth = maxOf(0.5f, w * 0.8f)
                        when (side) {
                            'l' -> cv.drawLine(x0, y1, x0 + dx, y0, linePaint)
                            'r' -> cv.drawLine(x1, y1, x1 + dx, y0, linePaint)
                            't' -> cv.drawLine(x0 + dx, y0, x1 + dx, y0, linePaint)
                            'b' -> cv.drawLine(x0, y1, x1, y1, linePaint)
                        }
                    }
                }
            }
            doc.finishPage(page)
        }
        file.outputStream().use { doc.writeTo(it) }
        doc.close()
    }

    private fun wrapWords(text: String, p: Paint, avail: Float): List<String> {
        val out = mutableListOf<String>()
        var cur = ""
        for (w in text.split(" ").filter { it.isNotEmpty() }) {
            val t = if (cur.isEmpty()) w else "$cur $w"
            if (p.measureText(t) > avail && cur.isNotEmpty()) {
                out.add(cur)
                cur = w
            } else {
                cur = t
            }
        }
        if (cur.isNotEmpty()) out.add(cur)
        return out
    }
}
