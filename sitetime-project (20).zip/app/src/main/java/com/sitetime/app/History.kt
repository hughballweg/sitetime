package com.sitetime.app

import android.content.Context
import java.time.LocalDate
import java.time.ZoneId

/**
 * Builds timesheet entries from saved location history, for days (or hours) you forgot to track.
 * It runs the same stop/drive rules as live tracking over the saved fixes, and only fills the gaps:
 * anything already on the timesheet is kept as it is. Drives it finds wait in "Pending your review".
 */
object History {
    private val lock = Any()

    private fun range(day: LocalDate): Pair<Long, Long> {
        val zone = ZoneId.systemDefault()
        return day.atStartOfDay(zone).toInstant().toEpochMilli() to day.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli()
    }

    fun hasHistory(ctx: Context, day: LocalDate): Boolean {
        val (from, to) = range(day)
        return Db.get(ctx).hasFixes(from, to)
    }

    /**
     * Fills in a past day. Returns how many entries were added.
     * (Today goes through [TrackingService.ACTION_TRACK_DAY] so live tracking can carry on from it.)
     */
    fun fillPastDay(ctx: Context, day: LocalDate): Int = synchronized(lock) {
        val db = Db.get(ctx)
        val (from, to) = range(day)
        val before = db.entriesBetween(from, to)
        val r = StayDetector(ctx, replay = true)
        r.setExisting(before, db.drivesBetween(from, to))
        db.fixesBetween(from, to).forEach { r.onLocation(it.lat, it.lng, it.acc, it.t) }
        r.stop()
        db.touch()
        Places.nameUnnamed(ctx, from, to)
        db.entriesBetween(from, to).size - before.size
    }

    /**
     * Replays today up to now. The stop you're at right now is left open, and the returned
     * detector is handed to live tracking so it keeps going from there.
     */
    fun replayToday(ctx: Context): StayDetector = synchronized(lock) {
        val db = Db.get(ctx)
        val (from, _) = range(LocalDate.now())
        val now = System.currentTimeMillis()
        val r = StayDetector(ctx, replay = true)
        r.seedDayState()
        r.setExisting(db.entriesBetween(from, now + 1), db.drivesBetween(from, now + 1))
        db.fixesBetween(from, now + 1).forEach { r.onLocation(it.lat, it.lng, it.acc, it.t) }
        r
    }
}
