package com.sitetime.app

import android.content.Context
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate
import java.time.ZoneId

/**
 * Names unnamed stops after the business you stopped at (e.g. a hardware store), using Google's
 * Places API (New) Nearby Search with the same key as the map. Each stop is checked once; a stop
 * you've named yourself is never changed. Needs "Places API (New)" enabled for the key.
 */
object Places {
    /** SHA-1 of app/debug.keystore, sent so the Android-restricted key is accepted. */
    private const val CERT_SHA1 = "BE881E0F594628C268468A4BD65F5F4FE76877C8"
    private const val RADIUS_M = 50.0
    private const val MAX_PER_RUN = 25

    /**
     * Per-phone caps. Google's free tier is 5,000 lookups a month for the whole key; these are 1/20 of
     * a safe 150 a day / 4,500 a month, so up to 20 phones can share the key and still stay free.
     */
    const val MAX_PER_DAY = 7
    const val MAX_PER_MONTH = 225
    private val lock = Any()

    /** Results that are just roads, addresses or areas, not a business. */
    private val NOT_A_BUSINESS = setOf(
        "route", "street_address", "premise", "subpremise", "locality", "sublocality", "political",
        "neighborhood", "postal_code", "plus_code", "geocode", "intersection", "country",
        "administrative_area_level_1", "administrative_area_level_2", "administrative_area_level_3",
        "parking", "parking_lot",
    )

    /** Checks unnamed stops between [from] and [to]. Call off the main thread (it uses the network). */
    fun nameUnnamed(ctx: Context, from: Long, to: Long) {
        if (BuildConfig.MAPS_API_KEY.isBlank()) return
        synchronized(lock) {
            val db = Db.get(ctx)
            for (e in db.unnamedToLookUp(from, to).take(MAX_PER_RUN)) {
                val lat = e.lat ?: continue
                val lng = e.lng ?: continue
                if (!takeOne(ctx)) return // this phone's daily or monthly allowance is used up
                val found = try {
                    nearestBusiness(ctx, lat, lng)
                } catch (ex: Exception) {
                    // No signal, or the Places API isn't switched on yet: try again next time.
                    return
                }
                db.setLookedUp(e.id, found?.first, found?.second)
            }
        }
    }

    /** Counts one lookup against this phone's allowance; false if it's used up. Every attempt counts. */
    private fun takeOne(ctx: Context): Boolean {
        val today = LocalDate.now()
        val day = today.toString()
        val month = day.substring(0, 7)
        val dayCount = if (Prefs.placesDay(ctx) == day) Prefs.placesDayCount(ctx) else 0
        val monthCount = if (Prefs.placesMonth(ctx) == month) Prefs.placesMonthCount(ctx) else 0
        if (dayCount >= MAX_PER_DAY || monthCount >= MAX_PER_MONTH) return false
        Prefs.setPlacesCounts(ctx, day, dayCount + 1, month, monthCount + 1)
        return true
    }

    fun nameUnnamedDay(ctx: Context, day: LocalDate) {
        val zone = ZoneId.systemDefault()
        nameUnnamed(
            ctx,
            day.atStartOfDay(zone).toInstant().toEpochMilli(),
            day.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli(),
        )
    }

    /** Places where you'd stop for lunch. */
    private val FOOD = setOf(
        "restaurant", "cafe", "coffee_shop", "bakery", "meal_takeaway", "meal_delivery", "food_court", "diner",
        "deli", "bar", "pub", "bar_and_grill", "donut_shop", "bagel_shop", "ice_cream_shop", "dessert_shop",
        "juice_shop", "tea_house", "steak_house", "sandwich_shop",
    )

    private fun kindOf(types: List<String>): String? =
        if (types.any { it in FOOD || it.endsWith("_restaurant") }) "food" else null

    /** The closest business within [RADIUS_M] of the spot (name, and "food" for restaurants), or null. */
    private fun nearestBusiness(ctx: Context, lat: Double, lng: Double): Pair<String, String?>? {
        val body = JSONObject()
            .put("maxResultCount", 5)
            .put("rankPreference", "DISTANCE")
            .put(
                "locationRestriction",
                JSONObject().put(
                    "circle",
                    JSONObject()
                        .put("center", JSONObject().put("latitude", lat).put("longitude", lng))
                        .put("radius", RADIUS_M),
                ),
            )
        val conn = URL("https://places.googleapis.com/v1/places:searchNearby").openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 10_000
            conn.readTimeout = 10_000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("X-Goog-Api-Key", BuildConfig.MAPS_API_KEY)
            conn.setRequestProperty("X-Goog-FieldMask", "places.displayName,places.types")
            conn.setRequestProperty("X-Android-Package", ctx.packageName)
            conn.setRequestProperty("X-Android-Cert", CERT_SHA1)
            conn.outputStream.use { it.write(body.toString().toByteArray()) }
            if (conn.responseCode != 200) throw IOException("Places API answered ${conn.responseCode}")
            val json = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
            val places = json.optJSONArray("places") ?: return null
            for (i in 0 until places.length()) {
                val place = places.getJSONObject(i)
                val typesJson = place.optJSONArray("types")
                val types = if (typesJson == null) emptyList() else (0 until typesJson.length()).map { typesJson.getString(it) }
                if (types.isNotEmpty() && types.all { it in NOT_A_BUSINESS }) continue
                val name = place.optJSONObject("displayName")?.optString("text").orEmpty().trim()
                if (name.isNotBlank()) return name to kindOf(types)
            }
            return null
        } finally {
            conn.disconnect()
        }
    }
}
