"""Re-implementation of TravelRow / drawTravelArt for previewing card art."""
import math
from PIL import Image, ImageDraw, ImageFont

SS = 4          # supersample
PX = 3          # output px per dp
K = SS * PX     # drawing px per dp
FONT = "/usr/share/fonts/opentype/inter/Inter-{}.otf"

def f(weight, sp):
    return ImageFont.truetype(FONT.format(weight), int(sp * K))

def rgba(hex_, a=1.0):
    h = hex_.lstrip("#")
    r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    return (r, g, b, int(round(a * 255)))

def withA(c, a):
    return (c[0], c[1], c[2], int(round(a * 255)))

OLD = dict(
    light_bg={True: "D3DDF5", False: "E6ECFA"}, dark_bg={True: "26346A", False: "1E2850"},
    ink_l=0.32, ink_d=0.28, tire_l=0.55, tire_d=0.45, glow=0.18, lamp=1.0, tail=True,
)
NEW = dict(
    light_bg={True: "E9EDF8", False: "F2F4FA"}, dark_bg={True: "242B45", False: "20253A"},
    ink_l=0.22, ink_d=0.18, tire_l=0.32, tire_d=0.28, glow=0.10, lamp=0.5, tail=False,
)

def rr(d, box, r, fill=None, outline=None, width=1):
    d.rounded_rectangle(box, radius=r, fill=fill, outline=outline, width=width)

def art(d, w, h, parts, dark, ink, tire, bg, P):
    dp = K
    faint = withA(ink, ink[3] / 255 * 0.55)
    line = lambda c, a, b, sw: d.line([a, b], fill=c, width=max(1, round(sw * dp)))
    glass = [(w - 50 * dp, 20 * dp), (w - 24 * dp, 20 * dp), (w - 7 * dp, h * 0.52), (w - 50 * dp, h * 0.52)]
    d.polygon(glass, fill=withA(ink, ink[3] / 255 * 0.35))
    d.line(glass + [glass[0]], fill=faint, width=round(dp))
    floor, seam = h * 0.75, w * 0.58
    line(faint, (6 * dp, floor), (w - 6 * dp, floor), 1)
    line(faint, (seam, h * 0.3), (seam, h - 8 * dp), 1)
    line(faint, (seam + 8 * dp, h * 0.68), (seam + 16 * dp, h * 0.68), 2)
    for fx in (0.16, 0.84):
        x0, y0 = w * fx - 13 * dp, h - 16 * dp
        d.arc([x0, y0, x0 + 26 * dp, y0 + 26 * dp], 180, 360, fill=faint, width=round(dp))
    ht = h * 0.54
    rr(d, [w - 6 * dp, ht, w, ht + 16 * dp], 3 * dp, fill=rgba("F4F8FF", 0.55 if dark else 1))
    rr(d, [w - 6 * dp, ht, w, ht + 16 * dp], 3 * dp, outline=faint, width=round(dp))
    rr(d, [0, floor - 23 * dp, 5 * dp, floor - 1 * dp], 3 * dp, fill=rgba("F2A0A0", 0.45 if dark else 0.6))
    for fx in (0.16, 0.84):
        cx, cy = w * fx, h - 3 * dp
        for r, c in ((9, tire), (4, bg), (1.5, tire)):
            d.ellipse([cx - r * dp, cy - r * dp, cx + r * dp, cy + r * dp], fill=c)
    if parts:
        for fx in (0.24, 0.76):
            line(ink, (w * fx, 8 * dp), (w * fx, 14 * dp), 2.2)
        x0, x1 = w * 0.14, w * 0.86
        line(ink, (x0, 3 * dp), (x1, 3 * dp), 1.6)
        line(ink, (x0, 8 * dp), (x1, 8 * dp), 1.6)
        x = x0
        while x <= x1 + 0.5:
            line(ink, (x, 3 * dp), (x, 8 * dp), 1.2)
            x += 12 * dp
        fill = withA(ink, ink[3] / 255 * 0.18)
        def box(l, t, bw, bh):
            d.rectangle([l, t, l + bw, t + bh], fill=fill)
            d.rectangle([l, t, l + bw, t + bh], outline=faint, width=round(dp))
            line(faint, (l + bw / 2, t), (l + bw / 2, t + bh * 0.35), 1)
        box(seam - 21 * dp, floor - 13 * dp, 17 * dp, 13 * dp)
        box(seam - 35 * dp, floor - 10 * dp, 12 * dp, 10 * dp)
        box(seam - 18 * dp, floor - 23 * dp, 11 * dp, 10 * dp)
    else:
        rx, ry = 36 * dp, 17 * dp
        angs = [math.radians(a) for a in (0, 22.5, 45, 67.5, 90)]
        at = lambda a, f: (math.cos(a) * rx * f, math.sin(a) * ry * f)
        for a in angs:
            line(ink, (0, 0), at(a, 1), 1)
        for fr in (0.3, 0.55, 0.8, 0.97):
            pts = [at(angs[0], fr)]
            for i in range(1, len(angs)):
                p, c, p0 = at(angs[i], fr), at((angs[i] + angs[i - 1]) / 2, fr * 0.86), pts[-1]
                for t in [k / 16 for k in range(1, 17)]:
                    pts.append(((1 - t) ** 2 * p0[0] + 2 * (1 - t) * t * c[0] + t * t * p[0],
                                (1 - t) ** 2 * p0[1] + 2 * (1 - t) * t * c[1] + t * t * p[1]))
            d.line(pts, fill=ink, width=round(dp))

THEMES = {
    "light": dict(page="F1F3FA", card="FFFFFF", on="1C1D22", var="545B7E", prim="283890", dark=False),
    "dark": dict(page="131316", card="222328", on="E4E5EA", var="A8AAB3", prim="B9C3FF", dark=True),
}

def card(kind, theme, P, wdp=328):
    T = THEMES[theme]
    parts = kind == "parts"
    travel = kind in ("parts", "travel")
    top = 18 if travel else 12
    hdp = top + 60 + (18 if travel else 12)
    w, h = wdp * K, hdp * K
    bgh = T["card"]
    bg = rgba(bgh)
    im = Image.new("RGB", (w, h), bg[:3])
    d = ImageDraw.Draw(im, "RGBA")
    if travel:
        ink = rgba("FFFFFF", 0.16) if T["dark"] else rgba("283890", 0.20)
        tire = rgba("FFFFFF", 0.26) if T["dark"] else rgba("2B2F3A", 0.30)
        art(d, w, h, parts, T["dark"], ink, tire, bg, P)
    if kind == "job":
        title, sub, lab, dur = "Mercy Hospital – Boiler 2", "7:02 AM – 11:48 AM", "Service", "4h 46m"
    elif parts:
        title, sub, lab, dur = "Parts run for Mercy Hospital", "11:48 AM – 12:31 PM", "Parts run", "43m"
    else:
        title, sub, lab, dur = "Travel for Mercy Hospital", "12:31 PM – 1:05 PM", "Travel", "34m"
    x, y = 16 * K, top * K
    d.text((x, y + 2 * K), title, font=f("SemiBold", 16), fill=rgba(T["on"]))
    d.text((x, y + 24 * K + 2 * K), sub, font=f("Regular", 14), fill=rgba(T["on"]))
    d.text((x, y + 44 * K + 2 * K), lab, font=f("Regular", 12), fill=rgba(T["var"]))
    fd = f("SemiBold", 16)
    endpad = 16
    tw = d.textlength(dur, font=fd)
    d.text((w - endpad * K - tw, (h - 20 * K) / 2), dur, font=fd, fill=rgba(T["prim"]))
    mask = Image.new("L", (w, h), 0)
    ImageDraw.Draw(mask).rounded_rectangle([0, 0, w - 1, h - 1], radius=10 * K, fill=255)
    im = im.convert("RGBA")
    im.putalpha(mask)
    return im

def column(theme, P, label):
    T = THEMES[theme]
    cards = [card(k, theme, P) for k in ("job", "parts", "travel")]
    W = 360 * K
    H = 40 * K + sum(c.height for c in cards) + 8 * K * (len(cards) - 1) + 16 * K
    im = Image.new("RGBA", (W, H), rgba(T["page"]))
    d = ImageDraw.Draw(im)
    d.text((16 * K, 12 * K), label, font=f("Bold", 14), fill=rgba(T["var"]))
    y = 40 * K
    for c in cards:
        im.alpha_composite(c, (16 * K, y))
        y += c.height + 8 * K
    return im

def main(out):
    cols = [[column("light", NEW, "Light / Branded"), column("dark", NEW, "Dark")]]
    gap = 6 * K
    rowh = [max(c.height for c in r) for r in cols]
    W = 2 * 360 * K + gap
    H = sum(rowh) + gap
    im = Image.new("RGBA", (W, H), (200, 200, 205, 255))
    y = 0
    for r, rh in zip(cols, rowh):
        x = 0
        for c in r:
            im.alpha_composite(c, (x, y))
            x += c.width + gap
        y += rh + gap
    im = im.resize((W // SS, H // SS), Image.LANCZOS).convert("RGB")
    im.save(out)

if __name__ == "__main__":
    import sys
    main(sys.argv[1])
