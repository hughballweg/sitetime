import sys
sys.path.insert(0, "/tmp")
from PIL import Image, ImageDraw
import preview as pv
import jobart as ja

K = pv.K
CATS = [
    ("E", "Shop · Fab / piping", "Shop", "6:58 AM – 11:30 AM", "4h 32m"),
    ("F", "Shop · Misc", "Shop", "11:30 AM – 12:15 PM", "45m"),
    ("G", "Shop · Plan review", "Shop", "12:45 PM – 2:00 PM", "1h 15m"),
    ("H", "Job site · Install duct", "Mercy Hospital – Boiler 2", "7:02 AM – 11:48 AM", "4h 46m"),
    ("I", "Job site · Millwright", "Kohler Plant 4", "7:10 AM – 3:20 PM", "8h 10m"),
    ("J", "Job site · Piping", "Lakeview Elementary", "7:00 AM – 3:30 PM", "8h 30m"),
    ("K", "Job site · Electrical", "Fox Valley Clinic", "8:15 AM – 10:40 AM", "2h 25m"),
    ("L", "Job site · Controls", "City Hall Annex", "10:55 AM – 1:10 PM", "2h 15m"),
    ("M", "Job site · Insulating", "Mercy Hospital – Boiler 2", "1:05 PM – 3:30 PM", "2h 25m"),
    ("N", "Job site · Demo", "Riverside Apartments", "7:00 AM – 12:00 PM", "5h"),
    ("O", "Job site · Gen. labor / misc", "Riverside Apartments", "12:30 PM – 3:30 PM", "3h"),
    ("P", "Job site · Coordination / supervisory", "St. Mary's Expansion", "7:00 AM – 9:00 AM", "2h"),
    ("Q", "Job site · Warranty punchlist service", "Oak Ridge Library", "9:30 AM – 11:00 AM", "1h 30m"),
    ("T", "Other · School", "Apprentice school", "5:00 PM – 9:00 PM", "4h"),
    ("U", "Other · Paid time off", "PTO", "7:00 AM – 3:30 PM", "8h 30m"),
    ("V", "Other · Break", "Lunch", "11:30 AM – 12:00 PM", "30m"),
]


def job_card(cat, label, title, times, dur, theme, wdp=328):
    T = pv.THEMES[theme]
    top = 12
    hdp = top + 60 + 12
    w, h = wdp * K, hdp * K
    bg = pv.rgba(T["card"])
    im = Image.new("RGB", (w, h), bg[:3])
    d = ImageDraw.Draw(im, "RGBA")
    ink = pv.rgba("FFFFFF", 0.16) if T["dark"] else pv.rgba("283890", 0.20)
    ja.render(d, ja.ICONS[cat], w - 10 * K, h, K, ink, bg)
    x, y = 16 * K, top * K
    d.text((x, y + 2 * K), title, font=pv.f("SemiBold", 16), fill=pv.rgba(T["on"]))
    d.text((x, y + 26 * K), times, font=pv.f("Regular", 14), fill=pv.rgba(T["on"]))
    d.text((x, y + 46 * K), label, font=pv.f("Regular", 12), fill=pv.rgba(T["var"]))
    fd = pv.f("SemiBold", 16)
    tw = d.textlength(dur, font=fd)
    d.text((w - 16 * K - tw, (h - 20 * K) / 2), dur, font=fd, fill=pv.rgba(T["prim"]))
    mask = Image.new("L", (w, h), 0)
    ImageDraw.Draw(mask).rounded_rectangle([0, 0, w - 1, h - 1], radius=10 * K, fill=255)
    im = im.convert("RGBA")
    im.putalpha(mask)
    return im


def column(theme, items, label):
    T = pv.THEMES[theme]
    cards = [job_card(c, l, t, tm, du, theme) for c, l, t, tm, du in items]
    W = 360 * K
    H = 40 * K + sum(c.height for c in cards) + 8 * K * (len(cards) - 1) + 16 * K
    im = Image.new("RGBA", (W, H), pv.rgba(T["page"]))
    d = ImageDraw.Draw(im)
    d.text((16 * K, 12 * K), label, font=pv.f("Bold", 14), fill=pv.rgba(T["var"]))
    y = 40 * K
    for c in cards:
        im.alpha_composite(c, (16 * K, y))
        y += c.height + 8 * K
    return im


def sheet(items, out, title_suffix=""):
    cols = [column("light", items, "Light / Branded" + title_suffix), column("dark", items, "Dark" + title_suffix)]
    gap = 6 * K
    W = sum(c.width for c in cols) + gap
    H = max(c.height for c in cols)
    im = Image.new("RGBA", (W, H), (200, 200, 205, 255))
    x = 0
    for c in cols:
        im.alpha_composite(c, (x, 0))
        x += c.width + gap
    im.resize((W // pv.SS, H // pv.SS), Image.LANCZOS).convert("RGB").save(out)


if __name__ == "__main__":
    sheet(CATS[:8], "/home/claude/job_art_preview_1.png")
    sheet(CATS[8:], "/home/claude/job_art_preview_2.png")
