import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

// Google Maps key: from the MAPS_API_KEY environment variable (e.g. a GitHub secret), or from
// maps.properties next to settings.gradle.kts (MAPS_API_KEY=...). Blank = the Map tab explains it isn't set up.
val mapsKey: String = System.getenv("MAPS_API_KEY")?.takeIf { it.isNotBlank() } ?: run {
    val f = rootProject.file("maps.properties")
    if (f.exists()) {
        Properties().apply { f.inputStream().use { load(it) } }.getProperty("MAPS_API_KEY", "").trim()
    } else {
        ""
    }
}

android {
    namespace = "com.sitetime.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.sitetime.app"
        minSdk = 26
        targetSdk = 35
        // Each GitHub build gets a higher version number so it installs over the last one.
        versionCode = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()
        versionName = "1.0." + (System.getenv("GITHUB_RUN_NUMBER") ?: "0")
        manifestPlaceholders["MAPS_API_KEY"] = mapsKey
        buildConfigField("String", "MAPS_API_KEY", "\"$mapsKey\"")
    }

    // A fixed signing key, so every new build can be installed as an update
    // without uninstalling (which would erase your timesheet data).
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }
    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-core")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("com.google.android.gms:play-services-location:21.3.0")
    implementation("com.google.maps.android:maps-compose:6.4.0")
}
