package com.sitetime.app

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import java.io.File
import java.time.Instant
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.util.Locale

val HM: DateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm")
val DAY_FMT: DateTimeFormatter = DateTimeFormatter.ofPattern("EEE d MMM")
private val H_MM: DateTimeFormatter = DateTimeFormatter.ofPattern("H:mm")

fun Long.toZoned(): ZonedDateTime = Instant.ofEpochMilli(this).atZone(ZoneId.systemDefault())
fun Long.toLocalDate(): LocalDate = toZoned().toLocalDate()

fun fmtTime(ms: Long): String =
    ms.toZoned().format(DateTimeFormatter.ofLocalizedTime(FormatStyle.SHORT))

fun fmtHm(ms: Long): String = ms.toZoned().format(HM)

fun fmtDur(ms: Long): String {
    val m = (ms / 60_000L).coerceAtLeast(0)
    return "${m / 60}h ${"%02d".format(m % 60)}m"
}

fun parseHm(s: String): LocalTime? =
    runCatching { LocalTime.parse(s.trim().replace('.', ':'), H_MM) }.getOrNull()

private fun hours(ms: Long) = String.format(Locale.US, "%.2f", ms / 3_600_000.0)

private fun csv(s: String) =
    if (s.any { it == ',' || it == '"' || it == '\n' }) "\"" + s.replace("\"", "\"\"") + "\"" else s

fun exportCsv(ctx: Context, entries: List<Entry>, fileName: String) {
    val sb = StringBuilder("Date,Site,Start,End,Hours,Note\n")
    var total = 0L
    for (e in entries.sortedBy { it.start }) {
        val s = e.start.toZoned()
        val dur = e.end - e.start
        total += dur
        sb.append(s.toLocalDate()).append(',')
            .append(csv(e.label)).append(',')
            .append(s.format(HM)).append(',')
            .append(e.end.toZoned().format(HM)).append(',')
            .append(hours(dur)).append(',')
            .append(csv(e.note)).append('\n')
    }
    sb.append(",Total,,,").append(hours(total)).append(",\n")

    val dir = File(ctx.cacheDir, "exports").apply { mkdirs() }
    val file = File(dir, fileName)
    file.writeText(sb.toString())
    val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", file)
    val send = Intent(Intent.ACTION_SEND)
        .setType("text/csv")
        .putExtra(Intent.EXTRA_STREAM, uri)
        .putExtra(Intent.EXTRA_SUBJECT, fileName.removeSuffix(".csv"))
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    ctx.startActivity(Intent.createChooser(send, "Export timesheet"))
}
