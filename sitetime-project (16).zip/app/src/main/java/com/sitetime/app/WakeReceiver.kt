package com.sitetime.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Morning alarm: switches tracking back on when tracking hours begin. */
class WakeReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        Prefs.migrate(ctx)
        if (!Prefs.trackingEnabled(ctx) || !Perms.hasLocation(ctx)) return
        try {
            TrackingService.send(ctx, TrackingService.ACTION_WAKE)
        } catch (e: Exception) {
            // Android refused to start it from the background: ask with a tap instead.
            TrackingService.postWakePrompt(ctx)
        }
    }
}
