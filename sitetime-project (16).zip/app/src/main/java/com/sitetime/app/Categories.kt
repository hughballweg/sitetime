package com.sitetime.app

/** The work-type columns on the timesheet form, keyed by spreadsheet column. */
data class Category(val col: String, val name: String, val group: String) {
    val label get() = "$group · ${name.lowercase().replaceFirstChar { it.uppercase() }}"
}

object Categories {
    val all = listOf(
        Category("E", "FAB / PIPING", "Shop"),
        Category("F", "MISC", "Shop"),
        Category("G", "PLAN REVIEW", "Shop"),
        Category("H", "INSTALL DUCT", "Job site"),
        Category("I", "MILLWRIGHT", "Job site"),
        Category("J", "PIPING", "Job site"),
        Category("K", "ELECTRICAL", "Job site"),
        Category("L", "CONTROLS", "Job site"),
        Category("M", "INSULATING", "Job site"),
        Category("N", "DEMO", "Job site"),
        Category("O", "GEN. LABOR / MISC", "Job site"),
        Category("P", "COORDINATION / SUPERVISORY", "Job site"),
        Category("Q", "WARRANTY PUNCHLIST SERVICE", "Job site"),
        Category("R", "PARTS RUN", "Other"),
        Category("S", "TRAVEL", "Other"),
        Category("T", "SCHOOL", "Other"),
        Category("U", "PAID TIME OFF", "Other"),
        Category("V", "BREAK", "Other"),
    )
    const val BREAK = "V"
    fun of(col: String?): Category? = all.firstOrNull { it.col == col }
    fun labelOf(col: String?): String = of(col)?.label ?: "No work type"
}
