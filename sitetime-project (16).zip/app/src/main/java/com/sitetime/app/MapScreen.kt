package com.sitetime.app

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.addPathNodes
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.LatLngBounds
import com.google.maps.android.compose.GoogleMap
import com.google.maps.android.compose.MapProperties
import com.google.maps.android.compose.MapType
import com.google.maps.android.compose.MapUiSettings
import com.google.maps.android.compose.MarkerComposable
import com.google.maps.android.compose.MarkerState
import com.google.maps.android.compose.Polyline
import com.google.maps.android.compose.rememberCameraPositionState
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter

/** Folded-map icon for the Map tab (Material "map" glyph). */
val MapIcon: ImageVector = ImageVector.Builder(
    name = "Map", defaultWidth = 24.dp, defaultHeight = 24.dp, viewportWidth = 24f, viewportHeight = 24f,
).addPath(
    pathData = addPathNodes(
        "M20.5,3l-0.16,0.03L15,5.1 9,3 3.36,4.9c-0.21,0.07 -0.36,0.25 -0.36,0.48V20.5c0,0.28 0.22,0.5 0.5,0.5" +
            "l0.16,-0.03L9,18.9l6,2.1 5.64,-1.9c0.21,-0.07 0.36,-0.25 0.36,-0.48V3.5c0,-0.28 -0.22,-0.5 -0.5,-0.5z" +
            "M15,19l-6,-2.11V5l6,2.11V19z",
    ),
    fill = SolidColor(Color.Black),
).build()

private val MAP_DAY_FMT = DateTimeFormatter.ofPattern("EEE, MMM d")
private val WISCONSIN = LatLng(44.5, -89.5)

/** Map tab: one day at a time, with your route and numbered pins for each stop. */
@Composable
fun MapScreen() {
    val ctx = LocalContext.current
    if (BuildConfig.MAPS_API_KEY.isBlank()) {
        MapNotSetUp()
        return
    }
    val db = remember { Db.get(ctx) }
    val version by Db.changes.collectAsState()
    var dayStr by rememberSaveable { mutableStateOf(LocalDate.now().toString()) }
    val day = LocalDate.parse(dayStr)
    val today = LocalDate.now()
    val zone = ZoneId.systemDefault()
    val from = day.atStartOfDay(zone).toInstant().toEpochMilli()
    val to = day.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli()

    // Stops with a location (drives show as the route line, not pins).
    val stops = remember(dayStr, version) {
        db.entriesBetween(from, to)
            .filter { it.lat != null && it.lng != null && it.category != "R" && it.category != "S" }
    }
    val route = remember(dayStr, version) { simplify(db.fixesBetween(from, to)) }
    val points = remember(stops, route) { route + stops.map { LatLng(it.lat!!, it.lng!!) } }
    val fallback = remember { db.lastFix()?.let { LatLng(it.lat, it.lng) } }

    val camera = rememberCameraPositionState {
        position = CameraPosition.fromLatLngZoom(fallback ?: WISCONSIN, if (fallback != null) 13f else 6f)
    }
    var loaded by remember { mutableStateOf(false) }
    val padPx = with(LocalDensity.current) { 56.dp.roundToPx() }
    val scope = rememberCoroutineScope()

    // Frame the whole day whenever the day changes.
    LaunchedEffect(loaded, dayStr, points.size) {
        if (!loaded || points.isEmpty()) return@LaunchedEffect
        val update = if (points.size == 1 || spanM(points) < 80f) {
            CameraUpdateFactory.newLatLngZoom(points.first(), 17f)
        } else {
            val b = LatLngBounds.builder()
            points.forEach { b.include(it) }
            CameraUpdateFactory.newLatLngBounds(b.build(), padPx)
        }
        try {
            camera.move(update)
        } catch (_: Exception) {
            // Map not laid out yet; it will frame on the next change.
        }
    }

    Column(Modifier.fillMaxSize()) {
        // Day picker
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = { dayStr = day.minusDays(1).toString() }) {
                Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, contentDescription = "Previous day")
            }
            TextButton(
                onClick = { pickDate(ctx, day) { if (!it.isAfter(today)) dayStr = it.toString() } },
                modifier = Modifier.weight(1f),
            ) {
                Text(
                    if (day == today) "Today · ${day.format(MAP_DAY_FMT)}" else day.format(MAP_DAY_FMT),
                    style = MaterialTheme.typography.titleMedium,
                )
            }
            IconButton(onClick = { dayStr = day.plusDays(1).toString() }, enabled = day.isBefore(today)) {
                Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = "Next day")
            }
        }

        Box(Modifier.fillMaxWidth().weight(1f)) {
            GoogleMap(
                modifier = Modifier.fillMaxSize(),
                cameraPositionState = camera,
                properties = MapProperties(mapType = MapType.HYBRID),
                uiSettings = MapUiSettings(zoomControlsEnabled = false, mapToolbarEnabled = false),
                onMapLoaded = { loaded = true },
            ) {
                if (route.size >= 2) {
                    // Dark underlay so the line stands out on any imagery.
                    Polyline(points = route, color = Color(0x99000000), width = 14f, zIndex = 1f)
                    Polyline(points = route, color = Color(0xFF7FD3FF), width = 8f, zIndex = 2f)
                }
                stops.forEachIndexed { i, e ->
                    val pos = LatLng(e.lat!!, e.lng!!)
                    val state = remember(e.id, pos) { MarkerState(position = pos) }
                    MarkerComposable(
                        e.id, i, e.ongoing,
                        state = state,
                        title = e.label,
                        snippet = "${fmtTime(e.start)} – ${if (e.ongoing) "now" else fmtTime(e.end)} · " +
                            "${fmtDur(e.end - e.start)} · ${Categories.labelOf(e.category)}",
                        anchor = Offset(0.5f, 0.5f),
                        zIndex = 3f + i,
                    ) {
                        NumberPin(i + 1, e.ongoing)
                    }
                }
            }
            if (points.isEmpty()) {
                MapNote("No location history for this day.")
            } else if (route.size < 2 && stops.isNotEmpty()) {
                MapNote("No route saved for this day. Routes are saved from this update on.")
            }
        }

        if (stops.isNotEmpty()) {
            LazyColumn(Modifier.fillMaxWidth().heightIn(max = 220.dp)) {
                itemsIndexed(stops, key = { _, e -> e.id }) { i, e ->
                    Row(
                        Modifier.fillMaxWidth()
                            .clickable {
                                scope.launch {
                                    try {
                                        camera.animate(CameraUpdateFactory.newLatLngZoom(LatLng(e.lat!!, e.lng!!), 17f))
                                    } catch (_: Exception) {
                                    }
                                }
                            }
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        NumberPin(i + 1, e.ongoing)
                        Column(Modifier.weight(1f)) {
                            Text(
                                e.label, style = MaterialTheme.typography.titleSmall,
                                maxLines = 1, overflow = TextOverflow.Ellipsis,
                            )
                            Text(
                                "${fmtTime(e.start)} – ${if (e.ongoing) "now" else fmtTime(e.end)}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        Text(
                            fmtDur(e.end - e.start), style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.primary,
                        )
                    }
                    HorizontalDivider()
                }
            }
        }
    }
}

@Composable
private fun NumberPin(n: Int, current: Boolean) {
    Box(
        Modifier.size(28.dp)
            .background(if (current) PrimeRed else PrimeNavy, CircleShape)
            .border(2.dp, Color.White, CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        Text("$n", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun MapNote(text: String) {
    Box(Modifier.fillMaxWidth().padding(12.dp), contentAlignment = Alignment.TopCenter) {
        Text(
            text,
            color = Color.White,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier
                .background(Color(0xCC1C1D22), RoundedCornerShape(8.dp))
                .padding(horizontal = 12.dp, vertical = 8.dp),
        )
    }
}

@Composable
private fun MapNotSetUp() {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterVertically),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("Map isn't set up yet", style = MaterialTheme.typography.titleMedium)
        Text(
            "The satellite map needs a Google Maps API key added to the app build. " +
                "Your location history is already being saved, so it will be there once the map is on.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

/** Drops fixes within 20 m of the last kept one, so standing still doesn't scribble on the map. */
private fun simplify(fixes: List<Fix>): List<LatLng> {
    val out = ArrayList<LatLng>()
    var lastLat = 0.0
    var lastLng = 0.0
    for (f in fixes) {
        if (out.isEmpty() || distanceM(lastLat, lastLng, f.lat, f.lng) >= 20f) {
            out.add(LatLng(f.lat, f.lng))
            lastLat = f.lat
            lastLng = f.lng
        }
    }
    return out
}

/** Rough size of the area covered, in metres. */
private fun spanM(points: List<LatLng>): Float {
    val minLat = points.minOf { it.latitude }
    val maxLat = points.maxOf { it.latitude }
    val minLng = points.minOf { it.longitude }
    val maxLng = points.maxOf { it.longitude }
    return distanceM(minLat, minLng, maxLat, maxLng)
}
