package com.sitetime.app

import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import kotlin.math.ceil
import kotlin.math.roundToLong

/** One line on a day: a site and its hours per work-type column. */
class SheetRow(val name: String) {
    val hours = linkedMapOf<String, Double>()
    val total get() = round1(hours.values.sum())
}

class SheetDay(
    val date: LocalDate,
    val rows: List<SheetRow>,
    val start: Double?,
    val stop: Double?,
    val notes: String,
    val edited: Boolean = false,
) {
    val total get() = round1(rows.sumOf { it.total })
    val hasBreak get() = rows.any { (it.hours[Categories.BREAK] ?: 0.0) > 0 }

    fun toJson(): String = JSONObject().apply {
        put("start", start ?: JSONObject.NULL)
        put("stop", stop ?: JSONObject.NULL)
        put("notes", notes)
        put("rows", JSONArray().apply {
            rows.forEach { r ->
                put(JSONObject().apply {
                    put("name", r.name)
                    put("hours", JSONObject().apply { r.hours.forEach { (k, v) -> put(k, v) } })
                })
            }
        })
    }.toString()

    companion object {
        fun fromJson(date: LocalDate, json: String): SheetDay {
            val o = JSONObject(json)
            val arr = o.getJSONArray("rows")
            val rows = (0 until arr.length()).map { i ->
                val ro = arr.getJSONObject(i)
                SheetRow(ro.getString("name")).also { row ->
                    val h = ro.getJSONObject("hours")
                    h.keys().forEach { k -> row.hours[k] = h.getDouble(k) }
                }
            }
            return SheetDay(
                date, rows,
                if (o.isNull("start")) null else o.getDouble("start"),
                if (o.isNull("stop")) null else o.getDouble("stop"),
                o.optString("notes", ""),
                edited = true,
            )
        }
    }
}

fun round1(x: Double): Double = (x * 10).roundToLong() / 10.0

/**
 * Clock time as the form wants it: hour in 24h plus tenths, where
 * :01-:06 = .1, :07-:12 = .2 ... :49-:54 = .9 and :55-:59 rolls to the next hour.
 */
fun decimalTime(ms: Long, dayStart: LocalDate): Double {
    val z = ms.toZoned()
    val dayOffset = (z.toLocalDate().toEpochDay() - dayStart.toEpochDay()) * 24
    return dayOffset + z.hour + ceil(z.minute / 6.0) / 10.0
}

/** 15.2 -> "3:12 PM", for showing what a decimal time means. */
fun decimalToClock(d: Double): String {
    val totalMin = (d * 60).roundToLong().toInt()
    val h = (totalMin / 60) % 24
    val m = totalMin % 60
    val h12 = if (h % 12 == 0) 12 else h % 12
    return "$h12:${"%02d".format(m)} ${if (h < 12) "AM" else "PM"}"
}

fun fmtNum(x: Double): String = String.format(Locale.US, "%.1f", x)

val WEEK_FMT: DateTimeFormatter = DateTimeFormatter.ofPattern("M/d/yy")

object Signature {
    fun file(ctx: Context) = File(ctx.filesDir, "signature.png")
    fun exists(ctx: Context) = file(ctx).exists()
}

object Timesheet {
    val DAY_NAMES = listOf("MON", "TUE", "WED", "THUR", "FRI", "SAT", "SUN")
    private val BASE_ROWS = listOf(4, 13, 22, 42, 51, 81, 90) // day header row of each block
    const val ROWS_PER_DAY = 6

    /** Always reads the latest entries, breaks and notes, so every screen and export agrees. */
    fun loadWeek(ctx: Context, weekStart: LocalDate): List<SheetDay> {
        val db = Db.get(ctx)
        val zone = java.time.ZoneId.systemDefault()
        val from = weekStart.atStartOfDay(zone).toInstant().toEpochMilli()
        val to = weekStart.plusDays(7).atStartOfDay(zone).toInstant().toEpochMilli()
        val end = weekStart.plusDays(7)
        return buildWeek(
            weekStart, db.entriesBetween(from, to), Prefs.defaultCategory(ctx),
            db.breaksBetween(weekStart, end), db.notesBetween(weekStart, end),
        )
    }

    /** Builds the week's timesheet from your entries (stops, logged drives and anything you added). */
    fun buildWeek(
        weekStart: LocalDate, entries: List<Entry>, defaultCat: String,
        breaks: Map<LocalDate, Int>, dayNotes: Map<LocalDate, String> = emptyMap(),
    ): List<SheetDay> =
        (0 until 7).map { i ->
            val date = weekStart.plusDays(i.toLong())
            val dayEntries = entries.filter { it.start.toLocalDate() == date }.sortedBy { it.start }
            val rows = linkedMapOf<String, SheetRow>()
            var start: Double? = null
            var stop: Double? = null
            // Time between entries (not logged as work) goes in the BREAK column of the line you left,
            // so the lines add up to the day's start-to-stop.
            var lastLine: String? = null
            for ((i, e) in dayEntries.withIndex()) {
                val s = decimalTime(e.start, date)
                val t = decimalTime(e.end, date)
                val hrs = round1((t - s).coerceAtLeast(0.0))
                // Lunch out goes on the line of the job you left (or came back to), in its BREAK column.
                val line = if (isLunchEntry(e)) {
                    (dayEntries.take(i).lastOrNull { !isLunchEntry(it) } ?: dayEntries.drop(i + 1).firstOrNull { !isLunchEntry(it) })
                        ?.let { sheetLine(it) } ?: e.label
                } else {
                    sheetLine(e)
                }
                val prevStop = stop
                val prevLine = lastLine
                if (prevStop != null && prevLine != null && s > prevStop) {
                    val gap = round1(s - prevStop)
                    if (gap > 0) {
                        val r = rows.getValue(prevLine)
                        r.hours[Categories.BREAK] = round1((r.hours[Categories.BREAK] ?: 0.0) + gap)
                    }
                }
                val row = rows.getOrPut(line) { SheetRow(line) }
                val cat = e.category ?: defaultCat
                if (hrs > 0) row.hours[cat] = round1((row.hours[cat] ?: 0.0) + hrs)
                start = minOf(start ?: s, s)
                stop = maxOf(stop ?: t, t)
                lastLine = line
            }
            applyBreak(rows.values.toList(), breaks[date] ?: 0)
            // The form has 6 lines per day; fold any extra sites into the last line.
            var list = rows.values.toList()
            if (list.size > ROWS_PER_DAY) {
                val merged = SheetRow(list.drop(ROWS_PER_DAY - 1).joinToString(" / ") { it.name })
                list.drop(ROWS_PER_DAY - 1).forEach { r ->
                    r.hours.forEach { (k, v) -> merged.hours[k] = round1((merged.hours[k] ?: 0.0) + v) }
                }
                list = list.take(ROWS_PER_DAY - 1) + merged
            }
            val notes = dayNotes[date]?.takeIf { it.isNotBlank() }
                ?: dayEntries.map { it.note }.filter { it.isNotBlank() }.distinct().joinToString("; ")
            SheetDay(date, list, start, stop, notes)
        }

    /** Minutes of the workday (first entry's start to last entry's end) not covered by any entry. */
    fun gapMinutes(dayEntries: List<Entry>): Int {
        var gap = 0L
        var cover: Long? = null
        for (e in dayEntries.sortedBy { it.start }) {
            val c = cover
            if (c != null && e.start > c) gap += e.start - c
            cover = maxOf(c ?: e.end, e.end)
        }
        return ((gap + 30_000L) / 60_000L).toInt()
    }

    /** Minutes of lunch entries (drives / stops logged as lunch). */
    fun lunchMinutes(dayEntries: List<Entry>): Int =
        ((dayEntries.filter { isLunchEntry(it) }.sumOf { it.end - it.start } + 30_000L) / 60_000L).toInt()

    /**
     * The day's break as it goes on the timesheet: time not logged as work (gaps + lunches), or the
     * break you set if that's more (the rest comes out of work time).
     */
    fun effectiveBreak(dayEntries: List<Entry>, breakMin: Int): Int =
        maxOf(breakMin, gapMinutes(dayEntries) + lunchMinutes(dayEntries))

    /** Work time for a day: entries minus lunches, minus any break beyond the gaps and lunches. */
    fun workedMs(dayEntries: List<Entry>, breakMin: Int): Long {
        val all = dayEntries.sumOf { it.end - it.start }
        val lunch = dayEntries.filter { isLunchEntry(it) }.sumOf { it.end - it.start }
        val away = (gapMinutes(dayEntries) + lunchMinutes(dayEntries)) * 60_000L
        val carve = (breakMin * 60_000L - away).coerceAtLeast(0L)
        return (all - lunch - carve).coerceAtLeast(0L)
    }

    /**
     * Your break happened while you were at a site, so the location data counted it as work.
     * Move it out of the work hours and into the BREAK column, taking it from the line with the
     * most hours first. The day's total stays the same, matching how the paper form is filled in.
     */
    private fun applyBreak(rows: List<SheetRow>, minutes: Int) {
        // Time away (gaps between entries, lunches you logged) is already in the BREAK column and
        // counts toward the day's break; only the rest comes out of work time.
        val already = rows.sumOf { it.hours[Categories.BREAK] ?: 0.0 }
        var left = round1(minutes / 60.0 - already)
        if (left <= 0) return
        for (row in rows.sortedByDescending { it.total }) {
            while (left > 0) {
                val (cat, h) = row.hours.filterKeys { it != Categories.BREAK }.maxByOrNull { it.value } ?: break
                if (h <= 0) break
                val take = minOf(h, left)
                row.hours[cat] = round1(h - take)
                if (row.hours[cat] == 0.0) row.hours.remove(cat)
                row.hours[Categories.BREAK] = round1((row.hours[Categories.BREAK] ?: 0.0) + take)
                left = round1(left - take)
            }
            if (left <= 0) break
        }
    }

    fun included(dayIndex: Int, fri: Boolean, sat: Boolean, sun: Boolean) = when (dayIndex) {
        4 -> fri
        5 -> sat
        6 -> sun
        else -> true
    }

    // ------------------------------------------------------------ Filling the form

    private sealed interface Cell
    private class Str(val text: String) : Cell
    private class Num(val value: Double) : Cell
    private class Formula(val f: String, val cached: Double) : Cell

    /** What goes in which cell, and which rows are hidden. Shared by the Excel file and the PDF. */
    private class Form(val cells: Map<String, Cell>, val hidden: Set<Int>, val closeRows: Set<Int>)

    private fun buildForm(
        name: String, weekStart: LocalDate, days: List<SheetDay>, fri: Boolean, sat: Boolean, sun: Boolean,
        initial: Boolean = false,
    ): Form {
        val cells = HashMap<String, Cell>()
        cells["H1"] = Str(name)
        cells["S1"] = Str(weekStart.format(WEEK_FMT))
        if (initial && name.isNotBlank()) cells["D65"] = Str(Prefs.initials(name)) // tool box talk initials
        val hidden = HashSet<Int>()
        days.forEachIndexed { i, day ->
            val b = BASE_ROWS[i]
            if (!included(i, fri, sat, sun)) {
                hidden.addAll(b..b + 8)
                return@forEachIndexed
            }
            cells["A$b"] = Str("${DAY_NAMES[i]} ${day.date.monthValue}/${day.date.dayOfMonth}")
            if (day.rows.isEmpty() && day.start == null) return@forEachIndexed
            day.start?.let { cells["B$b"] = Num(it) }
            day.stop?.let { cells["C$b"] = Num(it) }
            cells["D$b"] = Formula("SUM(E${b + 1}:V${b + ROWS_PER_DAY})", day.total)
            val lineRows = (b + 1..b + 6).toList()
            day.rows.take(ROWS_PER_DAY).forEachIndexed { j, row ->
                val r = lineRows[j]
                cells["A$r"] = Str(row.name)
                row.hours.forEach { (col, h) -> if (h != 0.0) cells["$col$r"] = Num(h) }
                cells["W$r"] = Formula("SUM(E$r:V$r)", row.total)
            }
            if (day.notes.isNotBlank()) cells["B${b + 7}"] = Str(day.notes)
            cells["W${b + 7}"] = Formula("SUM(W${b + 1}:W${b + 6})", day.total)
        }
        if (!sat && !sun) hidden.addAll(78..98)
        // Only the last day on each page gets a bottom line. Wednesday, Friday and Sunday have it built in;
        // Thursday needs it when Friday is left off, Saturday when Sunday is.
        val closeRows = HashSet<Int>()
        if (!fri) closeRows.add(50)
        if (sat && !sun) closeRows.add(89)
        // "TOTAL" at the top right belongs to the first day on a page: Sunday is first when Saturday is left off.
        if (sun && !sat) cells["W90"] = Str("TOTAL")
        return Form(cells, hidden, closeRows)
    }

    /** Excel's General number format: 7 rather than 7.0. */
    fun general(x: Double): String =
        if (x == Math.floor(x)) x.toLong().toString() else String.format(Locale.US, "%.1f", x)

    private fun esc(s: String) =
        s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    private fun signatureBitmap(ctx: Context, withSignature: Boolean) =
        Signature.file(ctx).takeIf { withSignature && it.exists() }?.let { BitmapFactory.decodeFile(it.path) }

    /**
     * A brand-new folder for every export, so email and Drive apps can never hand over a cached
     * older copy of a file with the same name. Old exports are cleared out after an hour.
     */
    private fun exportsDir(ctx: Context): File {
        val root = File(ctx.cacheDir, "exports").apply { mkdirs() }
        val cutoff = System.currentTimeMillis() - 60 * 60_000L
        root.listFiles()?.forEach { if (it.isDirectory && it.lastModified() < cutoff) it.deleteRecursively() }
        return File(root, System.currentTimeMillis().toString()).apply { mkdirs() }
    }

    fun writeXlsx(
        ctx: Context, name: String, weekStart: LocalDate, days: List<SheetDay>,
        fri: Boolean, sat: Boolean, sun: Boolean, withSignature: Boolean, initial: Boolean = false,
    ): File {
        val form = buildForm(name, weekStart, days, fri, sat, sun, initial)
        val cellRe = Regex(
            """<c r="([A-Z]+[0-9]+)"((?: [a-zA-Z:]+="[^"]*")*)\s*(?:/>|>(?:(?!</c>).)*</c>)""",
            RegexOption.DOT_MATCHES_ALL,
        )
        val styleRe = Regex(""" s="(\d+)"""")
        val rowRe = Regex("""<row r="(\d+)"""")

        val files = LinkedHashMap<String, ByteArray>()
        ZipInputStream(ctx.assets.open("timesheet_template.xlsx")).use { zin ->
            while (true) {
                val entry = zin.nextEntry ?: break
                val buf = ByteArrayOutputStream()
                zin.copyTo(buf)
                files[entry.name] = buf.toByteArray()
            }
        }
        var sheet = String(files.getValue("xl/worksheets/sheet1.xml"), Charsets.UTF_8)
        val closeStyles = FormPdf.closeStyles(ctx)
        val refRe = Regex("""([A-Z]+)([0-9]+)""")
        sheet = cellRe.replace(sheet) { m ->
            val ref = m.groupValues[1]
            val (colL, rowS) = refRe.find(ref)!!.destructured
            val override = if (rowS.toInt() in form.closeRows) {
                closeStyles[rowS.toInt()]?.get(colL[0] - 'A' + 1)
            } else {
                null
            }
            val v = form.cells[ref]
            if (v == null && override == null) return@replace m.value
            val st = override?.let { " s=\"$it\"" }
                ?: styleRe.find(m.groupValues[2])?.let { " s=\"${it.groupValues[1]}\"" } ?: ""
            if (v == null) return@replace "<c r=\"$ref\"$st/>"
            when (v) {
                is Str -> "<c r=\"$ref\"$st t=\"inlineStr\"><is><t xml:space=\"preserve\">${esc(v.text)}</t></is></c>"
                is Num -> "<c r=\"$ref\"$st><v>${general(v.value)}</v></c>"
                is Formula -> "<c r=\"$ref\"$st><f>${v.f}</f><v>${general(v.cached)}</v></c>"
            }
        }
        sheet = rowRe.replace(sheet) { m ->
            if (m.groupValues[1].toInt() in form.hidden) "${m.value} hidden=\"1\"" else m.value
        }
        if (!sat && !sun) {
            sheet = sheet.replace(
                """<rowBreaks count="2" manualBreakCount="2"><brk id="38" max="16383" man="1"/><brk id="77" max="16383" man="1"/></rowBreaks>""",
                """<rowBreaks count="1" manualBreakCount="1"><brk id="38" max="16383" man="1"/></rowBreaks>""",
            )
        }
        files["xl/worksheets/sheet1.xml"] = sheet.toByteArray(Charsets.UTF_8)

        // Signature: swap the invisible placeholder picture for your drawn signature.
        val sigFile = Signature.file(ctx)
        if (withSignature && sigFile.exists()) {
            val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(sigFile.path, opts)
            if (opts.outWidth > 0 && opts.outHeight > 0) {
                val p = FormPdf.signaturePosition(ctx, opts.outWidth, opts.outHeight)
                val emu = { pt: Float -> (pt * 12700).toLong() }
                var drawing = String(files.getValue("xl/drawings/drawing1.xml"), Charsets.UTF_8)
                drawing = drawing
                    .replace(
                        "<xdr:from><xdr:col>15</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>64</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:from>",
                        "<xdr:from><xdr:col>${p.col0}</xdr:col><xdr:colOff>${emu(p.colOffPt)}</xdr:colOff>" +
                            "<xdr:row>${p.row0}</xdr:row><xdr:rowOff>${emu(p.rowOffPt)}</xdr:rowOff></xdr:from>",
                    )
                    .replace("cx=\"9525\" cy=\"9525\"", "cx=\"${emu(p.wPt)}\" cy=\"${emu(p.hPt)}\"")
                files["xl/drawings/drawing1.xml"] = drawing.toByteArray(Charsets.UTF_8)
                files["xl/media/signature.png"] = sigFile.readBytes()
            }
        }

        val file = File(exportsDir(ctx), "${fileBase(name, weekStart)}.xlsx")
        ZipOutputStream(file.outputStream()).use { zout ->
            files.forEach { (n, bytes) ->
                zout.putNextEntry(ZipEntry(n))
                zout.write(bytes)
                zout.closeEntry()
            }
        }
        return file
    }

    /** The same form as a PDF, drawn from the Excel template's exact layout. */
    fun writePdf(
        ctx: Context, name: String, weekStart: LocalDate, days: List<SheetDay>,
        fri: Boolean, sat: Boolean, sun: Boolean, withSignature: Boolean, initial: Boolean = false,
    ): File {
        val form = buildForm(name, weekStart, days, fri, sat, sun, initial)
        val values = form.cells.mapValues { (_, v) ->
            when (v) {
                is Str -> v.text to false
                is Num -> general(v.value) to true
                is Formula -> general(v.cached) to true
            }
        }
        val sig = signatureBitmap(ctx, withSignature)
        val pos = sig?.let { FormPdf.signaturePosition(ctx, it.width, it.height) }
        val file = File(exportsDir(ctx), "${fileBase(name, weekStart)}.pdf")
        FormPdf.render(ctx, file, values, form.hidden, sat || sun, sig, pos, form.closeRows)
        return file
    }

    fun fileBase(name: String, weekStart: LocalDate): String {
        val safe = name.replace(Regex("[^A-Za-z0-9]+"), "_").trim('_').ifBlank { "Timesheet" }
        return "Timesheet_${safe}_$weekStart"
    }

    private fun share(ctx: Context, file: File, mime: String, subject: String, chooserTitle: String) {
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", file)
        val send = Intent(Intent.ACTION_SEND)
            .setType(mime)
            .putExtra(Intent.EXTRA_STREAM, uri)
            .putExtra(Intent.EXTRA_SUBJECT, subject)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(Intent.createChooser(send, chooserTitle))
    }

    private fun subject(name: String, weekStart: LocalDate) = "Timesheet - $name - week of ${weekStart.format(WEEK_FMT)}"

    fun shareXlsx(ctx: Context, file: File, name: String, weekStart: LocalDate) = share(
        ctx, file, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        subject(name, weekStart), "Send timesheet (Excel)",
    )

    fun sharePdf(ctx: Context, file: File, name: String, weekStart: LocalDate) =
        share(ctx, file, "application/pdf", subject(name, weekStart), "Send timesheet (PDF)")

    /** Sends the finished PDF to Android's print screen (printers, or Save as PDF). */
    fun printPdf(ctx: Context, file: File) {
        val pm = ctx.getSystemService(Context.PRINT_SERVICE) as PrintManager
        pm.print(
            file.nameWithoutExtension,
            object : PrintDocumentAdapter() {
                override fun onLayout(
                    oldAttributes: PrintAttributes?, newAttributes: PrintAttributes?,
                    cancellationSignal: CancellationSignal?, callback: PrintDocumentAdapter.LayoutResultCallback?, extras: Bundle?,
                ) {
                    if (cancellationSignal?.isCanceled == true) {
                        callback?.onLayoutCancelled()
                        return
                    }
                    callback?.onLayoutFinished(
                        PrintDocumentInfo.Builder(file.name)
                            .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                            .build(),
                        true,
                    )
                }

                override fun onWrite(
                    pages: Array<out PageRange>?, destination: ParcelFileDescriptor?,
                    cancellationSignal: CancellationSignal?, callback: PrintDocumentAdapter.WriteResultCallback?,
                ) {
                    try {
                        val dest = destination ?: return
                        file.inputStream().use { input ->
                            FileOutputStream(dest.fileDescriptor).use { output -> input.copyTo(output) }
                        }
                        callback?.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
                    } catch (e: Exception) {
                        callback?.onWriteFailed(e.message)
                    }
                }
            },
            // Double-sided, flipped on the short edge (landscape pages), so it's set up already in the print screen.
            PrintAttributes.Builder()
                .setMediaSize(PrintAttributes.MediaSize.NA_LETTER.asLandscape())
                .setDuplexMode(PrintAttributes.DUPLEX_MODE_SHORT_EDGE)
                .build(),
        )
    }
}
