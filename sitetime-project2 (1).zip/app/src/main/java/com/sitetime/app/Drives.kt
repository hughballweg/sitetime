package com.sitetime.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat

/**
 * Asks after each drive between two places (neither of them ignored) whether to log it
 * as a parts run or travel. Tapping a button adds it to the timesheet.
 */
object Drives {
    private const val CHANNEL = "drives"
    const val ACTION_LOG = "com.sitetime.app.LOG_DRIVE"
    const val ACTION_SKIP = "com.sitetime.app.SKIP_DRIVE"
    const val PARTS_RUN = "R"
    const val TRAVEL = "S"

    private const val MIN_DRIVE_MS = 3 * 60_000L
    private const val MAX_DRIVE_MS = 3 * 60 * 60_000L

    fun inRange(depart: Long, arrive: Long) = arrive - depart in MIN_DRIVE_MS..MAX_DRIVE_MS

    private fun notifId(driveId: Long) = 1000 + (driveId % 100_000L).toInt()

    /** Removes a drive's question from the notification shade (e.g. after its day was deleted). */
    fun clearNotice(ctx: Context, driveId: Long) {
        ctx.getSystemService(NotificationManager::class.java).cancel(notifId(driveId))
    }

    /** Adds the drive to the timesheet as a Parts run or Travel entry. */
    fun log(ctx: Context, driveId: Long, cat: String) {
        val db = Db.get(ctx)
        val d = db.drive(driveId) ?: return
        ctx.getSystemService(NotificationManager::class.java).cancel(notifId(driveId))
        if (d.status == Drive.LOGGED) return
        val dest = destination(ctx, d)
        val entryId = db.insertEntry(
            Entry(
                id = 0, siteId = null,
                label = travelPrefix(cat) + dest,
                lat = null, lng = null, start = d.start, end = d.end,
                ongoing = false, note = "", category = cat,
            )
        )
        db.setDriveStatus(driveId, Drive.LOGGED, entryId)
    }

    /** The name of the job a drive ended at (kept current if you name the stop later). */
    fun destination(ctx: Context, d: Drive): String = d.job ?: Db.get(ctx).arrivalEntry(d.end)?.label ?: d.to

    /**
     * Logs a drive with your changes: Travel or Parts run, which job it's for, and its times
     * (on the drive's day).
     */
    fun logAs(ctx: Context, driveId: Long, cat: String, job: String, start: Long, end: Long) {
        val db = Db.get(ctx)
        val d = db.drive(driveId) ?: return
        ctx.getSystemService(NotificationManager::class.java).cancel(notifId(driveId))
        if (d.status == Drive.LOGGED) return
        val entryId = db.insertEntry(
            Entry(
                id = 0, siteId = null, label = travelPrefix(cat) + job.trim(),
                lat = null, lng = null, start = minOf(start, end), end = maxOf(start, end),
                ongoing = false, note = "", category = cat,
            )
        )
        db.setDriveStatus(driveId, Drive.LOGGED, entryId)
    }

    /**
     * Deleting a drive entry (Travel / Parts run): its drive goes under the day's "not counted"
     * drives, so you can count it again. A hand-added one gets a drive made for it.
     */
    fun deleteToNotCounted(ctx: Context, e: Entry) {
        val db = Db.get(ctx)
        val linked = db.drivesForEntry(e.id)
        db.deleteEntry(e.id)
        if (linked.isNotEmpty()) {
            linked.forEach { db.setDriveStatus(it.id, Drive.IGNORED, null) }
        } else {
            val job = jobOf(e.label)
            val id = db.addDrive(e.start, e.end, "", errandPlaceOf(e.label) ?: job, job)
            db.setDriveStatus(id, Drive.IGNORED, null)
        }
    }

    fun skip(ctx: Context, driveId: Long) {
        ctx.getSystemService(NotificationManager::class.java).cancel(notifId(driveId))
        val db = Db.get(ctx)
        if (db.drive(driveId)?.status == Drive.PENDING) db.setDriveStatus(driveId, Drive.SKIPPED, null)
    }

    /** A lunch drive: left off the timesheet (the break already covers it) and out of the day's list. */
    /**
     * A drive for lunch: it becomes a "Lunch" card at that time (BREAK column), and the day's break
     * covers it. Add eating time on the card.
     */
    fun lunch(ctx: Context, driveId: Long) {
        ctx.getSystemService(NotificationManager::class.java).cancel(notifId(driveId))
        val db = Db.get(ctx)
        val d = db.drive(driveId) ?: return
        if (d.status == Drive.LOGGED) return
        val entryId = db.insertEntry(
            Entry(
                id = 0, siteId = null, label = LUNCH_PREFIX, lat = null, lng = null, start = d.start, end = d.end,
                ongoing = false, note = "", category = Categories.BREAK,
            )
        )
        db.setDriveStatus(driveId, Drive.LUNCH, entryId)
        db.syncLunchBreak(d.start.toLocalDate())
    }

    fun ask(ctx: Context, driveId: Long, depart: Long, arrive: Long, from: String, to: String, job: String = to) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Drive time questions", NotificationManager.IMPORTANCE_HIGH)
        )
        val id = notifId(driveId)
        fun action(action: String, cat: String?, code: Int): PendingIntent {
            val i = Intent(ctx, DriveReceiver::class.java)
                .setAction(action)
                .putExtra("drive", driveId)
                .putExtra("cat", cat)
            return PendingIntent.getBroadcast(
                ctx, id * 4 + code, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            )
        }
        val text = "$from → $to, ${fmtTime(depart)} – ${fmtTime(arrive)} (${fmtDur(arrive - depart)}). " +
            "Add it to your timesheet as travel or a parts run for $job?"
        val n = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_pm)
            .setColor(0xFF283890.toInt())
            .setContentTitle("Log that drive?")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .addAction(0, "Parts run", action(ACTION_LOG, PARTS_RUN, 1))
            .addAction(0, "Travel", action(ACTION_LOG, TRAVEL, 2))
            .addAction(0, "Don't log", action(ACTION_SKIP, null, 3))
            .build()
        nm.notify(id, n)
    }
}

/** Handles the buttons on the "Log that drive?" notification. */
class DriveReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val entry = intent.getLongExtra("entry", -1L)
        when (intent.action) {
            Errands.ACTION_PARTS -> intent.getStringExtra("job")?.let { if (entry >= 0) Errands.partsRun(ctx, entry, it) }
            Errands.ACTION_LUNCH -> if (entry >= 0) Errands.lunch(ctx, entry)
            Errands.ACTION_JOB -> if (entry >= 0) Errands.job(ctx, entry)
            Errands.ACTION_SKIP -> if (entry >= 0) Errands.dismiss(ctx, entry)
        }
        val id = intent.getLongExtra("drive", -1L)
        if (id < 0) return
        when (intent.action) {
            Drives.ACTION_LOG -> intent.getStringExtra("cat")?.let { Drives.log(ctx, id, it) }
            Drives.ACTION_SKIP -> Drives.skip(ctx, id)
        }
    }
}
