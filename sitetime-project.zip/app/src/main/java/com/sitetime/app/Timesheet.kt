package com.sitetime.app

import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.print.PrintAttributes
import android.print.PrintManager
import android.util.Base64
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import kotlin.math.ceil
import kotlin.math.roundToLong

/** One line on a day: a site and its hours per work-type column. */
class SheetRow(val name: String) {
    val hours = linkedMapOf<String, Double>()
    val total get() = round1(hours.values.sum())
}

class SheetDay(
    val date: LocalDate,
    val rows: List<SheetRow>,
    val start: Double?,
    val stop: Double?,
    val notes: String,
    val edited: Boolean = false,
) {
    val total get() = round1(rows.sumOf { it.total })
    val hasBreak get() = rows.any { (it.hours[Categories.BREAK] ?: 0.0) > 0 }

    fun toJson(): String = JSONObject().apply {
        put("start", start ?: JSONObject.NULL)
        put("stop", stop ?: JSONObject.NULL)
        put("notes", notes)
        put("rows", JSONArray().apply {
            rows.forEach { r ->
                put(JSONObject().apply {
                    put("name", r.name)
                    put("hours", JSONObject().apply { r.hours.forEach { (k, v) -> put(k, v) } })
                })
            }
        })
    }.toString()

    companion object {
        fun fromJson(date: LocalDate, json: String): SheetDay {
            val o = JSONObject(json)
            val arr = o.getJSONArray("rows")
            val rows = (0 until arr.length()).map { i ->
                val ro = arr.getJSONObject(i)
                SheetRow(ro.getString("name")).also { row ->
                    val h = ro.getJSONObject("hours")
                    h.keys().forEach { k -> row.hours[k] = h.getDouble(k) }
                }
            }
            return SheetDay(
                date, rows,
                if (o.isNull("start")) null else o.getDouble("start"),
                if (o.isNull("stop")) null else o.getDouble("stop"),
                o.optString("notes", ""),
                edited = true,
            )
        }
    }
}

fun round1(x: Double): Double = (x * 10).roundToLong() / 10.0

/**
 * Clock time as the form wants it: hour in 24h plus tenths, where
 * :01-:06 = .1, :07-:12 = .2 ... :49-:54 = .9 and :55-:59 rolls to the next hour.
 */
fun decimalTime(ms: Long, dayStart: LocalDate): Double {
    val z = ms.toZoned()
    val dayOffset = (z.toLocalDate().toEpochDay() - dayStart.toEpochDay()) * 24
    return dayOffset + z.hour + ceil(z.minute / 6.0) / 10.0
}

/** 15.2 -> "3:12 PM", for showing what a decimal time means. */
fun decimalToClock(d: Double): String {
    val totalMin = (d * 60).roundToLong().toInt()
    val h = (totalMin / 60) % 24
    val m = totalMin % 60
    val h12 = if (h % 12 == 0) 12 else h % 12
    return "$h12:${"%02d".format(m)} ${if (h < 12) "AM" else "PM"}"
}

fun fmtNum(x: Double): String = String.format(Locale.US, "%.1f", x)

val WEEK_FMT: DateTimeFormatter = DateTimeFormatter.ofPattern("M/d/yy")

object Signature {
    fun file(ctx: Context) = File(ctx.filesDir, "signature.png")
    fun exists(ctx: Context) = file(ctx).exists()
}

object Timesheet {
    val DAY_NAMES = listOf("MON", "TUE", "WED", "THUR", "FRI", "SAT", "SUN")
    private val BASE_ROWS = listOf(4, 13, 22, 42, 51, 81, 90) // day header row of each block
    const val ROWS_PER_DAY = 6

    /** Builds the week from tracked stops, then swaps in any days you edited by hand. */
    fun buildWeek(
        weekStart: LocalDate, entries: List<Entry>, defaultCat: String,
        breaks: Map<LocalDate, Int>, edits: Map<LocalDate, String> = emptyMap(),
    ): List<SheetDay> =
        (0 until 7).map { i ->
            val date = weekStart.plusDays(i.toLong())
            edits[date]?.let { json ->
                runCatching { SheetDay.fromJson(date, json) }.getOrNull()?.let { return@map it }
            }
            val dayEntries = entries.filter { it.start.toLocalDate() == date }.sortedBy { it.start }
            val rows = linkedMapOf<String, SheetRow>()
            var start: Double? = null
            var stop: Double? = null
            for (e in dayEntries) {
                val s = decimalTime(e.start, date)
                val t = decimalTime(e.end, date)
                val hrs = round1((t - s).coerceAtLeast(0.0))
                val row = rows.getOrPut(e.label) { SheetRow(e.label) }
                val cat = e.category ?: defaultCat
                if (hrs > 0) row.hours[cat] = round1((row.hours[cat] ?: 0.0) + hrs)
                start = minOf(start ?: s, s)
                stop = maxOf(stop ?: t, t)
            }
            applyBreak(rows.values.toList(), breaks[date] ?: 0)
            // The form has 6 lines per day; fold any extra sites into the last line.
            var list = rows.values.toList()
            if (list.size > ROWS_PER_DAY) {
                val merged = SheetRow(list.drop(ROWS_PER_DAY - 1).joinToString(" / ") { it.name })
                list.drop(ROWS_PER_DAY - 1).forEach { r ->
                    r.hours.forEach { (k, v) -> merged.hours[k] = round1((merged.hours[k] ?: 0.0) + v) }
                }
                list = list.take(ROWS_PER_DAY - 1) + merged
            }
            val notes = dayEntries.map { it.note }.filter { it.isNotBlank() }.distinct().joinToString("; ")
            SheetDay(date, list, start, stop, notes)
        }

    /**
     * Your break happened while you were at a site, so the location data counted it as work.
     * Move it out of the work hours and into the BREAK column, taking it from the line with the
     * most hours first. The day's total stays the same, matching how the paper form is filled in.
     */
    private fun applyBreak(rows: List<SheetRow>, minutes: Int) {
        var left = round1(minutes / 60.0)
        if (left <= 0) return
        for (row in rows.sortedByDescending { it.total }) {
            while (left > 0) {
                val (cat, h) = row.hours.filterKeys { it != Categories.BREAK }.maxByOrNull { it.value } ?: break
                if (h <= 0) break
                val take = minOf(h, left)
                row.hours[cat] = round1(h - take)
                if (row.hours[cat] == 0.0) row.hours.remove(cat)
                row.hours[Categories.BREAK] = round1((row.hours[Categories.BREAK] ?: 0.0) + take)
                left = round1(left - take)
            }
            if (left <= 0) break
        }
    }

    fun included(dayIndex: Int, fri: Boolean, weekend: Boolean) = when (dayIndex) {
        4 -> fri
        5, 6 -> weekend
        else -> true
    }

    // ------------------------------------------------------------ Excel

    private sealed interface Cell
    private class Str(val text: String) : Cell
    private class Num(val value: Double) : Cell
    private class Formula(val f: String, val cached: Double) : Cell

    private fun esc(s: String) =
        s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    // Pixel widths of columns P..W on the form, used to centre the signature on the sign line.
    private val SIGN_COL_PX = listOf(80, 88, 73, 96, 96, 96, 96, 96)
    private const val EMU_PER_PX = 9525
    private const val SIGN_HEIGHT_EMU = 40 * 12700 // 40 pt tall
    private const val SIGN_MAX_WIDTH_EMU = 3_657_600 // 4 inches

    fun writeXlsx(
        ctx: Context, name: String, weekStart: LocalDate, days: List<SheetDay>,
        fri: Boolean, weekend: Boolean, withSignature: Boolean,
    ): File {
        val cells = HashMap<String, Cell>()
        cells["H1"] = Str(name)
        cells["S1"] = Str(weekStart.format(WEEK_FMT))
        cells["P67"] = Str(name)

        val hiddenRows = HashSet<Int>()
        days.forEachIndexed { i, day ->
            val b = BASE_ROWS[i]
            if (!included(i, fri, weekend)) {
                hiddenRows.addAll(b..b + 8)
                return@forEachIndexed
            }
            if (day.rows.isEmpty() && day.start == null) return@forEachIndexed
            day.start?.let { cells["B$b"] = Num(it) }
            day.stop?.let { cells["C$b"] = Num(it) }
            cells["D$b"] = Formula("SUM(E${b + 1}:V${b + ROWS_PER_DAY})", day.total)
            // Monday's first line is labelled "PTO?" on the form, so it's used last.
            val lineRows = if (i == 0) (b + 2..b + 6).toList() + (b + 1) else (b + 1..b + 6).toList()
            day.rows.take(ROWS_PER_DAY).forEachIndexed { j, row ->
                val r = lineRows[j]
                cells["A$r"] = Str(row.name)
                row.hours.forEach { (col, h) -> if (h != 0.0) cells["$col$r"] = Num(h) }
                cells["W$r"] = Formula("SUM(E$r:V$r)", row.total)
            }
            if (day.notes.isNotBlank()) cells["B${b + 7}"] = Str(day.notes)
            cells["W${b + 7}"] = Formula("SUM(W${b + 1}:W${b + 6})", day.total)
        }
        if (!weekend) hiddenRows.addAll(78..98)

        val cellRe = Regex(
            """<c r="([A-Z]+[0-9]+)"((?: [a-zA-Z:]+="[^"]*")*)\s*(?:/>|>(?:(?!</c>).)*</c>)""",
            RegexOption.DOT_MATCHES_ALL,
        )
        val styleRe = Regex(""" s="(\d+)"""")
        val rowRe = Regex("""<row r="(\d+)"""")

        val files = LinkedHashMap<String, ByteArray>()
        ZipInputStream(ctx.assets.open("timesheet_template.xlsx")).use { zin ->
            while (true) {
                val entry = zin.nextEntry ?: break
                val buf = ByteArrayOutputStream()
                zin.copyTo(buf)
                files[entry.name] = buf.toByteArray()
            }
        }
        var sheet = String(files.getValue("xl/worksheets/sheet1.xml"), Charsets.UTF_8)
        sheet = cellRe.replace(sheet) { m ->
            val ref = m.groupValues[1]
            val v = cells[ref] ?: return@replace m.value
            val st = styleRe.find(m.groupValues[2])?.let { " s=\"${it.groupValues[1]}\"" } ?: ""
            when (v) {
                is Str -> "<c r=\"$ref\"$st t=\"inlineStr\"><is><t xml:space=\"preserve\">${esc(v.text)}</t></is></c>"
                is Num -> "<c r=\"$ref\"$st><v>${fmtNum(v.value)}</v></c>"
                is Formula -> "<c r=\"$ref\"$st><f>${v.f}</f><v>${fmtNum(v.cached)}</v></c>"
            }
        }
        sheet = rowRe.replace(sheet) { m ->
            if (m.groupValues[1].toInt() in hiddenRows) "${m.value} hidden=\"1\"" else m.value
        }
        if (!weekend) {
            sheet = sheet.replace(
                """<rowBreaks count="2" manualBreakCount="2"><brk id="38" max="16383" man="1" /><brk id="77" max="16383" man="1" /></rowBreaks>""",
                """<rowBreaks count="1" manualBreakCount="1"><brk id="38" max="16383" man="1" /></rowBreaks>""",
            )
        }
        files["xl/worksheets/sheet1.xml"] = sheet.toByteArray(Charsets.UTF_8)

        // Signature: swap the invisible placeholder picture for your drawn signature.
        val sigFile = Signature.file(ctx)
        if (withSignature && sigFile.exists()) {
            val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(sigFile.path, opts)
            if (opts.outWidth > 0 && opts.outHeight > 0) {
                var cy = SIGN_HEIGHT_EMU.toLong()
                var cx = cy * opts.outWidth / opts.outHeight
                if (cx > SIGN_MAX_WIDTH_EMU) {
                    cy = cy * SIGN_MAX_WIDTH_EMU / cx
                    cx = SIGN_MAX_WIDTH_EMU.toLong()
                }
                var offPx = SIGN_COL_PX.sum() / 2.0 - cx / EMU_PER_PX / 2.0
                var col = 15 // column P
                for (w in SIGN_COL_PX) {
                    if (offPx < w) break
                    offPx -= w
                    col++
                }
                var drawing = String(files.getValue("xl/drawings/drawing1.xml"), Charsets.UTF_8)
                drawing = drawing
                    .replace(
                        "<xdr:col>15</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>64</xdr:row>",
                        "<xdr:col>$col</xdr:col><xdr:colOff>${(offPx.coerceAtLeast(0.0) * EMU_PER_PX).toLong()}</xdr:colOff><xdr:row>64</xdr:row>",
                    )
                    .replace("cx=\"9525\" cy=\"9525\"", "cx=\"$cx\" cy=\"$cy\"")
                files["xl/drawings/drawing1.xml"] = drawing.toByteArray(Charsets.UTF_8)
                files["xl/media/signature.png"] = sigFile.readBytes()
            }
        }

        val dir = File(ctx.cacheDir, "exports").apply { mkdirs() }
        val file = File(dir, "${fileBase(name, weekStart)}.xlsx")
        ZipOutputStream(file.outputStream()).use { zout ->
            files.forEach { (n, bytes) ->
                zout.putNextEntry(ZipEntry(n))
                zout.write(bytes)
                zout.closeEntry()
            }
        }
        return file
    }

    fun fileBase(name: String, weekStart: LocalDate): String {
        val safe = name.replace(Regex("[^A-Za-z0-9]+"), "_").trim('_').ifBlank { "Timesheet" }
        return "Timesheet_${safe}_$weekStart"
    }

    fun shareXlsx(ctx: Context, file: File) {
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", file)
        val send = Intent(Intent.ACTION_SEND)
            .setType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
            .putExtra(Intent.EXTRA_STREAM, uri)
            .putExtra(Intent.EXTRA_SUBJECT, file.nameWithoutExtension.replace('_', ' '))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(Intent.createChooser(send, "Send timesheet"))
    }

    // ------------------------------------------------------------ Print / PDF

    // Relative column widths, copied from the Excel form (A..W).
    private val COL_W = listOf(
        12.4, 9.7, 13.0, 13.0, 13.0, 13.0, 13.0, 13.0, 13.0, 13.0, 13.0, 13.0,
        13.0, 13.0, 13.0, 10.8, 11.8, 9.7, 13.0, 13.0, 13.0, 13.0, 13.0,
    )

    private fun dataUri(ctx: Context, bytes: ByteArray, mime: String) =
        "data:$mime;base64," + Base64.encodeToString(bytes, Base64.NO_WRAP)

    fun html(
        ctx: Context, name: String, weekStart: LocalDate, days: List<SheetDay>,
        fri: Boolean, weekend: Boolean, withSignature: Boolean,
    ): String {
        val cats = Categories.all
        val logo = runCatching { dataUri(ctx, ctx.assets.open("logo.jpg").readBytes(), "image/jpeg") }.getOrNull()
        val sigFile = Signature.file(ctx)
        val sig = if (withSignature && sigFile.exists()) dataUri(ctx, sigFile.readBytes(), "image/png") else null
        val total = COL_W.sum()
        val sb = StringBuilder()
        sb.append(
            """<!doctype html><html><head><meta charset="utf-8"><style>
            @page { size: letter landscape; margin: 0.35in; }
            * { box-sizing: border-box; }
            body { font-family: Arial, Helvetica, sans-serif; color: #000; margin: 0; }
            .page { page-break-after: always; }
            .page:last-child { page-break-after: auto; }
            .top { display: flex; align-items: flex-end; height: 24px; margin-bottom: 2px; }
            .top .lbl { font-weight: bold; font-size: 9px; margin: 0 6px 2px 0; }
            .top .val { font-size: 12px; font-weight: bold; border-bottom: 1px solid #000; padding: 0 8px 1px 4px; }
            table.grid { border-collapse: collapse; table-layout: fixed; width: 100%; }
            .grid td { border: 1px solid #000; height: 15px; padding: 1px 3px; font-size: 9px; text-align: center;
                       vertical-align: middle; overflow-wrap: anywhere; }
            .grid tr.hdr td { border: none; height: 104px; position: relative; vertical-align: bottom; padding: 0; }
            .grid tr.hdr td.cat { border-bottom: 1px solid #000; }
            .grid tr.hdr td.cat div { position: absolute; left: 45%; bottom: 4px; transform-origin: 0 100%;
                       transform: rotate(-60deg); white-space: nowrap; font-size: 7px; line-height: 1.1; text-align: left; }
            .grid tr.grp td { font-weight: bold; font-size: 8px; white-space: nowrap; overflow: hidden; }
            .grid tr.day td { font-weight: bold; }
            .grid tr.day td.site { white-space: nowrap; line-height: 1.05; }
            .grid tr.day td.site small { font-weight: normal; font-size: 7px; }
            .grid td.site { text-align: left; }
            .grid td.js-l { border-left: 2.5px solid #000; } .grid td.js-r { border-right: 2.5px solid #000; }
            .grid tr.notes td { text-align: left; border-left: none; border-right: none; }
            .grid tr.notes td.ntext { font-size: 8.5px; }
            .grid tr.notes td.tfd { text-align: center; border: 1px solid #000; }
            .grid tr.notes td.dt { border: 1px solid #000; text-align: center; font-weight: bold; }
            .grid tr.gap td { border: none; height: 16px; }
            .logo { position: absolute; left: 0; top: 40px; width: 15%; }
            .chart { text-align: center; font-size: 9px; margin: 8px 0 2px; white-space: pre; }
            table.foot { width: 100%; border-collapse: collapse; margin-top: 12px; font-size: 10px; }
            .foot td { vertical-align: bottom; padding: 0 6px; }
            .ibox { width: 90px; height: 34px; border: 2px solid #000; margin: 0 auto; }
            .small { font-size: 9px; text-align: center; padding-top: 3px; }
            .sline { border-bottom: 1px solid #000; height: 48px; text-align: center; position: relative; }
            .sline img { height: 44px; max-width: 95%; object-fit: contain; }
            .printed { font-size: 10px; font-style: italic; text-align: center; padding-top: 2px; }
            table.appr { border: 2px solid #000; border-collapse: collapse; font-size: 9px; width: 100%; }
            .appr td { padding: 3px 6px; } .appr .ln { border-bottom: 1px solid #000; width: 45%; }
            .notice { font-size: 10px; text-align: center; line-height: 1.6; }
            .mandatory { font-size: 15px; text-align: center; margin-top: 8px; }
            </style></head><body>"""
        )

        fun colgroup() {
            sb.append("<colgroup>")
            COL_W.forEach { sb.append("<col style=\"width:${"%.3f".format(Locale.US, it / total * 100)}%\">") }
            sb.append("</colgroup>")
        }

        fun header() {
            sb.append("<tr class=\"hdr\"><td colspan=\"4\"></td>")
            cats.forEachIndexed { k, c ->
                val js = when (k) { 3 -> " js-l"; 12 -> " js-r"; else -> "" }
                sb.append("<td class=\"cat$js\"><div>${esc(c.name)}</div></td>")
            }
            sb.append("<td></td></tr>")
            sb.append("<tr class=\"grp\"><td>DATE</td><td>START</td><td>STOP</td><td>TOTAL</td>")
            sb.append("<td colspan=\"3\">SHOP</td><td colspan=\"10\" class=\"js-l js-r\">JOB SITE</td>")
            sb.append("<td colspan=\"5\">OTHER</td><td style=\"border:none\"></td></tr>")
        }

        fun dayBlock(i: Int) {
            val day = days[i]
            val has = day.rows.isNotEmpty() || day.start != null
            sb.append("<tr class=\"day\"><td class=\"site\">${DAY_NAMES[i]} <small>${day.date.monthValue}/${day.date.dayOfMonth}</small></td>")
            sb.append("<td>${day.start?.let { fmtNum(it) } ?: ""}</td><td>${day.stop?.let { fmtNum(it) } ?: ""}</td>")
            sb.append("<td>${if (has) fmtNum(day.total) else ""}</td>")
            cats.forEachIndexed { k, _ ->
                val js = when (k) { 3 -> " class=\"js-l\""; 12 -> " class=\"js-r\""; else -> "" }
                sb.append("<td$js></td>")
            }
            sb.append("<td style=\"font-weight:normal\">TOTAL</td></tr>")
            for (j in 0 until ROWS_PER_DAY) {
                val row = day.rows.getOrNull(j)
                sb.append("<tr><td class=\"site\" colspan=\"4\">${esc(row?.name ?: "")}</td>")
                cats.forEachIndexed { k, c ->
                    val js = when (k) { 3 -> " class=\"js-l\""; 12 -> " class=\"js-r\""; else -> "" }
                    val v = row?.hours?.get(c.col)?.takeIf { it != 0.0 }
                    sb.append("<td$js>${v?.let { fmtNum(it) } ?: ""}</td>")
                }
                sb.append("<td>${row?.let { fmtNum(it.total) } ?: ""}</td></tr>")
            }
            sb.append("<tr class=\"notes\"><td>NOTES:</td><td class=\"ntext\" colspan=\"17\">${esc(day.notes)}</td>")
            sb.append("<td class=\"tfd\" colspan=\"4\">TOTAL FOR DAY</td>")
            sb.append("<td class=\"dt\">${if (has) fmtNum(day.total) else ""}</td></tr>")
            sb.append("<tr class=\"gap\"><td colspan=\"23\"></td></tr>")
        }

        fun footer() {
            sb.append("<div class=\"chart\">12:00 = 12    1:00 = 13    2:00 = 14    3:00 = 15    4:00 = 16    5:00 = 17    6:00 = 18    7:00 = 19    8:00 = 20</div>")
            sb.append("<div class=\"chart\">:01-:06 = .1      :07-:12 = .2      :13-:18 = .3      :19-:24 = .4      :25-:30 = .5      :31-:36 = .6      :37-:42 = .7      :43-:48 = .8      :49-:54 = .9</div>")
            sb.append("<table class=\"foot\"><tr>")
            sb.append("<td style=\"width:20%\">RECEIVED WEEKLY TOOL BOX TALK</td>")
            sb.append("<td style=\"width:12%\"><div class=\"ibox\"></div><div class=\"small\">INITIAL HERE</div></td>")
            sb.append("<td style=\"width:30%;text-align:center\">THE ABOVE INFORMATION IS TRUE AND ACCURATE</td>")
            sb.append("<td style=\"width:38%\"><div class=\"sline\">${sig?.let { "<img src=\"$it\">" } ?: ""}</div>")
            sb.append("<div class=\"small\">SIGN HERE</div><div class=\"printed\">${esc(name)}</div></td>")
            sb.append("</tr></table>")
            sb.append("<table style=\"width:100%;margin-top:10px;border-collapse:collapse\"><tr>")
            sb.append("<td style=\"width:24%;vertical-align:top\"><table class=\"appr\">")
            sb.append("<tr><td colspan=\"2\" style=\"text-align:center;border-bottom:2px solid #000\">APPRENTICE HOUR BREAKDOWN</td></tr>")
            listOf("Blueprint Layout", "Installation", "Welding and Soldering", "Misc activities").forEach {
                sb.append("<tr><td>$it</td><td class=\"ln\"></td></tr>")
            }
            sb.append("</table></td><td style=\"vertical-align:top;padding-left:20px\">")
            sb.append("<div class=\"notice\">A CORRECT AND COMPLETE TIMESHEET MUST BE RECEIVED BY THE OFFICE NO LATER THAN MONDAY<br>")
            sb.append("FOR PROCESSING AND ISSUANCE OF YOUR PAYCHECK ON THURSDAY.</div>")
            sb.append("<div class=\"notice\" style=\"margin-top:6px\">0.8 HOURS PER DAY OF LUNCH/BREAK TIME ARE MANDATORY AND WILL BE CALCULATED ON WORK DAYS OF 6 HRS OR MORE</div>")
            sb.append("<div class=\"mandatory\">USE OF THIS TIME SHEET FORM IS MANDATORY</div>")
            sb.append("</td></tr></table>")
        }

        fun page(dayIdx: List<Int>, first: Boolean, withFooter: Boolean) {
            sb.append("<div class=\"page\" style=\"position:relative\">")
            if (first) {
                sb.append("<div class=\"top\"><div style=\"width:26%\"></div>")
                sb.append("<span class=\"lbl\">NAME:</span><span class=\"val\" style=\"min-width:28%\">${esc(name)}</span>")
                sb.append("<div style=\"flex:1\"></div><span class=\"lbl\">WEEK STARTING:</span>")
                sb.append("<span class=\"val\" style=\"min-width:12%\">${weekStart.format(WEEK_FMT)}</span><div style=\"width:6%\"></div></div>")
                logo?.let { sb.append("<img class=\"logo\" src=\"$it\">") }
            }
            sb.append("<table class=\"grid\">")
            colgroup()
            header()
            dayIdx.forEach { dayBlock(it) }
            sb.append("</table>")
            if (withFooter) footer()
            sb.append("</div>")
        }

        page(listOf(0, 1, 2), first = true, withFooter = false)
        page(if (fri) listOf(3, 4) else listOf(3), first = false, withFooter = true)
        if (weekend) page(listOf(5, 6), first = false, withFooter = false)
        sb.append("</body></html>")
        return sb.toString()
    }

    private var printView: WebView? = null

    /** Opens Android's print dialog, which can also save as PDF. Needs an Activity context. */
    fun print(ctx: Context, html: String, jobName: String) {
        val wv = WebView(ctx)
        wv.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String?) {
                val pm = ctx.getSystemService(Context.PRINT_SERVICE) as PrintManager
                pm.print(
                    jobName,
                    view.createPrintDocumentAdapter(jobName),
                    PrintAttributes.Builder()
                        .setMediaSize(PrintAttributes.MediaSize.NA_LETTER.asLandscape())
                        .build(),
                )
            }
        }
        wv.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
        printView = wv // keep alive until printing starts
    }
}
