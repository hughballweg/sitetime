package com.sitetime.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat

/**
 * Asks after each drive between two places (neither of them ignored) whether to log it
 * as a parts run or travel. Tapping a button adds it to the timesheet.
 */
object Drives {
    private const val CHANNEL = "drives"
    const val ACTION_LOG = "com.sitetime.app.LOG_DRIVE"
    const val ACTION_SKIP = "com.sitetime.app.SKIP_DRIVE"
    const val PARTS_RUN = "R"
    const val TRAVEL = "S"

    private const val MIN_DRIVE_MS = 3 * 60_000L
    private const val MAX_DRIVE_MS = 3 * 60 * 60_000L

    fun shouldAsk(ctx: Context, depart: Long, arrive: Long): Boolean =
        Prefs.askDrives(ctx) && arrive - depart in MIN_DRIVE_MS..MAX_DRIVE_MS

    fun ask(ctx: Context, depart: Long, arrive: Long, from: String, to: String) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Drive time questions", NotificationManager.IMPORTANCE_HIGH)
        )
        val id = 1000 + ((depart / 60_000L) % 100_000L).toInt()
        fun action(action: String, cat: String?, code: Int): PendingIntent {
            val i = Intent(ctx, DriveReceiver::class.java)
                .setAction(action)
                .putExtra("start", depart)
                .putExtra("end", arrive)
                .putExtra("cat", cat)
                .putExtra("id", id)
            return PendingIntent.getBroadcast(
                ctx, id * 4 + code, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            )
        }
        val text = "${fmtTime(depart)} – ${fmtTime(arrive)} (${fmtDur(arrive - depart)}), $from → $to. " +
            "Add it to your timesheet?"
        val n = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_pm)
            .setColor(0xFF283890.toInt())
            .setContentTitle("Log that drive?")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .addAction(0, "Parts run", action(ACTION_LOG, PARTS_RUN, 1))
            .addAction(0, "Travel", action(ACTION_LOG, TRAVEL, 2))
            .addAction(0, "Don't log", action(ACTION_SKIP, null, 3))
            .build()
        nm.notify(id, n)
    }
}

/** Handles the buttons on the "Log that drive?" notification. */
class DriveReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val id = intent.getIntExtra("id", 0)
        ctx.getSystemService(NotificationManager::class.java).cancel(id)
        if (intent.action != Drives.ACTION_LOG) return
        val start = intent.getLongExtra("start", 0L)
        val end = intent.getLongExtra("end", 0L)
        val cat = intent.getStringExtra("cat") ?: return
        if (start <= 0L || end <= start) return
        Db.get(ctx).insertEntry(
            Entry(
                id = 0, siteId = null,
                label = if (cat == Drives.PARTS_RUN) "Parts run" else "Travel",
                lat = null, lng = null, start = start, end = end,
                ongoing = false, note = "", category = cat,
            )
        )
    }
}
