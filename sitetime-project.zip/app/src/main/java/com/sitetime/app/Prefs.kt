package com.sitetime.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import androidx.core.content.edit

object Prefs {
    private fun p(c: Context) = c.getSharedPreferences("settings", Context.MODE_PRIVATE)

    fun trackingEnabled(c: Context) = p(c).getBoolean("tracking", false)
    fun setTrackingEnabled(c: Context, v: Boolean) = p(c).edit { putBoolean("tracking", v) }

    /** Minutes you must stay in one place before it is logged. */
    fun minStayMin(c: Context) = p(c).getInt("minStay", 10)

    /** How far (metres) you can wander and still count as "the same place". */
    fun radiusM(c: Context) = p(c).getInt("radius", 150)

    /** How often to check location, in minutes. */
    fun intervalMin(c: Context) = p(c).getInt("interval", 2)

    fun highAccuracy(c: Context) = p(c).getBoolean("highAcc", false)

    /** Name printed on timesheets. Blank until the first-run prompt is answered. */
    fun name(c: Context) = p(c).getString("name", "") ?: ""
    fun setName(c: Context, v: String) = p(c).edit { putString("name", v.trim()) }

    /** Work type given to new stops at places that aren't saved sites. */
    fun defaultCategory(c: Context) = p(c).getString("defaultCat", "O") ?: "O"
    fun setDefaultCategory(c: Context, v: String) = p(c).edit { putString("defaultCat", v) }

    fun includeFriday(c: Context) = p(c).getBoolean("incFri", false)
    fun includeWeekend(c: Context) = p(c).getBoolean("incWknd", false)

    /** End-of-day reminder (minutes after midnight). Default 4:30 PM. */
    fun reminderOn(c: Context) = p(c).getBoolean("remindOn", true)
    fun reminderMin(c: Context) = p(c).getInt("remindMin", 16 * 60 + 30)
    fun lastReminderDay(c: Context) = p(c).getString("remindDay", "") ?: ""
    fun setLastReminderDay(c: Context, v: String) = p(c).edit { putString("remindDay", v) }

    /** No new places are logged after this time of day. Default 5:30 PM. */
    fun cutoffOn(c: Context) = p(c).getBoolean("cutoffOn", true)
    fun cutoffMin(c: Context) = p(c).getInt("cutoffMin", 17 * 60 + 30)

    /** Set by "Done for today": nothing is logged until this time (next morning). */
    fun pausedUntil(c: Context) = p(c).getLong("pausedUntil", 0L)
    fun setPausedUntil(c: Context, v: Long) = p(c).edit { putLong("pausedUntil", v) }

    /** Ask after each drive between work places whether to log it as a parts run or travel. */
    fun askDrives(c: Context) = p(c).getBoolean("askDrives", true)

    fun includeSignature(c: Context) = p(c).getBoolean("incSig", true)

    fun setInt(c: Context, key: String, v: Int) = p(c).edit { putInt(key, v) }
    fun setBool(c: Context, key: String, v: Boolean) = p(c).edit { putBoolean(key, v) }
}

object Perms {
    private fun granted(c: Context, p: String) =
        ContextCompat.checkSelfPermission(c, p) == PackageManager.PERMISSION_GRANTED

    fun hasLocation(c: Context) =
        granted(c, Manifest.permission.ACCESS_FINE_LOCATION) ||
            granted(c, Manifest.permission.ACCESS_COARSE_LOCATION)

    fun hasBackground(c: Context) =
        Build.VERSION.SDK_INT < 29 || granted(c, Manifest.permission.ACCESS_BACKGROUND_LOCATION)

    fun foregroundRequest(): Array<String> {
        val list = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
        )
        if (Build.VERSION.SDK_INT >= 33) list.add(Manifest.permission.POST_NOTIFICATIONS)
        return list.toTypedArray()
    }
}
