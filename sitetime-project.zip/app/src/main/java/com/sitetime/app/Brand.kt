package com.sitetime.app

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Text
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.shape.RoundedCornerShape

/** PRIME Mechanical of Wisconsin brand colours, taken from the logo. */
val PrimeNavy = Color(0xFF283890)
val PrimeRed = Color(0xFFEE1D24)
private val Ink = Color(0xFF1B2240)
private val Slate = Color(0xFF5B6280)
private val Mist = Color(0xFFF3F4F9)

private val LightColors = lightColorScheme(
    primary = PrimeNavy, onPrimary = Color.White,
    primaryContainer = Color(0xFFDDE1F5), onPrimaryContainer = Color(0xFF141C4D),
    secondary = Color(0xFF4A5285), onSecondary = Color.White,
    secondaryContainer = Color(0xFFE3E6F4), onSecondaryContainer = Ink,
    tertiary = PrimeRed, onTertiary = Color.White,
    tertiaryContainer = Color(0xFFFDE4E5), onTertiaryContainer = Color(0xFF5C0A0D),
    error = Color(0xFFC4161C), onError = Color.White,
    errorContainer = Color(0xFFFDE4E5), onErrorContainer = Color(0xFF5C0A0D),
    background = Mist, onBackground = Ink,
    surface = Mist, onSurface = Ink,
    surfaceVariant = Color(0xFFE4E7F2), onSurfaceVariant = Slate,
    outline = Color(0xFFB7BCD3), outlineVariant = Color(0xFFDDE0EC),
    surfaceContainerLowest = Color.White, surfaceContainerLow = Color.White,
    surfaceContainer = Color.White, surfaceContainerHigh = Color.White,
    surfaceContainerHighest = Color.White,
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFB9C3FF), onPrimary = Color(0xFF0F1A5E),
    primaryContainer = PrimeNavy, onPrimaryContainer = Color.White,
    secondary = Color(0xFFC1C6E6), onSecondary = Color(0xFF232A4E),
    secondaryContainer = Color(0xFF2C3359), onSecondaryContainer = Color(0xFFE3E6F4),
    tertiary = Color(0xFFFF8A8E), onTertiary = Color(0xFF5C0A0D),
    tertiaryContainer = Color(0xFF5C1518), onTertiaryContainer = Color(0xFFFFDADB),
    error = Color(0xFFFF8A8E), onError = Color(0xFF5C0A0D),
    errorContainer = Color(0xFF5C1518), onErrorContainer = Color(0xFFFFDADB),
    background = Color(0xFF10142B), onBackground = Color(0xFFE3E5F3),
    surface = Color(0xFF10142B), onSurface = Color(0xFFE3E5F3),
    surfaceVariant = Color(0xFF2A3052), onSurfaceVariant = Color(0xFFA9AECB),
    outline = Color(0xFF565C80), outlineVariant = Color(0xFF2E3458),
    surfaceContainerLowest = Color(0xFF0B0F22), surfaceContainerLow = Color(0xFF161B36),
    surfaceContainer = Color(0xFF181D3A), surfaceContainerHigh = Color(0xFF1E2444),
    surfaceContainerHighest = Color(0xFF1E2444),
)

private val BrandType = Typography().let { t ->
    t.copy(
        displaySmall = t.displaySmall.copy(fontWeight = FontWeight.Bold, letterSpacing = (-0.5).sp),
        headlineSmall = t.headlineSmall.copy(fontWeight = FontWeight.Bold),
        titleLarge = t.titleLarge.copy(fontWeight = FontWeight.Bold),
        titleMedium = t.titleMedium.copy(fontWeight = FontWeight.SemiBold),
        titleSmall = t.titleSmall.copy(fontWeight = FontWeight.Bold),
        labelLarge = t.labelLarge.copy(fontWeight = FontWeight.SemiBold),
    )
}

private val BrandShapes = Shapes(
    small = RoundedCornerShape(6.dp),
    medium = RoundedCornerShape(10.dp),
    large = RoundedCornerShape(14.dp),
)

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) DarkColors else LightColors,
        typography = BrandType,
        shapes = BrandShapes,
        content = content,
    )
}

/** The logo's two red lines: the app's signature mark. */
@Composable
fun DoubleRule(modifier: Modifier = Modifier, thickness: Int = 3) {
    Column(modifier.fillMaxWidth()) {
        Spacer(Modifier.fillMaxWidth().height(thickness.dp).background(PrimeRed))
        Spacer(Modifier.height(thickness.dp))
        Spacer(Modifier.fillMaxWidth().height(thickness.dp).background(PrimeRed))
    }
}

@Composable
fun BrandHeader() {
    val dark = isSystemInDarkTheme()
    Column(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceContainerLowest)) {
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().padding(start = 20.dp, end = 20.dp, top = 14.dp, bottom = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Image(
                painterResource(R.drawable.prime_logo),
                contentDescription = "PRIME Mechanical of Wisconsin",
                modifier = Modifier.height(30.dp),
                colorFilter = if (dark) ColorFilter.tint(Color.White) else null,
            )
            Spacer(Modifier.weight(1f).width(8.dp))
            Text(
                "Site Time",
                style = TextStyle(fontSize = 13.sp, fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        DoubleRule(thickness = 2)
    }
}
