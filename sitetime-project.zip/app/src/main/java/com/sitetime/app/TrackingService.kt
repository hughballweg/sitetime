package com.sitetime.app

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority

class TrackingService : Service() {

    companion object {
        private const val CHANNEL = "tracking"
        private const val REMIND_CHANNEL = "reminders"
        private const val NOTIF_ID = 1
        private const val REMIND_ID = 2
        const val ACTION_DONE = "com.sitetime.app.DONE"
        const val ACTION_CONTINUE = "com.sitetime.app.CONTINUE"
        const val ACTION_RESUME = "com.sitetime.app.RESUME"

        /** Sends "Done for today" / "Resume" to the running service. */
        fun send(ctx: Context, action: String) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, TrackingService::class.java).setAction(action))
        }

        /** Starts tracking, or re-applies settings if it's already running. */
        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, TrackingService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, TrackingService::class.java))
        }
    }

    private lateinit var fused: FusedLocationProviderClient
    private lateinit var detector: StayDetector

    private val callback = object : LocationCallback() {
        override fun onLocationResult(result: LocationResult) {
            for (loc in result.locations) {
                detector.onLocation(loc.latitude, loc.longitude, loc.accuracy, loc.time)
            }
            getSystemService(NotificationManager::class.java)
                .notify(NOTIF_ID, buildNotification(detector.status()))
            maybeRemind()
        }
    }

    override fun onCreate() {
        super.onCreate()
        fused = LocationServices.getFusedLocationProviderClient(this)
        detector = StayDetector(this)
        Db.get(this).closeStaleOngoing(detector.activeId)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Location tracking", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(REMIND_CHANNEL, "End-of-day reminder", NotificationManager.IMPORTANCE_HIGH)
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            ServiceCompat.startForeground(
                this, NOTIF_ID, buildNotification(detector.status()),
                if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION else 0,
            )
        } catch (e: Exception) {
            // Usually: no location permission, or Android refused a background start.
            stopSelf()
            return START_NOT_STICKY
        }
        val nm = getSystemService(NotificationManager::class.java)
        when (intent?.action) {
            ACTION_DONE -> {
                detector.endDay(System.currentTimeMillis())
                nm.cancel(REMIND_ID)
            }
            ACTION_CONTINUE -> nm.cancel(REMIND_ID)
            ACTION_RESUME -> detector.resume()
        }
        nm.notify(NOTIF_ID, buildNotification(detector.status()))
        if (!requestUpdates()) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    @SuppressLint("MissingPermission")
    private fun requestUpdates(): Boolean {
        if (!Perms.hasLocation(this)) return false
        val intervalMs = Prefs.intervalMin(this) * 60_000L
        val priority = if (Prefs.highAccuracy(this)) Priority.PRIORITY_HIGH_ACCURACY
        else Priority.PRIORITY_BALANCED_POWER_ACCURACY
        val request = LocationRequest.Builder(priority, intervalMs)
            .setMinUpdateIntervalMillis(intervalMs / 2)
            .build()
        return try {
            fused.removeLocationUpdates(callback)
            fused.requestLocationUpdates(request, callback, Looper.getMainLooper())
            true
        } catch (e: SecurityException) {
            false
        }
    }

    /** Once a day, at the reminder time, if you've worked today and haven't tapped "Done" yet. */
    private fun maybeRemind() {
        if (!Prefs.reminderOn(this)) return
        val now = java.time.ZonedDateTime.now()
        val today = now.toLocalDate()
        if (Prefs.lastReminderDay(this) == today.toString()) return
        if (now.hour * 60 + now.minute < Prefs.reminderMin(this)) return
        if (System.currentTimeMillis() < Prefs.pausedUntil(this)) return
        val start = today.atStartOfDay(now.zone).toInstant().toEpochMilli()
        val todays = Db.get(this).entriesBetween(start, today.plusDays(1).atStartOfDay(now.zone).toInstant().toEpochMilli())
        if (todays.isEmpty()) return // day off: no reminder
        Prefs.setLastReminderDay(this, today.toString())

        val current = todays.lastOrNull { it.ongoing }
        val total = todays.sumOf { it.end - it.start }
        val text = (current?.let { "At ${it.label} since ${fmtTime(it.start)}. " } ?: "") +
            "${fmtDur(total)} logged today. Tap Done when you leave work."
        fun action(a: String, code: Int) = PendingIntent.getForegroundService(
            this, code, Intent(this, TrackingService::class.java).setAction(a),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val open = PendingIntent.getActivity(
            this, 3, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val n = NotificationCompat.Builder(this, REMIND_CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_pm)
            .setColor(0xFF283890.toInt())
            .setContentTitle("Wrapping up for the day?")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(open)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .addAction(0, "Done for today", action(ACTION_DONE, 10))
            .addAction(0, "Still working", action(ACTION_CONTINUE, 11))
            .build()
        getSystemService(NotificationManager::class.java).notify(REMIND_ID, n)
    }

    private fun buildNotification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_pm)
            .setColor(0xFF283890.toInt())
            .setContentTitle("Site Time is tracking")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    override fun onDestroy() {
        fused.removeLocationUpdates(callback)
        // Only close the current stay if the user actually switched tracking off.
        if (!Prefs.trackingEnabled(this)) detector.stop()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
