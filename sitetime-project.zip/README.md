# Site Time

Android app that logs a timesheet from where you go. While tracking is on, it
checks location every few minutes; any place you stay for the set time (default
10 min, within 150 m) becomes a timesheet entry from arrival to departure.

- New places appear as "Unnamed stop". Tap to name them; tick "Save as a site"
  so future visits are named automatically.
- "Ignore this place" (e.g. home) stops it from ever being logged.
- Edit or add entries by hand, browse by week, export CSV.
- All data stays on the phone (SQLite). No accounts, no servers.

Build: Kotlin + Jetpack Compose, AGP 8.7, Gradle 8.9, minSdk 26 (Android 8+).
`gradle assembleDebug` produces app/build/outputs/apk/debug/app-debug.apk.
The included app/debug.keystore keeps the signature stable so updates install
over the previous version without losing data.

## Timesheet export
The Timesheet button fills in the company form (app/src/main/assets/timesheet_template.xlsx,
built from MENS_TIMESHEET.xlsx with Sat/Sun added on page 3) with your name, the week-starting
Monday, start/stop times in decimal hours using the form's 6-minute rounding, hours per work-type
column, breaks, and notes. Friday and Sat/Sun can be included or left off each time. "Print / PDF"
opens Android's print dialog, which can also save a PDF.

## End of day
A reminder at 4:30 PM (changeable) offers "Done for today", which ends the current stop and
logs nothing more until 4:00 AM. New places aren't logged after the cutoff (default 5:30 PM).
Driving time is never logged. Mark home, church, etc. as ignored places (add them by address).

## Editing and signing
"Review / edit sheet" edits exactly what goes on the form, per day. Edited days stay as you
saved them until you tap "Undo edits". "Sign timesheet" captures a finger signature that is
placed on the SIGN HERE line in both the Excel file and the printout.

## Branding
PRIME Mechanical of Wisconsin: navy #283890 and red #EE1D24 from the logo. The logo heads every
screen with the logo's double red rule beneath it. App icon set (incl. round and monochrome themed
icon) in res/mipmap-*; status-bar icon res/drawable-*/ic_stat_pm.png is cut from the monochrome layer.
