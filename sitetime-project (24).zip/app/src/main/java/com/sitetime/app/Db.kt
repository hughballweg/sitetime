package com.sitetime.app

import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import androidx.core.content.contentValuesOf
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update

class Db private constructor(ctx: Context) : SQLiteOpenHelper(ctx, "sitetime.db", null, 10) {

    companion object {
        @Volatile
        private var instance: Db? = null

        fun get(ctx: Context): Db =
            instance ?: synchronized(this) {
                instance ?: Db(ctx.applicationContext).also { instance = it }
            }

        /** Bumped on every write so the UI knows to reload. */
        val changes = MutableStateFlow(0)

        private const val ECOLS = "id, site_id, label, lat, lng, start_ms, end_ms, ongoing, note, category, break_min, errand, place_kind"
        private const val DCOLS = "id, start_ms, end_ms, from_label, to_label, status, entry_id, job, errand_id"
        private const val BREAKS_TABLE =
            "CREATE TABLE IF NOT EXISTS day_breaks (day TEXT PRIMARY KEY, minutes INTEGER NOT NULL)"
        private const val SHEETS_TABLE =
            "CREATE TABLE IF NOT EXISTS day_sheets (day TEXT PRIMARY KEY, json TEXT NOT NULL)"
        private const val DRIVES_TABLE =
            "CREATE TABLE IF NOT EXISTS drives (id INTEGER PRIMARY KEY AUTOINCREMENT, start_ms INTEGER NOT NULL, " +
                "end_ms INTEGER NOT NULL, from_label TEXT NOT NULL, to_label TEXT NOT NULL, " +
                "status INTEGER NOT NULL DEFAULT 0, entry_id INTEGER, job TEXT)"
        private const val NOTES_TABLE =
            "CREATE TABLE IF NOT EXISTS day_notes (day TEXT PRIMARY KEY, note TEXT NOT NULL)"
        private const val SCOLS = "id, name, lat, lng, radius, ignored, category, morning_travel"
        /** Every location fix while tracking, for the map's route line. */
        private const val FIXES_TABLE =
            "CREATE TABLE IF NOT EXISTS fixes (t INTEGER PRIMARY KEY, lat REAL NOT NULL, lng REAL NOT NULL, acc REAL NOT NULL)"
        /** Whether an unnamed stop has been checked for a business name (see [Places]). */
        private const val LOOKED_UP_COLUMN = "ALTER TABLE entries ADD COLUMN looked_up INTEGER NOT NULL DEFAULT 0"
        /** Short stops waiting for "parts run or lunch?", and what kind of place they were (v10). */
        private val ERRAND_COLUMNS = listOf(
            "ALTER TABLE entries ADD COLUMN errand INTEGER NOT NULL DEFAULT 0",
            "ALTER TABLE entries ADD COLUMN place_kind TEXT",
            "ALTER TABLE drives ADD COLUMN errand_id INTEGER",
        )
        /** How long location history is kept. */
        private const val FIX_KEEP_DAYS = 180L
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE sites (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, " +
                "lat REAL NOT NULL, lng REAL NOT NULL, radius REAL NOT NULL, ignored INTEGER NOT NULL DEFAULT 0, category TEXT, " +
                "morning_travel INTEGER NOT NULL DEFAULT 0)"
        )
        db.execSQL(
            "CREATE TABLE entries (id INTEGER PRIMARY KEY AUTOINCREMENT, site_id INTEGER, label TEXT NOT NULL, " +
                "lat REAL, lng REAL, start_ms INTEGER NOT NULL, end_ms INTEGER NOT NULL, " +
                "ongoing INTEGER NOT NULL DEFAULT 0, note TEXT NOT NULL DEFAULT '', " +
                "category TEXT, break_min INTEGER NOT NULL DEFAULT 0)"
        )
        db.execSQL("CREATE INDEX entries_start ON entries(start_ms)")
        db.execSQL(BREAKS_TABLE)
        db.execSQL(SHEETS_TABLE)
        db.execSQL(DRIVES_TABLE)
        db.execSQL(NOTES_TABLE)
        db.execSQL(FIXES_TABLE)
        db.execSQL(LOOKED_UP_COLUMN)
        ERRAND_COLUMNS.forEach { db.execSQL(it) }
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE sites ADD COLUMN category TEXT")
            db.execSQL("ALTER TABLE entries ADD COLUMN category TEXT")
            db.execSQL("ALTER TABLE entries ADD COLUMN break_min INTEGER NOT NULL DEFAULT 0")
        }
        if (oldVersion < 3) db.execSQL(BREAKS_TABLE)
        if (oldVersion < 4) db.execSQL(SHEETS_TABLE)
        if (oldVersion < 5) {
            db.execSQL(DRIVES_TABLE)
            db.execSQL(NOTES_TABLE)
            // Hand-edited sheet copies froze a day and hid later changes; the sheet is now built
            // from your entries every time, so retire those copies.
            db.execSQL("DELETE FROM day_sheets")
        }
        if (oldVersion < 6) db.execSQL("ALTER TABLE sites ADD COLUMN morning_travel INTEGER NOT NULL DEFAULT 0")
        if (oldVersion < 7) {
            if (oldVersion >= 5) db.execSQL("ALTER TABLE drives ADD COLUMN job TEXT")
            // "Drive to X" entries become "Parts run for X" / "Travel for X"
            db.execSQL("UPDATE entries SET label = 'Parts run for ' || substr(label, 10) WHERE label LIKE 'Drive to %' AND category = 'R'")
            db.execSQL("UPDATE entries SET label = 'Travel for ' || substr(label, 10) WHERE label LIKE 'Drive to %' AND category = 'S'")
        }
        if (oldVersion < 8) db.execSQL(FIXES_TABLE)
        if (oldVersion < 9) db.execSQL(LOOKED_UP_COLUMN)
        if (oldVersion < 10) ERRAND_COLUMNS.forEach { db.execSQL(it) }
    }

    private fun bump() = changes.update { it + 1 }

    /** Lets screens refresh after changes that aren't database writes (e.g. pausing). */
    fun touch() = bump()

    // ---------- Drives ----------

    private fun Cursor.toDrive() = Drive(
        id = getLong(0), start = getLong(1), end = getLong(2), from = getString(3), to = getString(4),
        status = getInt(5), entryId = if (isNull(6)) null else getLong(6), job = if (isNull(7)) null else getString(7),
        errandId = if (isNull(8)) null else getLong(8),
    )

    fun addDrive(start: Long, end: Long, from: String, to: String, job: String? = null): Long =
        writableDatabase.insert(
            "drives", null,
            contentValuesOf(
                "start_ms" to start, "end_ms" to end, "from_label" to from, "to_label" to to,
                "status" to Drive.PENDING, "job" to job,
            ),
        ).also { bump() }

    /**
     * Drives still waiting for you to log or skip them, newest first. Drives to and from a short stop
     * that's waiting for "parts run or lunch?" are left out: they're answered along with the stop.
     */
    fun pendingDrives(): List<Drive> =
        readableDatabase.rawQuery(
            "SELECT $DCOLS FROM drives WHERE status = ? AND (errand_id IS NULL OR errand_id NOT IN " +
                "(SELECT id FROM entries WHERE errand > 0)) ORDER BY start_ms DESC",
            arrayOf(Drive.PENDING.toString()),
        ).use { c -> buildList { while (c.moveToNext()) add(c.toDrive()) } }

    /** The drives to and from a short stop. */
    fun drivesForErrand(entryId: Long): List<Drive> =
        readableDatabase.rawQuery(
            "SELECT $DCOLS FROM drives WHERE errand_id = ? ORDER BY start_ms", arrayOf(entryId.toString()),
        ).use { c -> buildList { while (c.moveToNext()) add(c.toDrive()) } }

    fun setDriveErrand(driveId: Long, entryId: Long) {
        writableDatabase.update(
            "drives", contentValuesOf("errand_id" to entryId), "id = ?", arrayOf(driveId.toString()),
        )
        bump()
    }

    fun setErrand(entryId: Long, state: Int) {
        writableDatabase.update(
            "entries", contentValuesOf("errand" to state), "id = ?", arrayOf(entryId.toString()),
        )
        bump()
    }

    /** Short stops you've left that are waiting for "parts run or lunch?", newest first. */
    fun pendingErrands(): List<Entry> =
        readableDatabase.rawQuery(
            "SELECT $ECOLS FROM entries WHERE errand = ? ORDER BY start_ms DESC", arrayOf(ERRAND_ASK.toString()),
        ).use { c -> buildList { while (c.moveToNext()) add(c.toEntry()) } }

    /** Names to suggest while typing a job: saved sites first, then names you've used before. */
    fun knownJobNames(): List<String> {
        val names = LinkedHashMap<String, String>()
        sites().filter { !it.ignored }.forEach { names.putIfAbsent(it.name.lowercase(), it.name) }
        readableDatabase.rawQuery(
            "SELECT label FROM entries GROUP BY label ORDER BY MAX(start_ms) DESC LIMIT 300", null,
        ).use { c ->
            while (c.moveToNext()) {
                val raw = c.getString(0)
                val l = jobOf(raw)
                if (l != UNNAMED && l.isNotBlank() && !raw.startsWith(LUNCH_PREFIX)) names.putIfAbsent(l.lowercase(), l)
            }
        }
        return names.values.toList()
    }

    fun drive(id: Long): Drive? =
        readableDatabase.rawQuery(
            "SELECT $DCOLS FROM drives WHERE id = ?",
            arrayOf(id.toString()),
        ).use { c -> if (c.moveToFirst()) c.toDrive() else null }

    fun drivesBetween(from: Long, to: Long): List<Drive> =
        readableDatabase.rawQuery(
            "SELECT $DCOLS FROM drives WHERE start_ms >= ? AND start_ms < ? ORDER BY start_ms",
            arrayOf(from.toString(), to.toString()),
        ).use { c -> buildList { while (c.moveToNext()) add(c.toDrive()) } }

    fun setDriveStatus(id: Long, status: Int, entryId: Long?) {
        writableDatabase.update(
            "drives", contentValuesOf("status" to status, "entry_id" to entryId),
            "id = ?", arrayOf(id.toString()),
        )
        bump()
    }

    // ---------- Day notes ----------

    fun notesBetween(from: java.time.LocalDate, to: java.time.LocalDate): Map<java.time.LocalDate, String> =
        readableDatabase.rawQuery(
            "SELECT day, note FROM day_notes WHERE day >= ? AND day < ?",
            arrayOf(from.toString(), to.toString()),
        ).use { c ->
            buildMap { while (c.moveToNext()) put(java.time.LocalDate.parse(c.getString(0)), c.getString(1)) }
        }

    fun setDayNote(day: java.time.LocalDate, note: String) {
        if (note.isBlank()) {
            writableDatabase.delete("day_notes", "day = ?", arrayOf(day.toString()))
        } else {
            writableDatabase.insertWithOnConflict(
                "day_notes", null, contentValuesOf("day" to day.toString(), "note" to note),
                SQLiteDatabase.CONFLICT_REPLACE,
            )
        }
        bump()
    }

    /** Adds a line to the day's notes (once), e.g. "Parts run to Menards for Shop". */
    fun appendDayNote(day: java.time.LocalDate, line: String) {
        val old = notesBetween(day, day.plusDays(1))[day].orEmpty().trim()
        if (old.split("; ").any { it == line }) return
        setDayNote(day, if (old.isBlank()) line else "$old; $line")
    }

    /** A parts run was changed: keep the line it added to the day's notes in step. */
    fun replaceInDayNote(day: java.time.LocalDate, oldLine: String, newLine: String) {
        val old = notesBetween(day, day.plusDays(1))[day] ?: return
        val parts = old.split("; ")
        if (oldLine !in parts) return
        setDayNote(day, parts.map { if (it == oldLine) newLine else it }.distinct().joinToString("; "))
    }

    // ---------- Hand-edited timesheet days (no longer used; kept so old databases open) ----------

    fun sheetsBetween(from: java.time.LocalDate, to: java.time.LocalDate): Map<java.time.LocalDate, String> =
        readableDatabase.rawQuery(
            "SELECT day, json FROM day_sheets WHERE day >= ? AND day < ?",
            arrayOf(from.toString(), to.toString()),
        ).use { c ->
            buildMap { while (c.moveToNext()) put(java.time.LocalDate.parse(c.getString(0)), c.getString(1)) }
        }

    /** Save a hand-edited day, or pass null to go back to the tracked data. */
    fun setSheet(day: java.time.LocalDate, json: String?) {
        if (json == null) {
            writableDatabase.delete("day_sheets", "day = ?", arrayOf(day.toString()))
        } else {
            writableDatabase.insertWithOnConflict(
                "day_sheets", null, contentValuesOf("day" to day.toString(), "json" to json),
                SQLiteDatabase.CONFLICT_REPLACE,
            )
        }
        bump()
    }

    // ---------- Sites ----------

    private fun Cursor.toSite() = Site(
        id = getLong(0), name = getString(1), lat = getDouble(2), lng = getDouble(3),
        radius = getDouble(4), ignored = getInt(5) != 0,
        category = if (isNull(6)) null else getString(6),
        morningTravel = getInt(7) != 0,
    )

    fun sites(): List<Site> =
        readableDatabase.rawQuery("SELECT $SCOLS FROM sites ORDER BY ignored, name COLLATE NOCASE", null)
            .use { c -> buildList { while (c.moveToNext()) add(c.toSite()) } }

    fun site(id: Long): Site? =
        readableDatabase.rawQuery("SELECT $SCOLS FROM sites WHERE id = ?", arrayOf(id.toString()))
            .use { c -> if (c.moveToFirst()) c.toSite() else null }

    fun addSite(
        name: String, lat: Double, lng: Double, radius: Double, ignored: Boolean, category: String? = null,
        morningTravel: Boolean = false,
    ): Long =
        writableDatabase.insert(
            "sites", null,
            contentValuesOf(
                "name" to name, "lat" to lat, "lng" to lng,
                "radius" to radius, "ignored" to if (ignored) 1 else 0, "category" to category,
                "morning_travel" to if (morningTravel) 1 else 0,
            ),
        ).also { bump() }

    fun updateSite(s: Site) {
        val db = writableDatabase
        db.update(
            "sites",
            contentValuesOf(
                "name" to s.name, "radius" to s.radius, "ignored" to if (s.ignored) 1 else 0, "category" to s.category,
                "morning_travel" to if (s.morningTravel) 1 else 0, "lat" to s.lat, "lng" to s.lng,
            ),
            "id = ?", arrayOf(s.id.toString()),
        )
        db.update("entries", contentValuesOf("label" to s.name), "site_id = ?", arrayOf(s.id.toString()))
        bump()
    }

    fun deleteSite(id: Long) {
        val db = writableDatabase
        db.delete("sites", "id = ?", arrayOf(id.toString()))
        db.update("entries", contentValuesOf("site_id" to null), "site_id = ?", arrayOf(id.toString()))
        bump()
    }

    /** The closest saved site whose radius contains this point, if any. */
    fun findSiteFor(lat: Double, lng: Double): Site? =
        sites()
            .map { it to distanceM(lat, lng, it.lat, it.lng) }
            .filter { (s, d) -> d <= s.radius }
            .minByOrNull { it.second }
            ?.first

    /** Names (or, for ignored places, removes) unnamed stops that fall inside this site. */
    fun assignUnnamedNear(site: Site) {
        val db = writableDatabase
        val unnamed = db.rawQuery(
            "SELECT $ECOLS FROM entries WHERE site_id IS NULL AND lat IS NOT NULL AND label = ?",
            arrayOf(UNNAMED),
        ).use { c -> buildList { while (c.moveToNext()) add(c.toEntry()) } }
        for (e in unnamed) {
            val lat = e.lat ?: continue
            val lng = e.lng ?: continue
            if (distanceM(site.lat, site.lng, lat, lng) > site.radius) continue
            if (site.ignored) {
                db.delete("entries", "id = ?", arrayOf(e.id.toString()))
            } else {
                val values = contentValuesOf("site_id" to site.id, "label" to site.name)
                if (site.category != null) values.put("category", site.category)
                db.update("entries", values, "id = ?", arrayOf(e.id.toString()))
                renameDrivesInto(db, e.label, site.name, e.start)
            }
        }
        bump()
    }

    // ---------- Daily breaks ----------

    /** Break minutes per day, for days from [from] up to (not including) [to]. */
    /** Sets the day's break to at least [minutes] (a lunch you logged). */
    fun breakAtLeast(day: java.time.LocalDate, minutes: Int) {
        val cur = breaksBetween(day, day.plusDays(1))[day] ?: 0
        if (minutes > cur) setBreak(day, minutes)
    }

    fun breaksBetween(from: java.time.LocalDate, to: java.time.LocalDate): Map<java.time.LocalDate, Int> =
        readableDatabase.rawQuery(
            "SELECT day, minutes FROM day_breaks WHERE day >= ? AND day < ?",
            arrayOf(from.toString(), to.toString()),
        ).use { c ->
            buildMap { while (c.moveToNext()) put(java.time.LocalDate.parse(c.getString(0)), c.getInt(1)) }
        }

    fun setBreak(day: java.time.LocalDate, minutes: Int) {
        if (minutes <= 0) {
            writableDatabase.delete("day_breaks", "day = ?", arrayOf(day.toString()))
        } else {
            writableDatabase.insertWithOnConflict(
                "day_breaks", null, contentValuesOf("day" to day.toString(), "minutes" to minutes),
                SQLiteDatabase.CONFLICT_REPLACE,
            )
        }
        bump()
    }

    // ---------- Entries ----------

    private fun Cursor.toEntry() = Entry(
        id = getLong(0),
        siteId = if (isNull(1)) null else getLong(1),
        label = getString(2),
        lat = if (isNull(3)) null else getDouble(3),
        lng = if (isNull(4)) null else getDouble(4),
        start = getLong(5),
        end = getLong(6),
        ongoing = getInt(7) != 0,
        note = getString(8),
        category = if (isNull(9)) null else getString(9),
        breakMin = getInt(10),
        errand = getInt(11),
        placeKind = if (isNull(12)) null else getString(12),
    )

    private fun Entry.values() = contentValuesOf(
        "site_id" to siteId, "label" to label, "lat" to lat, "lng" to lng,
        "start_ms" to start, "end_ms" to end, "ongoing" to if (ongoing) 1 else 0, "note" to note,
        "category" to category, "break_min" to breakMin, "errand" to errand, "place_kind" to placeKind,
    )

    /** Entries that start within [from, to). */
    fun entriesBetween(from: Long, to: Long): List<Entry> =
        readableDatabase.rawQuery(
            "SELECT $ECOLS FROM entries WHERE start_ms >= ? AND start_ms < ? ORDER BY start_ms",
            arrayOf(from.toString(), to.toString()),
        ).use { c -> buildList { while (c.moveToNext()) add(c.toEntry()) } }

    fun allEntries(): List<Entry> =
        readableDatabase.rawQuery("SELECT $ECOLS FROM entries ORDER BY start_ms", null)
            .use { c -> buildList { while (c.moveToNext()) add(c.toEntry()) } }

    fun entry(id: Long): Entry? =
        readableDatabase.rawQuery("SELECT $ECOLS FROM entries WHERE id = ?", arrayOf(id.toString()))
            .use { c -> if (c.moveToFirst()) c.toEntry() else null }

    /** The job you arrived at when a drive ended (its stop starts exactly when the drive ends). */
    fun arrivalEntry(arriveMs: Long): Entry? =
        readableDatabase.rawQuery(
            "SELECT $ECOLS FROM entries WHERE start_ms = ? AND label NOT LIKE ? AND label NOT LIKE ? " +
                "AND label NOT LIKE ? AND label NOT LIKE ? ORDER BY id LIMIT 1",
            arrayOf(arriveMs.toString(), "$DRIVE_PREFIX%", "$PARTS_PREFIX%", "$TRAVEL_PREFIX%", "$ERRAND_PREFIX%"),
        ).use { c -> if (c.moveToFirst()) c.toEntry() else null }

    /** When a job is named or renamed, travel into it follows ("Travel for Unnamed stop" -> "Travel for Thoreau"). */
    private fun renameDrivesInto(db: SQLiteDatabase, oldLabel: String, newLabel: String, arriveMs: Long) {
        val driveLike = listOf(PARTS_PREFIX, TRAVEL_PREFIX, DRIVE_PREFIX, ERRAND_PREFIX, LUNCH_PREFIX)
        if (oldLabel == newLabel || driveLike.any { oldLabel.startsWith(it) || newLabel.startsWith(it) }) return
        for (p in TRAVEL_PREFIXES) {
            db.update(
                "entries", contentValuesOf("label" to p + newLabel),
                "label = ? AND end_ms = ?", arrayOf(p + oldLabel, arriveMs.toString()),
            )
        }
        // Parts runs that day for this job follow too ("Parts run to Menards for Unnamed stop" -> "... for Thoreau").
        val zone = java.time.ZoneId.systemDefault()
        val day = arriveMs.toLocalDate()
        val from = day.atStartOfDay(zone).toInstant().toEpochMilli()
        val to = day.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli()
        val runs = db.rawQuery(
            "SELECT id, label FROM entries WHERE label LIKE ? AND start_ms >= ? AND start_ms < ?",
            arrayOf("$ERRAND_PREFIX%", from.toString(), to.toString()),
        ).use { c -> buildList { while (c.moveToNext()) add(c.getLong(0) to c.getString(1)) } }
        for ((id, label) in runs) {
            if (jobOf(label) != oldLabel) continue
            val renamed = errandLabel(errandPlaceOf(label), newLabel)
            db.update("entries", contentValuesOf("label" to renamed), "id = ?", arrayOf(id.toString()))
            val notes = notesBetween(day, day.plusDays(1))[day]
            if (notes != null) {
                val parts = notes.split("; ").map { if (it == label) renamed else it }
                db.update("day_notes", contentValuesOf("note" to parts.joinToString("; ")), "day = ?", arrayOf(day.toString()))
            }
        }
    }

    fun insertEntry(e: Entry): Long =
        writableDatabase.insert("entries", null, e.values()).also { bump() }

    fun updateEntry(e: Entry) {
        val old = entry(e.id)
        val db = writableDatabase
        db.update("entries", e.values(), "id = ?", arrayOf(e.id.toString()))
        if (old != null) renameDrivesInto(db, old.label, e.label, old.start)
        bump()
    }

    fun deleteEntry(id: Long) {
        val db = writableDatabase
        db.delete("entries", "id = ?", arrayOf(id.toString()))
        // A logged drive whose entry was deleted goes back to "not logged".
        db.update(
            "drives", contentValuesOf("status" to Drive.SKIPPED, "entry_id" to null),
            "entry_id = ?", arrayOf(id.toString()),
        )
        bump()
    }

    fun setEntryEnd(id: Long, end: Long, ongoing: Boolean) {
        writableDatabase.update(
            "entries", contentValuesOf("end_ms" to end, "ongoing" to if (ongoing) 1 else 0),
            "id = ?", arrayOf(id.toString()),
        )
        bump()
    }

    /** Marks any "ongoing" stop as finished, except the one currently being tracked. */
    // ---------- Location history ----------

    /** Saves one location fix (no screen refresh: the map reloads when you open it or change day). */
    fun addFix(t: Long, lat: Double, lng: Double, acc: Float) {
        writableDatabase.insertWithOnConflict(
            "fixes", null, contentValuesOf("t" to t, "lat" to lat, "lng" to lng, "acc" to acc.toDouble()),
            SQLiteDatabase.CONFLICT_REPLACE,
        )
    }

    fun fixesBetween(from: Long, to: Long): List<Fix> =
        readableDatabase.rawQuery(
            "SELECT t, lat, lng, acc FROM fixes WHERE t >= ? AND t < ? ORDER BY t",
            arrayOf(from.toString(), to.toString()),
        ).use { c -> buildList { while (c.moveToNext()) add(Fix(c.getLong(0), c.getDouble(1), c.getDouble(2), c.getFloat(3))) } }

    /** The most recent fix, to centre the map on a day with no history. */
    fun lastFix(): Fix? =
        readableDatabase.rawQuery("SELECT t, lat, lng, acc FROM fixes ORDER BY t DESC LIMIT 1", null)
            .use { c -> if (c.moveToFirst()) Fix(c.getLong(0), c.getDouble(1), c.getDouble(2), c.getFloat(3)) else null }

    // ---------- Business names for unnamed stops ----------

    /** Unnamed stops in the range that haven't been checked for a business name yet, newest first. */
    fun unnamedToLookUp(from: Long, to: Long): List<Entry> =
        readableDatabase.rawQuery(
            "SELECT $ECOLS FROM entries WHERE start_ms >= ? AND start_ms < ? AND label = ? " +
                "AND lat IS NOT NULL AND lng IS NOT NULL AND looked_up = 0 ORDER BY start_ms DESC",
            arrayOf(from.toString(), to.toString(), UNNAMED),
        ).use { c -> buildList { while (c.moveToNext()) add(c.toEntry()) } }

    /** Marks a stop as checked, and names it after the business there (unless you've named it since). */
    fun setLookedUp(id: Long, business: String?, kind: String? = null) {
        val w = writableDatabase
        w.update("entries", contentValuesOf("looked_up" to 1, "place_kind" to kind), "id = ?", arrayOf(id.toString()))
        if (!business.isNullOrBlank()) {
            w.update("entries", contentValuesOf("label" to business), "id = ? AND label = ?", arrayOf(id.toString(), UNNAMED))
        }
        bump()
    }

    fun hasFixes(from: Long, to: Long): Boolean =
        readableDatabase.rawQuery(
            "SELECT 1 FROM fixes WHERE t >= ? AND t < ? LIMIT 1", arrayOf(from.toString(), to.toString()),
        ).use { it.moveToFirst() }

    /**
     * Deletes everything for one day: stops, drives and travel entries, break, notes, and (unless
     * [keepHistory]) the saved location history. Returns the ids of the drives removed.
     */
    fun deleteDay(day: java.time.LocalDate, keepHistory: Boolean): List<Long> {
        val zone = java.time.ZoneId.systemDefault()
        val from = day.atStartOfDay(zone).toInstant().toEpochMilli().toString()
        val to = day.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli().toString()
        val driveIds = drivesBetween(from.toLong(), to.toLong()).map { it.id }
        val w = writableDatabase
        w.beginTransaction()
        try {
            w.delete("entries", "start_ms >= ? AND start_ms < ?", arrayOf(from, to))
            w.delete("drives", "start_ms >= ? AND start_ms < ?", arrayOf(from, to))
            w.delete("day_breaks", "day = ?", arrayOf(day.toString()))
            w.delete("day_notes", "day = ?", arrayOf(day.toString()))
            if (!keepHistory) w.delete("fixes", "t >= ? AND t < ?", arrayOf(from, to))
            w.setTransactionSuccessful()
        } finally {
            w.endTransaction()
        }
        bump()
        return driveIds
    }

    /** Drops location history older than [FIX_KEEP_DAYS]. */
    fun pruneFixes(now: Long) {
        writableDatabase.delete("fixes", "t < ?", arrayOf((now - FIX_KEEP_DAYS * 24 * 3_600_000L).toString()))
    }

    fun closeStaleOngoing(exceptId: Long, keepId: Long = -1L) {
        writableDatabase.update(
            "entries", contentValuesOf("ongoing" to 0),
            "ongoing = 1 AND id != ? AND id != ?", arrayOf(exceptId.toString(), keepId.toString()),
        )
        bump()
    }
}
