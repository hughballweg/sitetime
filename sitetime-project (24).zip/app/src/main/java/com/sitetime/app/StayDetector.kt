package com.sitetime.app

import android.content.Context
import androidx.core.content.edit
import java.time.ZoneId

/** Earliest time of day (minutes) a new stop can be logged, and when "Done for today" ends. */
const val DAY_START_MIN = 4 * 60

/** When "Done for today" ends: the next time your tracking hours start (or 4:00 AM if tracking hours are off). */
fun nextMorning(ctx: Context, now: Long): Long {
    val zone = ZoneId.systemDefault()
    val m = Prefs.resumeMin(ctx)
    var t = now.toLocalDate().atTime(m / 60, m % 60).atZone(zone)
    if (t.toInstant().toEpochMilli() <= now) t = t.plusDays(1)
    return t.toInstant().toEpochMilli()
}

/**
 * Turns a stream of location fixes into "stays": periods where you stayed within
 * [Prefs.radiusM] of one spot for at least [Prefs.minStayMin] minutes.
 *
 * State is saved to SharedPreferences after every fix, so a stay survives the
 * service being restarted by the system.
 *
 * With [replay] = true it runs over saved location history instead (see [History]): nothing is
 * recorded, no drive questions pop up (drives wait in "Pending your review"), the workday markers
 * are kept in memory, and stops or drives already on the timesheet are left as they are.
 */
class StayDetector(ctx: Context, private val replay: Boolean = false) {
    private val app = ctx.applicationContext
    private val p = if (replay) {
        app.getSharedPreferences("detector_replay", Context.MODE_PRIVATE).also { it.edit().clear().commit() }
    } else {
        app.getSharedPreferences("detector", Context.MODE_PRIVATE)
    }
    private val db = Db.get(app)

    private var hasCand = p.getBoolean("hasCand", false)
    private var aLat = Double.fromBits(p.getLong("aLat", 0L))
    private var aLng = Double.fromBits(p.getLong("aLng", 0L))
    private var n = p.getInt("n", 0)
    private var first = p.getLong("first", 0L)
    private var last = p.getLong("last", 0L)
    private var away = p.getInt("away", 0)
    private var suppressed = p.getBoolean("suppressed", false)
    // Whether the current place has counted as a real stop, and whether it's an ignored/off-hours place.
    private var reached = p.getBoolean("reached", false)
    private var ignoredHere = p.getBoolean("ignoredHere", false)
    // Where and when you last left a real stop: the start of a possible drive.
    private var depTime = p.getLong("depTime", 0L)
    private var depIgnored = p.getBoolean("depIgnored", true)
    private var depLabel = p.getString("depLabel", "") ?: ""
    // Name of the place you're stopped at (also for ignored places, e.g. "Home").
    private var placeName = p.getString("placeName", "") ?: ""
    // Where you were when tracking shut off for the night, and whether it has just switched back on.
    private var restLat = Double.fromBits(p.getLong("restLat", 0L))
    private var restLng = Double.fromBits(p.getLong("restLng", 0L))
    private var restTime = p.getLong("restTime", 0L)
    private var wakePending = p.getBoolean("wakePending", false)
    // A place you were at overnight: never logged as a job stop.
    private var overnight = p.getBoolean("overnight", false)
    // The stop you're at might be a parts run or lunch (a short stop somewhere that isn't a job site).
    private var activeErrand = p.getBoolean("activeErrand", false)
    // The short stop you just left, waiting for "parts run or lunch?": the next drive goes with it.
    private var depErrandId = p.getLong("depErrandId", -1L)
    var activeId = p.getLong("activeId", -1L)
        private set

    // Replay only: what's already on the timesheet for the day, and where the stop being added must end.
    private var existing: List<Entry> = emptyList()
    private var existingDrives: List<Drive> = emptyList()
    private var clipAt = Long.MAX_VALUE

    // Workday markers. Live they're kept in Prefs; a replay keeps its own so a past day can't change today's.
    private var rWorkDay = ""
    private var rWorkStartMs = 0L
    private var rWorkManual = false
    private var rArrivedDay = ""
    private fun workDay() = if (replay) rWorkDay else Prefs.workDay(app)
    private fun workStartMs() = if (replay) rWorkStartMs else Prefs.workStartMs(app)
    private fun workStartManual() = if (replay) rWorkManual else Prefs.workStartManual(app)
    private fun arrivedDay() = if (replay) rArrivedDay else Prefs.arrivedDay(app)
    private fun markArrived(day: String) {
        if (replay) rArrivedDay = day else Prefs.setArrivedDay(app, day)
    }
    private fun markWorkStart(day: String, ms: Long, manual: Boolean) {
        if (replay) {
            rWorkDay = day
            rWorkStartMs = ms
            rWorkManual = manual
        } else {
            Prefs.setWorkStart(app, day, ms, manual)
        }
    }

    /** Replay: start from today's workday markers (e.g. "Start work" was tapped). */
    fun seedDayState() {
        rWorkDay = Prefs.workDay(app)
        rWorkStartMs = Prefs.workStartMs(app)
        rWorkManual = Prefs.workStartManual(app)
        rArrivedDay = Prefs.arrivedDay(app)
    }

    /** Replay of today: hand the workday markers back to live tracking. */
    fun saveDayState() {
        Prefs.setWorkStart(app, rWorkDay, rWorkStartMs, rWorkManual)
        Prefs.setArrivedDay(app, rArrivedDay)
    }

    /** Replay: what's already on the timesheet for this day (kept as is; only the gaps get filled). */
    fun setExisting(entries: List<Entry>, drives: List<Drive>) {
        existing = entries
        existingDrives = drives
    }

    private fun taken(s: Long, e: Long) =
        existing.any { it.start < e && it.end > s } || existingDrives.any { it.start < e && it.end > s }

    companion object {
        private const val MAX_ACCURACY_M = 250f          // ignore fixes worse than this
        private const val MAX_GAP_MS = 60 * 60_000L      // no fixes for an hour = start fresh
        private const val JUMP_M = 1000f                 // one fix this far away ends a stay at once
    }

    fun onLocation(lat: Double, lng: Double, accuracy: Float, time: Long) {
        if (accuracy > MAX_ACCURACY_M) return
        if (!replay) {
            db.addFix(time, lat, lng, accuracy)
            if (time < Prefs.pausedUntil(app) || !Prefs.logOn(app)) {
                // "Done for today", or Track day is off: your location is saved, but nothing is logged.
                if (hasCand || activeId >= 0) finish()
                save()
                return
            }
        }
        val minStayMs = Prefs.minStayMin(app) * 60_000L
        val radius = Prefs.radiusM(app).toFloat()

        if (wakePending) {
            // First fix after tracking was off for the night. Assume you stayed where you were.
            wakePending = false
            if (hasCand) {
                last = time
            } else if (restTime > 0 && distanceM(restLat, restLng, lat, lng) <= radius) {
                startCandidate(lat, lng, time)
                first = time - minStayMs
                overnight = true
            }
        }

        if (!hasCand) {
            startCandidate(lat, lng, time)
        } else if (time - last > MAX_GAP_MS) {
            finish()
            startCandidate(lat, lng, time)
        } else {
            val d = distanceM(aLat, aLng, lat, lng)
            if (d <= radius) {
                away = 0
                // Drift the centre point towards the average of fixes for a steadier location.
                n = minOf(n + 1, 20)
                aLat += (lat - aLat) / n
                aLng += (lng - aLng) / n
                last = time
                if (activeId >= 0) {
                    val cur = db.entry(activeId)
                    if (cur == null || !cur.ongoing) {
                        // You deleted this stop or set its end time yourself: leave it alone.
                        activeId = -1
                        activeErrand = false
                        suppressed = true
                    } else {
                        db.setEntryEnd(activeId, minOf(last, clipAt), ongoing = true)
                        if (activeErrand && last - first >= Errands.MAX_MS) {
                            // Here for hours: it's a job, not a parts run.
                            activeErrand = false
                            Errands.becameJob(app, activeId, ask = !replay)
                        }
                    }
                } else if (!suppressed && last - first >= minStayMs) {
                    val site = db.findSiteFor(aLat, aLng)
                    reached = true
                    // After the workday ends only job sites count: a saved job, or a place you already
                    // logged time at today. Unknown places (errands on the way home) aren't logged.
                    val worked = workedHereToday(aLat, aLng, first, radius)
                    val jobAfterHours = !inWorkWindow(first) && (site?.ignored == false || worked)
                    ignoredHere = site?.ignored == true || (!inWorkWindow(first) && !jobAfterHours) || overnight
                    placeName = site?.name ?: UNNAMED
                    // Replay: a stop already on the timesheet here is kept as it is.
                    val onSheet = if (replay) existing.firstOrNull { it.start < last && it.end > first } else null
                    if (onSheet != null) {
                        ignoredHere = false
                        placeName = onSheet.label
                    }
                    // Not a saved site and not somewhere you worked today: maybe a parts run or lunch.
                    val errand = site == null && !worked && !ignoredHere && onSheet == null
                    val driveIn = checkDrive(arrive = first, here = placeName, site = site, quiet = errand)
                    if (ignoredHere || onSheet != null) {
                        suppressed = true
                    } else {
                        clipAt = if (replay) existing.filter { it.start >= first }.minOfOrNull { it.start } ?: Long.MAX_VALUE else Long.MAX_VALUE
                        activeId = db.insertEntry(
                            Entry(
                                id = 0, siteId = site?.id, label = site?.name ?: UNNAMED,
                                lat = aLat, lng = aLng, start = first, end = minOf(last, clipAt),
                                ongoing = true, note = "",
                                category = site?.category ?: Prefs.defaultCategory(app),
                                errand = if (errand) ERRAND_MAYBE else 0,
                            )
                        )
                        activeErrand = errand
                        if (errand && driveIn >= 0) db.setDriveErrand(driveIn, activeId)
                    }
                }
            } else {
                away++
                // Need two fixes in a row outside the radius (or one big jump) so a
                // single bad reading doesn't end the stay.
                if (away >= 2 || d > JUMP_M) {
                    finish()
                    startCandidate(lat, lng, time)
                }
            }
        }
        save()
    }

    /**
     * You just arrived somewhere and stayed. Decide whether the drive here counts:
     *  - between two work places: recorded, and you're asked Parts run / Travel;
     *  - from home/church/etc. (the morning commute): not counted, and your workday starts now,
     *    unless you tapped "Start work" before leaving, or this place is set to count the morning drive.
     */
    /**
     * [quiet]: you arrived at a possible parts run / lunch stop, so the drive isn't asked about yet.
     * Returns the id of a drive that's waiting to be tied to the stop here, or -1.
     */
    private fun checkDrive(arrive: Long, here: String, site: Site?, quiet: Boolean = false): Long {
        val depart = depTime
        depTime = 0L
        val fromErrand = depErrandId
        depErrandId = -1L
        var held = -1L
        // A drive away from a short stop goes with that stop; one into a short stop waits for this one.
        fun handle(id: Long, ask: () -> Unit) {
            val withStop = fromErrand >= 0 && Errands.driveOut(app, id, fromErrand)
            if (withStop) return
            if (quiet) held = id else if (!replay && Prefs.askDrives(app)) ask()
        }
        val today = arrive.toLocalDate().toString()
        val started = workDay() == today
        val arrivedAlready = arrivedDay() == today
        if (depart > 0 && Drives.inRange(depart, arrive) && !(replay && taken(depart, arrive))) {
            val from = depLabel.ifBlank { "last stop" }
            if (!depIgnored && !ignoredHere) {
                // between two work places
                val id = db.addDrive(depart, arrive, from, here)
                handle(id) { Drives.ask(app, id, depart, arrive, from, here) }
            } else if (arrivedAlready && !(depIgnored && ignoredHere) && inWorkWindow(arrive)) {
                // Already logging hours today: a trip to or from home / the office / another ignored place
                // (e.g. grabbing tools) can count too. A trip *to* such a place counts for the job you left.
                val job = if (ignoredHere) from else here
                val id = db.addDrive(depart, arrive, from, here, job)
                handle(id) { Drives.ask(app, id, depart, arrive, from, here, job) }
            } else if (depIgnored && !ignoredHere && !arrivedAlready) {
                val manual = started && workStartManual()
                val siteRule = !started && site?.morningTravel == true
                if (manual || siteRule) {
                    val s = if (manual) maxOf(depart, workStartMs()) else depart
                    if (arrive - s >= 60_000L) {
                        val id = db.addDrive(s, arrive, from, here)
                        // Into a possible parts run: wait for the answer instead of logging it as travel now.
                        if (quiet) held = id else Drives.log(app, id, Drives.TRAVEL)
                    }
                }
            }
        }
        if (!ignoredHere) {
            if (!arrivedAlready) markArrived(today)
            if (!started) markWorkStart(today, arrive, manual = false)
        }
        return held
    }

    /** "Start work": your workday starts now, so the drive to your first job counts as travel. */
    fun startWork(now: Long) {
        Prefs.setPausedUntil(app, 0L)
        Prefs.setWorkStart(app, now.toLocalDate().toString(), now, manual = true)
        db.touch()
    }

    /** New places are only logged between 4:00 AM and the cutoff time. */
    /** You already logged time within [radius] of this spot earlier the same day (going back to a job). */
    private fun workedHereToday(lat: Double, lng: Double, at: Long, radius: Float): Boolean {
        val dayStart = at.toLocalDate().atStartOfDay(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli()
        return db.entriesBetween(dayStart, at).any { e ->
            val eLat = e.lat
            val eLng = e.lng
            eLat != null && eLng != null && e.category != "R" && e.category != "S" &&
                distanceM(eLat, eLng, lat, lng) <= radius
        }
    }

    private fun inWorkWindow(ms: Long): Boolean {
        val z = ms.toZoned()
        val m = z.hour * 60 + z.minute
        return m >= DAY_START_MIN && (!Prefs.cutoffOn(app) || m < Prefs.cutoffMin(app))
    }

    /**
     * "Done for today": ends the current stop right now (if you're still there) and stops
     * logging anything until tomorrow morning, so the drive home and evening stops never count.
     */
    fun endDay(now: Long) {
        // If you've already started driving away, end at the last moment you were still there.
        val endAt = if (away > 0) last else maxOf(last, now)
        if (activeId >= 0) {
            db.setEntryEnd(activeId, endAt, ongoing = false)
            if (activeErrand) closeErrand(activeId, endAt - first)
        }
        activeErrand = false
        activeId = -1
        hasCand = false
        suppressed = false
        reached = false
        ignoredHere = false
        depTime = 0L
        away = 0
        Prefs.setPausedUntil(app, nextMorning(app, now))
        save()
        db.touch()
    }

    /** True when nothing is being logged right now: no ongoing job stop, and you're at an ignored place (or done for the day). */
    fun canRest(): Boolean = activeId < 0 && (!hasCand || (reached && ignoredHere))

    /** Tracking is shutting off for the night. Remember where you are so the morning picks up from here. */
    fun rest(lat: Double?, lng: Double?, now: Long) {
        if (hasCand) {
            restLat = aLat
            restLng = aLng
            restTime = now
        } else if (lat != null && lng != null) {
            restLat = lat
            restLng = lng
            restTime = now
        } else {
            restTime = 0L
        }
        save()
    }

    /** Tracking switched back on; the next fix carries on from where you rested. */
    fun wake() {
        wakePending = true
        save()
    }

    fun resume() {
        Prefs.setPausedUntil(app, 0L)
        db.touch()
    }

    /** Close the current stay, e.g. when tracking is switched off. */
    fun stop() {
        finish()
        save()
    }

    fun status(): String = when {
        !Prefs.logOn(app) -> "Track day is off. Your location is still being saved."
        System.currentTimeMillis() < Prefs.pausedUntil(app) -> "Done for today. Tracking starts again at ${fmtClockMin(Prefs.resumeMin(app))}."
        activeId >= 0 -> db.entry(activeId)?.let { "At ${it.label} since ${fmtTime(it.start)}" }
            ?: "At a place you removed"
        hasCand && suppressed -> "At an ignored place"
        hasCand && last - first >= 60_000L ->
            "Stopped since ${fmtTime(first)} — logs after ${Prefs.minStayMin(app)} min"
        hasCand -> "On the move"
        else -> "Waiting for location…"
    }

    private fun startCandidate(lat: Double, lng: Double, time: Long) {
        hasCand = true
        aLat = lat
        aLng = lng
        n = 1
        first = time
        last = time
        away = 0
        suppressed = false
        reached = false
        ignoredHere = false
        overnight = false
        activeId = -1
        activeErrand = false
        clipAt = Long.MAX_VALUE
    }

    /** You left a short stop: under [Errands.MAX_MS] it waits for "parts run or lunch?", otherwise it's a job. */
    private fun closeErrand(id: Long, stayMs: Long) {
        if (stayMs < Errands.MAX_MS) {
            db.setErrand(id, ERRAND_ASK)
            depErrandId = id
            if (!replay) Errands.ask(app, id)
        } else {
            Errands.becameJob(app, id, ask = !replay)
        }
    }

    private fun finish() {
        if (reached) {
            // Leaving a real stop: remember it as the start of a possible drive.
            depTime = last
            depIgnored = ignoredHere
            depLabel = (if (activeId >= 0) db.entry(activeId)?.label else null) ?: placeName
            depErrandId = -1L
        }
        reached = false
        ignoredHere = false
        if (activeId >= 0) {
            val end = minOf(last, clipAt)
            db.setEntryEnd(activeId, end, ongoing = false)
            if (activeErrand) closeErrand(activeId, end - first)
        }
        activeErrand = false
        activeId = -1
        hasCand = false
        suppressed = false
        away = 0
    }

    /** Live tracking takes over where a replay of today left off (including a stop you're still at). */
    fun copyFrom(o: StayDetector) {
        hasCand = o.hasCand
        aLat = o.aLat
        aLng = o.aLng
        n = o.n
        first = o.first
        last = o.last
        away = o.away
        suppressed = o.suppressed
        reached = o.reached
        ignoredHere = o.ignoredHere
        depTime = o.depTime
        depIgnored = o.depIgnored
        depLabel = o.depLabel
        placeName = o.placeName
        overnight = o.overnight
        activeId = o.activeId
        activeErrand = o.activeErrand
        depErrandId = o.depErrandId
        save()
    }

    private fun save() = p.edit {
        putBoolean("hasCand", hasCand)
        putLong("aLat", aLat.toRawBits())
        putLong("aLng", aLng.toRawBits())
        putInt("n", n)
        putLong("first", first)
        putLong("last", last)
        putInt("away", away)
        putBoolean("suppressed", suppressed)
        putLong("activeId", activeId)
        putBoolean("reached", reached)
        putBoolean("ignoredHere", ignoredHere)
        putLong("depTime", depTime)
        putBoolean("depIgnored", depIgnored)
        putString("depLabel", depLabel)
        putString("placeName", placeName)
        putLong("restLat", restLat.toRawBits())
        putLong("restLng", restLng.toRawBits())
        putLong("restTime", restTime)
        putBoolean("wakePending", wakePending)
        putBoolean("overnight", overnight)
        putBoolean("activeErrand", activeErrand)
        putLong("depErrandId", depErrandId)
    }
}
