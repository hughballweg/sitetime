@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.sitetime.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import kotlinx.coroutines.launch
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.draw.scale
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.SwitchDefaults
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.res.painterResource
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.location.Geocoder
import android.os.Handler
import android.os.Looper
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Surface
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import java.util.Locale
import android.os.PowerManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.LifecycleResumeEffect
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.TemporalAdjusters

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ThemeState.load(this)
        enableEdgeToEdge()
        setContent {
            val dark = ThemeState.mode == ThemeMode.DARK
            LaunchedEffect(dark) {
                enableEdgeToEdge(
                    statusBarStyle = if (dark) {
                        androidx.activity.SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
                    } else {
                        androidx.activity.SystemBarStyle.light(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT)
                    },
                    navigationBarStyle = if (dark) {
                        androidx.activity.SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
                    } else {
                        androidx.activity.SystemBarStyle.light(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT)
                    },
                )
            }
            AppTheme { App() }
        }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    var needName by remember { mutableStateOf(Prefs.name(ctx).isBlank()) }
    if (needName) NameDialog { needName = false }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val tabs = listOf("Timesheet", "Sites", "Settings")
    val icons = listOf(Icons.Default.DateRange, Icons.Default.Place, Icons.Default.Settings)
    Scaffold(
        topBar = { BrandHeader() },
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest, tonalElevation = 0.dp) {
                tabs.forEachIndexed { i, t ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Icon(icons[i], contentDescription = null) },
                        label = { Text(t) },
                    )
                }
            }
        },
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> TimesheetScreen()
                1 -> SitesScreen()
                else -> SettingsScreen()
            }
        }
    }
}

/** Shown once on first launch. It can't be dismissed without a name. */
@Composable
fun NameDialog(onDone: () -> Unit) {
    val ctx = LocalContext.current
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = { },
        title = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Image(
                    painterResource(R.drawable.prime_logo), contentDescription = "PRIME Mechanical of Wisconsin",
                    modifier = Modifier.fillMaxWidth(),
                    colorFilter = if (LocalDark.current) ColorFilter.tint(Color.White) else null,
                )
                Text("Welcome to Timesheet")
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Enter your name as it should appear on your timesheets. You can change it later in Settings.")
                OutlinedTextField(
                    value = name, onValueChange = { name = it }, label = { Text("Your name") },
                    singleLine = true, modifier = Modifier.fillMaxWidth(),
                )
            }
        },
        confirmButton = {
            TextButton(enabled = name.isNotBlank(), onClick = {
                Prefs.setName(ctx, name)
                onDone()
            }) { Text("Continue") }
        },
    )
}

@Composable
fun CategoryPicker(title: String, selected: String?, onSelect: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Column {
        if (title.isNotEmpty()) {
            Text(title, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Box {
            OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) {
                Text(Categories.labelOf(selected), maxLines = 1)
            }
            DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                Categories.all.forEach { c ->
                    DropdownMenuItem(text = { Text(c.label) }, onClick = { onSelect(c.col); open = false })
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Timesheet

@Composable
fun TimesheetScreen() {
    val ctx = LocalContext.current
    val db = remember { Db.get(ctx) }
    val version by Db.changes.collectAsState()
    val thisWeek = remember { LocalDate.now().with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY)) }
    var weekStart by remember { mutableStateOf(thisWeek) }
    val zone = ZoneId.systemDefault()
    val from = weekStart.atStartOfDay(zone).toInstant().toEpochMilli()
    val to = weekStart.plusDays(7).atStartOfDay(zone).toInstant().toEpochMilli()
    val entries = remember(version, from) { db.entriesBetween(from, to) }
    val breaks = remember(version, from) { db.breaksBetween(weekStart, weekStart.plusDays(7)) }
    var breakDay by remember { mutableStateOf<LocalDate?>(null) }
    var editorDay by remember { mutableStateOf<Int?>(null) }
    // Drives you haven't logged yet show alongside your jobs; logged ones are already entries.
    val drives = remember(version, from) { db.drivesBetween(from, to).filter { it.status != Drive.LOGGED } }
    // Today (newest) at the top, earlier days below it.
    val days = (entries.map { it.start.toLocalDate() } + drives.map { it.start.toLocalDate() }).toSortedSet().reversed()
    var refreshing by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    var editing by remember { mutableStateOf<Entry?>(null) }
    var adding by remember { mutableStateOf(false) }
    var exporting by remember { mutableStateOf(false) }

    androidx.compose.material3.pulltorefresh.PullToRefreshBox(
        isRefreshing = refreshing,
        onRefresh = {
            refreshing = true
            scope.launch {
                // Ask for a fresh location fix and reload everything on screen.
                if (Prefs.trackingEnabled(ctx) && Perms.hasLocation(ctx)) {
                    try {
                        TrackingService.start(ctx)
                    } catch (_: Exception) {
                    }
                }
                db.touch()
                kotlinx.coroutines.delay(700)
                refreshing = false
            }
        },
        modifier = Modifier.fillMaxSize(),
    ) {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        item { TrackingCard() }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { weekStart = weekStart.minusWeeks(1) }) {
                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, "Previous week")
                }
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        if (weekStart == thisWeek) "This week" else "Week of ${weekStart.format(WEEK_FMT)}",
                        style = MaterialTheme.typography.titleMedium,
                    )
                    Text(
                        "${weekStart.format(java.time.format.DateTimeFormatter.ofPattern("MMM d"))} – " +
                            "${weekStart.plusDays(6).format(java.time.format.DateTimeFormatter.ofPattern("MMM d"))} · " +
                            fmtDur(entries.sumOf { it.end - it.start }),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary,
                    )
                }
                IconButton(onClick = { weekStart = weekStart.plusWeeks(1) }) {
                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, "Next week")
                }
            }
        }
        item {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    val today = LocalDate.now()
                    editorDay = if (!today.isBefore(weekStart) && today.isBefore(weekStart.plusDays(7))) {
                        (today.toEpochDay() - weekStart.toEpochDay()).toInt()
                    } else {
                        0
                    }
                }) { Text("Review / edit sheet") }
                OutlinedButton(onClick = { adding = true }) {
                    Icon(Icons.Default.Add, null)
                    Spacer(Modifier.width(6.dp))
                    Text("Add entry")
                }
                Button(onClick = { exporting = true }) {
                    Icon(Icons.Default.Share, null)
                    Spacer(Modifier.width(6.dp))
                    Text("Timesheet")
                }
            }
        }
        if (entries.isEmpty() && drives.isEmpty()) {
            item {
                Text(
                    "Nothing logged this week. Once tracking is on, any place you stay " +
                        "${Prefs.minStayMin(ctx)}+ minutes shows up here automatically.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        for (date in days) {
            val list = entries.filter { it.start.toLocalDate() == date }
            val dayDrives = drives.filter { it.start.toLocalDate() == date }
            item(key = "day-$date") {
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        date.format(DAY_FMT), Modifier.weight(1f),
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.primary,
                    )
                    val mins = breaks[date] ?: 0
                    TextButton(onClick = { breakDay = date }) {
                        Text(if (mins > 0) "Break $mins min" else "Add break")
                    }
                    Text(
                        fmtDur(list.sumOf { it.end - it.start }),
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.primary,
                    )
                }
            }
            val rows: List<Any> = (list + dayDrives).sortedBy { if (it is Entry) it.start else (it as Drive).start }
            items(rows, key = { if (it is Entry) "e${it.id}" else "d${(it as Drive).id}" }) { row ->
                if (row is Entry) EntryRow(row) { editing = row } else DriveRow(row as Drive)
            }
        }
    }
    }

    editing?.let { e -> EntryDialog(e, e.start.toLocalDate()) { editing = null } }
    if (exporting) {
        ExportDialog(
            weekStart,
            onEdit = {
                exporting = false
                val today = LocalDate.now()
                editorDay = if (!today.isBefore(weekStart) && today.isBefore(weekStart.plusDays(7))) {
                    (today.toEpochDay() - weekStart.toEpochDay()).toInt()
                } else {
                    0
                }
            },
        ) { exporting = false }
    }
    editorDay?.let { d -> SheetEditorDialog(weekStart, d) { editorDay = null } }
    breakDay?.let { d -> BreakDialog(d, breaks[d] ?: 0) { breakDay = null } }
    if (adding) {
        val today = LocalDate.now()
        val default = if (!today.isBefore(weekStart) && today.isBefore(weekStart.plusDays(7))) today else weekStart
        EntryDialog(null, default) { adding = false }
    }
}

/** A drive between two work places that hasn't been added to the timesheet. */
@Composable
fun DriveRow(d: Drive) {
    val ctx = LocalContext.current
    val version by Db.changes.collectAsState()
    val dest = remember(d, version) { Drives.destination(ctx, d) }
    Card(
        Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
    ) {
        Column(Modifier.padding(start = 16.dp, end = 8.dp, top = 10.dp, bottom = 4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("$DRIVE_PREFIX$dest", style = MaterialTheme.typography.titleSmall)
                    Text(
                        "${fmtTime(d.start)} – ${fmtTime(d.end)} · from ${d.from}" +
                            if (d.status == Drive.SKIPPED) " · not on timesheet" else " · not logged yet",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Text(fmtDur(d.end - d.start), style = MaterialTheme.typography.titleSmall)
            }
            FlowRow {
                TextButton(onClick = { Drives.log(ctx, d.id, Drives.TRAVEL) }) { Text("Log as Travel") }
                TextButton(onClick = { Drives.log(ctx, d.id, Drives.PARTS_RUN) }) { Text("Log as Parts run") }
                if (d.status == Drive.PENDING) {
                    TextButton(onClick = { Drives.skip(ctx, d.id) }) { Text("Don't log") }
                }
            }
        }
    }
}

@Composable
fun EntryRow(e: Entry, onClick: () -> Unit) {
    val unnamed = e.siteId == null && e.lat != null && e.label == UNNAMED
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        colors = if (unnamed) CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer)
        else CardDefaults.cardColors(),
    ) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(e.label, style = MaterialTheme.typography.titleMedium)
                val times = "${fmtTime(e.start)} – ${if (e.ongoing) "now" else fmtTime(e.end)}"
                Text(
                    when {
                        unnamed -> "$times · tap to name"
                        e.note.isNotBlank() -> "$times · ${e.note}"
                        else -> times
                    },
                    style = MaterialTheme.typography.bodyMedium,
                )
                Text(
                    Categories.labelOf(e.category),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Text(fmtDur(e.end - e.start), style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
        }
    }
}

// ---------------------------------------------------------------- 12-hour time and date pickers

private val H12: java.time.format.DateTimeFormatter = java.time.format.DateTimeFormatter.ofPattern("h:mm a", Locale.US)
fun fmt12(t: java.time.LocalTime): String = t.format(H12)
fun fmt12(ms: Long): String = fmt12(ms.toZoned().toLocalTime())

fun pickTime(ctx: Context, initial: java.time.LocalTime, onPicked: (java.time.LocalTime) -> Unit) {
    android.app.TimePickerDialog(
        ctx, { _, h, m -> onPicked(java.time.LocalTime.of(h, m)) }, initial.hour, initial.minute, false,
    ).show()
}

fun pickDate(ctx: Context, initial: LocalDate, onPicked: (LocalDate) -> Unit) {
    android.app.DatePickerDialog(
        ctx, { _, y, mo, d -> onPicked(LocalDate.of(y, mo + 1, d)) },
        initial.year, initial.monthValue - 1, initial.dayOfMonth,
    ).show()
}

/** A tappable field that shows a time or date and opens a picker. */
@Composable
fun PickerField(label: String, value: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    OutlinedButton(onClick = onClick, modifier = modifier, shape = MaterialTheme.shapes.small) {
        Column(Modifier.fillMaxWidth()) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(value, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
        }
    }
}

fun epochMs(d: LocalDate, t: java.time.LocalTime): Long =
    d.atTime(t).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()

/** End time on the same day as the start, or the next day if it's earlier (past midnight). */
fun endMs(d: LocalDate, start: java.time.LocalTime, end: java.time.LocalTime): Long =
    if (end.isAfter(start)) epochMs(d, end) else epochMs(d.plusDays(1), end)

@Composable
fun EntryDialog(entry: Entry?, defaultDate: LocalDate, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val db = remember { Db.get(ctx) }
    val sites = remember { db.sites().filter { !it.ignored } }
    var label by remember { mutableStateOf(entry?.label?.takeIf { it != UNNAMED } ?: "") }
    var siteId by remember { mutableStateOf(entry?.siteId) }
    var date by remember { mutableStateOf(entry?.start?.toLocalDate() ?: defaultDate) }
    var start by remember { mutableStateOf(entry?.start?.toZoned()?.toLocalTime() ?: java.time.LocalTime.of(7, 0)) }
    var end by remember { mutableStateOf(entry?.end?.toZoned()?.toLocalTime() ?: java.time.LocalTime.of(15, 30)) }
    var endTouched by remember { mutableStateOf(false) }
    var note by remember { mutableStateOf(entry?.note ?: "") }
    var category by remember { mutableStateOf(entry?.category ?: Prefs.defaultCategory(ctx)) }
    var saveAsSite by remember { mutableStateOf(entry != null && entry.siteId == null && entry.lat != null) }
    var pickOpen by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val canSaveSite = entry?.lat != null && siteId == null
    val stillThere = entry?.ongoing == true && !endTouched

    val save: () -> Unit = save@{
        if (label.isBlank()) {
            error = "Give the site or job a name."
            return@save
        }
        val startMs = epochMs(date, start)
        val endMsVal = if (stillThere) maxOf(entry?.end ?: startMs, startMs) else endMs(date, start, end)
        var newSiteId = siteId
        val lat = entry?.lat
        val lng = entry?.lng
        if (canSaveSite && saveAsSite && lat != null && lng != null) {
            newSiteId = db.addSite(label.trim(), lat, lng, Prefs.radiusM(ctx).toDouble(), false, category)
        }
        val updated = Entry(
            id = entry?.id ?: 0, siteId = newSiteId, label = label.trim(), lat = lat, lng = lng,
            start = startMs, end = endMsVal, ongoing = stillThere, note = note.trim(),
            category = category, breakMin = 0,
        )
        if (entry == null) db.insertEntry(updated) else db.updateEntry(updated)
        if (newSiteId != null && newSiteId != entry?.siteId) db.site(newSiteId)?.let { db.assignUnnamedNear(it) }
        onDismiss()
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (entry == null) "Add entry" else "Edit entry") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = label, onValueChange = { label = it; siteId = null },
                    label = { Text("Site / job name") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                )
                if (sites.isNotEmpty()) {
                    Box {
                        TextButton(onClick = { pickOpen = true }) { Text("Pick a saved site") }
                        DropdownMenu(expanded = pickOpen, onDismissRequest = { pickOpen = false }) {
                            sites.forEach { st ->
                                DropdownMenuItem(
                                    text = { Text(st.name) },
                                    onClick = {
                                        label = st.name
                                        siteId = st.id
                                        st.category?.let { category = it }
                                        pickOpen = false
                                    },
                                )
                            }
                        }
                    }
                }
                PickerField("Date", date.format(java.time.format.DateTimeFormatter.ofPattern("EEE, MMM d, yyyy")), Modifier.fillMaxWidth()) {
                    pickDate(ctx, date) { date = it }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PickerField("Start", fmt12(start), Modifier.weight(1f)) { pickTime(ctx, start) { start = it } }
                    PickerField("End", if (stillThere) "Still there" else fmt12(end), Modifier.weight(1f)) {
                        pickTime(ctx, end) {
                            end = it
                            endTouched = true
                        }
                    }
                }
                CategoryPicker("Work type", category) { category = it }
                OutlinedTextField(
                    value = note, onValueChange = { note = it },
                    label = { Text("Note (optional)") }, modifier = Modifier.fillMaxWidth(),
                )
                if (canSaveSite) {
                    Row(
                        Modifier.clickable { saveAsSite = !saveAsSite },
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Checkbox(checked = saveAsSite, onCheckedChange = { saveAsSite = it })
                        Text(
                            "Save as a site, so future stops here are named automatically",
                            style = MaterialTheme.typography.bodyMedium,
                        )
                    }
                }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                if (entry != null) {
                    FlowRow {
                        TextButton(onClick = { db.deleteEntry(entry.id); onDismiss() }) {
                            Text("Delete entry", color = MaterialTheme.colorScheme.error)
                        }
                        val lat = entry.lat
                        val lng = entry.lng
                        if (lat != null && lng != null && entry.siteId == null) {
                            TextButton(onClick = {
                                val id = db.addSite("Ignored place", lat, lng, Prefs.radiusM(ctx).toDouble(), true)
                                db.site(id)?.let { db.assignUnnamedNear(it) }
                                db.deleteEntry(entry.id)
                                onDismiss()
                            }) { Text("Ignore this place") }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = save) { Text("Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
fun TrackingCard() {
    val ctx = LocalContext.current
    var enabled by remember { mutableStateOf(Prefs.trackingEnabled(ctx)) }
    var tick by remember { mutableIntStateOf(0) }
    val version by Db.changes.collectAsState()
    val paused = remember(version, tick) { Prefs.pausedUntil(ctx) > System.currentTimeMillis() }
    LifecycleResumeEffect(Unit) {
        tick++
        onPauseOrDispose { }
    }
    val hasLoc = remember(tick) { Perms.hasLocation(ctx) }
    val hasBg = remember(tick) { Perms.hasBackground(ctx) }
    val batteryOk = remember(tick) {
        (ctx.getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(ctx.packageName)
    }

    val turnOn = {
        Prefs.setTrackingEnabled(ctx, true)
        enabled = true
        TrackingService.start(ctx)
    }
    val locLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        tick++
        if (Perms.hasLocation(ctx)) turnOn()
    }
    val bgLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        tick++
        if (!granted) openAppSettings(ctx)
    }

    // Make sure the service is running whenever the app is opened with tracking on.
    LaunchedEffect(Unit) {
        if (enabled && Perms.hasLocation(ctx)) {
            try {
                TrackingService.start(ctx)
            } catch (_: Exception) {
            }
        }
    }

    val today = remember(version) {
        val zone = ZoneId.systemDefault()
        val d = LocalDate.now()
        Db.get(ctx).entriesBetween(
            d.atStartOfDay(zone).toInstant().toEpochMilli(),
            d.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli(),
        )
    }
    val current = today.lastOrNull { it.ongoing }
    val todayStr = LocalDate.now().toString()
    val workStarted = remember(version, tick) { Prefs.workDay(ctx) == todayStr }
    val workStartAt = remember(version, tick) { Prefs.workStartMs(ctx) }
    val status = when {
        !enabled -> "Tracking is off. Turn it on to log your day automatically."
        !hasLoc -> "Location access is off, so nothing is being logged."
        paused -> "Done for today. Logging picks back up at 4:00 AM."
        current != null -> "At ${current.label} since ${fmtTime(current.start)}"
        else -> "Watching for your next stop"
    }
    val branded = LocalBranded.current
    val onNavy = if (branded) Color.White else MaterialTheme.colorScheme.onSurface
    val softOnNavy = if (branded) Color(0xFFC9CFF0) else MaterialTheme.colorScheme.onSurfaceVariant
    val heroButton = if (branded) {
        ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = PrimeNavy)
    } else {
        ButtonDefaults.buttonColors()
    }

    Card(
        Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(
            containerColor = if (branded) PrimeNavy else MaterialTheme.colorScheme.surfaceContainerLowest,
            contentColor = onNavy,
        ),
        border = if (branded) null else androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
        Column(Modifier.padding(start = 20.dp, end = 16.dp, top = 16.dp, bottom = 16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    LocalDate.now().format(java.time.format.DateTimeFormatter.ofPattern("EEEE, MMMM d")),
                    Modifier.weight(1f), style = MaterialTheme.typography.labelLarge, color = softOnNavy,
                )
                Text(if (enabled) "Tracking" else "Off", style = MaterialTheme.typography.labelMedium, color = softOnNavy)
                Spacer(Modifier.width(8.dp))
                Switch(
                    checked = enabled,
                    onCheckedChange = { on ->
                        if (on) {
                            if (hasLoc) turnOn() else locLauncher.launch(Perms.foregroundRequest())
                        } else {
                            Prefs.setTrackingEnabled(ctx, false)
                            enabled = false
                            TrackingService.stop(ctx)
                        }
                    },
                    colors = if (branded) {
                        SwitchDefaults.colors(
                            checkedThumbColor = PrimeNavy, checkedTrackColor = Color.White, checkedBorderColor = Color.White,
                            uncheckedThumbColor = softOnNavy, uncheckedTrackColor = Color(0x22FFFFFF), uncheckedBorderColor = softOnNavy,
                        )
                    } else {
                        SwitchDefaults.colors()
                    },
                )
            }
            Text(
                fmtDur(today.sumOf { it.end - it.start }),
                style = MaterialTheme.typography.displaySmall, color = onNavy,
            )
            Text(status, style = MaterialTheme.typography.bodyMedium, color = softOnNavy)
            if (enabled && workStarted && !paused) {
                Text(
                    "Workday started ${fmtTime(workStartAt)}" + if (Prefs.workStartManual(ctx)) " (Start work)" else "",
                    style = MaterialTheme.typography.bodySmall, color = softOnNavy,
                )
            }
            if (branded) {
                Spacer(Modifier.height(14.dp))
                DoubleRule(thickness = 2)
                Spacer(Modifier.height(14.dp))
            } else {
                Spacer(Modifier.height(16.dp))
            }
            if (enabled && hasLoc) {
                if (paused) {
                    OutlinedButton(
                        onClick = { TrackingService.send(ctx, TrackingService.ACTION_RESUME) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = if (branded) ButtonDefaults.outlinedButtonColors(contentColor = Color.White) else ButtonDefaults.outlinedButtonColors(),
                        border = if (branded) androidx.compose.foundation.BorderStroke(1.dp, softOnNavy) else androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    ) { Text("Resume logging today") }
                } else if (!workStarted) {
                    Button(
                        onClick = { TrackingService.send(ctx, TrackingService.ACTION_START_WORK) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = heroButton,
                    ) { Text("Start work") }
                    Text(
                        "Going to the office? No need. Your day starts when you arrive.",
                        style = MaterialTheme.typography.bodySmall, color = softOnNavy,
                    )
                } else {
                    Button(
                        onClick = { TrackingService.send(ctx, TrackingService.ACTION_DONE) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = heroButton,
                    ) { Text("Done for today") }
                }
            } else if (!enabled) {
                Button(
                    onClick = { if (hasLoc) turnOn() else locLauncher.launch(Perms.foregroundRequest()) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = heroButton,
                ) { Text("Start tracking") }
            }
            if (enabled && !hasLoc) {
                Warning("Location permission is off.", "Allow", onNavy = branded) {
                    locLauncher.launch(Perms.foregroundRequest())
                }
            }
            if (enabled && hasLoc && !hasBg) {
                Warning("Set location to \"Allow all the time\" so tracking restarts after a reboot.", "Fix", onNavy = branded) {
                    bgLauncher.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
                }
            }
            if (enabled && !batteryOk) {
                Warning("Battery optimization can pause tracking when the screen is off.", "Fix", onNavy = branded) {
                    requestBatteryExemption(ctx)
                }
            }
        }
    }
}

@Composable
fun Warning(text: String, action: String, onNavy: Boolean = false, onClick: () -> Unit) {
    Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(
            text, Modifier.weight(1f),
            style = MaterialTheme.typography.bodySmall,
            color = if (onNavy) Color(0xFFFFC2C4) else MaterialTheme.colorScheme.error,
        )
        TextButton(
            onClick = onClick,
            colors = if (onNavy) ButtonDefaults.textButtonColors(contentColor = Color.White) else ButtonDefaults.textButtonColors(),
        ) { Text(action) }
    }
}

fun openAppSettings(ctx: Context) {
    ctx.startActivity(
        Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))
    )
}

@SuppressLint("BatteryLife")
fun requestBatteryExemption(ctx: Context) {
    try {
        ctx.startActivity(
            Intent(
                android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                Uri.parse("package:${ctx.packageName}"),
            )
        )
    } catch (_: Exception) {
        ctx.startActivity(Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
    }
}

// ---------------------------------------------------------------- Sites

@SuppressLint("MissingPermission")
fun currentLocation(ctx: Context, cb: (Pair<Double, Double>?) -> Unit) {
    try {
        LocationServices.getFusedLocationProviderClient(ctx)
            .getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, CancellationTokenSource().token)
            .addOnSuccessListener { loc -> cb(loc?.let { it.latitude to it.longitude }) }
            .addOnFailureListener { cb(null) }
    } catch (_: SecurityException) {
        cb(null)
    }
}

@Composable
fun SitesScreen() {
    val ctx = LocalContext.current
    val db = remember { Db.get(ctx) }
    val version by Db.changes.collectAsState()
    val sites = remember(version) { db.sites() }
    var editing by remember { mutableStateOf<Site?>(null) }
    var newLoc by remember { mutableStateOf<NewPlace?>(null) }
    var addressOpen by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        item {
            Text(
                "You don't need to set up job sites in advance: new places show up on your timesheet as " +
                    "\"Unnamed stop\" and you name them there. Saved sites name future stops automatically. " +
                    "Add home, church, and other personal places, then turn on \"Ignore this place\" so they never count.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        item {
            Button(
                enabled = !busy,
                onClick = {
                    msg = null
                    if (!Perms.hasLocation(ctx)) {
                        msg = "Turn on tracking first so the app has location access."
                    } else {
                        busy = true
                        currentLocation(ctx) { loc ->
                            busy = false
                            if (loc == null) {
                                msg = "Couldn't get a location fix. Try again in a moment."
                            } else {
                                newLoc = NewPlace(loc.first, loc.second, "")
                            }
                        }
                    }
                },
            ) { Text(if (busy) "Getting location…" else "Add my current location") }
        }
        item {
            OutlinedButton(onClick = { addressOpen = true }) { Text("Add a place by address") }
        }
        msg?.let { m -> item { Text(m, color = MaterialTheme.colorScheme.error) } }
        if (sites.isEmpty()) {
            item { Text("No saved sites yet.", style = MaterialTheme.typography.bodyMedium) }
        }
        items(sites, key = { it.id }) { s ->
            Card(onClick = { editing = s }, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                    Text(s.name, style = MaterialTheme.typography.titleMedium)
                    Text(
                        if (s.ignored) {
                            "Ignored · ${s.radius.toInt()} m radius"
                        } else {
                            "${Categories.labelOf(s.category)} · " +
                                (if (s.morningTravel) "morning drive counts · " else "") + "${s.radius.toInt()} m radius"
                        },
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
            }
        }
    }

    editing?.let { s -> SiteDialog(s, s.lat, s.lng) { editing = null } }
    newLoc?.let { p -> SiteDialog(null, p.lat, p.lng, p.name) { newLoc = null } }
    if (addressOpen) {
        AddressDialog(onDismiss = { addressOpen = false }) { place ->
            addressOpen = false
            newLoc = place
        }
    }
}

@Composable
fun SiteDialog(site: Site?, lat: Double, lng: Double, initialName: String = "", onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val db = remember { Db.get(ctx) }
    var name by remember { mutableStateOf(site?.name ?: initialName) }
    var radius by remember { mutableStateOf((site?.radius?.toInt() ?: Prefs.radiusM(ctx)).toString()) }
    var ignored by remember { mutableStateOf(site?.ignored ?: false) }
    var category by remember { mutableStateOf(site?.category ?: Prefs.defaultCategory(ctx)) }
    var morningTravel by remember { mutableStateOf(site?.morningTravel ?: false) }
    var error by remember { mutableStateOf<String?>(null) }

    val confirm: () -> Unit = confirm@{
        val r = radius.trim().toDoubleOrNull()
        val n = name.trim().ifBlank { if (ignored) "Ignored place" else "" }
        if (n.isBlank()) {
            error = "Give the site a name."
            return@confirm
        }
        if (r == null || r < 30 || r > 3000) {
            error = "Radius should be between 30 and 3000 m."
            return@confirm
        }
        val id = if (site == null) {
            db.addSite(n, lat, lng, r, ignored, category, morningTravel && !ignored)
        } else {
            db.updateSite(
                site.copy(name = n, radius = r, ignored = ignored, category = category, morningTravel = morningTravel && !ignored),
            )
            site.id
        }
        db.site(id)?.let { db.assignUnnamedNear(it) }
        onDismiss()
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (site == null) "New site" else "Edit site") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = name, onValueChange = { name = it }, label = { Text("Name") },
                    singleLine = true, modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = radius, onValueChange = { radius = it }, label = { Text("Radius (metres)") },
                    singleLine = true, modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                )
                if (!ignored) {
                    CategoryPicker("Usual work type here", category) { category = it }
                    Text("When this is my first stop of the day", style = MaterialTheme.typography.labelMedium)
                    Column {
                        Row(
                            Modifier.fillMaxWidth().clickable { morningTravel = false },
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            androidx.compose.material3.RadioButton(selected = !morningTravel, onClick = { morningTravel = false })
                            Text("Work starts when I arrive (drive here not counted)", style = MaterialTheme.typography.bodyMedium)
                        }
                        Row(
                            Modifier.fillMaxWidth().clickable { morningTravel = true },
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            androidx.compose.material3.RadioButton(selected = morningTravel, onClick = { morningTravel = true })
                            Text("Count my morning drive here as travel", style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Ignore this place")
                        Text(
                            "For home and other non-work spots. Stops here won't be logged.",
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                    Switch(checked = ignored, onCheckedChange = { ignored = it })
                }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                if (site != null) {
                    TextButton(onClick = { db.deleteSite(site.id); onDismiss() }) {
                        Text("Delete site", color = MaterialTheme.colorScheme.error)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = confirm) { Text("Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

// ---------------------------------------------------------------- Settings

@Composable
fun SettingsScreen() {
    val ctx = LocalContext.current
    var minStay by remember { mutableIntStateOf(Prefs.minStayMin(ctx)) }
    var radius by remember { mutableIntStateOf(Prefs.radiusM(ctx)) }
    var interval by remember { mutableIntStateOf(Prefs.intervalMin(ctx)) }
    var highAcc by remember { mutableStateOf(Prefs.highAccuracy(ctx)) }
    var name by remember { mutableStateOf(Prefs.name(ctx)) }
    var defaultCat by remember { mutableStateOf(Prefs.defaultCategory(ctx)) }
    var sat by remember { mutableStateOf(Prefs.includeSaturday(ctx)) }
    var sun by remember { mutableStateOf(Prefs.includeSunday(ctx)) }
    var remindOn by remember { mutableStateOf(Prefs.reminderOn(ctx)) }
    var cutoffOn by remember { mutableStateOf(Prefs.cutoffOn(ctx)) }
    var askDrives by remember { mutableStateOf(Prefs.askDrives(ctx)) }
    var startRemind by remember { mutableStateOf(Prefs.startRemindOn(ctx)) }
    val restart: () -> Unit = {
        if (Prefs.trackingEnabled(ctx)) {
            try {
                TrackingService.start(ctx)
            } catch (_: Exception) {
            }
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp),
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("Appearance", style = MaterialTheme.typography.titleSmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ThemeMode.values().forEach { m ->
                    FilterChip(
                        selected = ThemeState.mode == m,
                        onClick = { ThemeState.set(ctx, m) },
                        label = { Text(m.label) },
                    )
                }
            }
        }
        OutlinedTextField(
            value = name,
            onValueChange = {
                name = it
                if (it.isNotBlank()) Prefs.setName(ctx, it)
            },
            label = { Text("Your name (printed on timesheets)") },
            isError = name.isBlank(),
            supportingText = { if (name.isBlank()) Text("Name can't be empty") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        CategoryPicker("Default work type for new places", defaultCat) {
            defaultCat = it
            Prefs.setDefaultCategory(ctx, it)
        }
        Column {
            Text("Weekend days on printed/exported timesheets", style = MaterialTheme.typography.titleSmall)
            SwitchRow("Include Saturday", sat) { sat = it; Prefs.setBool(ctx, "incSat", it) }
            SwitchRow("Include Sunday", sun) { sun = it; Prefs.setBool(ctx, "incSun", it) }
            Text(
                "These are the defaults. You can still change them each time you print or export.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        HorizontalDivider()
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("Start of the workday", style = MaterialTheme.typography.titleSmall)
            SwitchRow("Weekday \"Start work\" reminder", startRemind) {
                startRemind = it
                Prefs.setBool(ctx, "startRemindOn", it)
            }
            if (startRemind) TimeSetting("Remind me at", Prefs.startRemindMin(ctx)) { Prefs.setInt(ctx, "startRemindMin", it) }
            Text(
                "Your drive to the office isn't counted. Your day starts when you arrive. If you're heading " +
                    "straight to a job, tap Start work before you leave and the drive counts as travel. You can " +
                    "also set a saved place to always count the morning drive there.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(8.dp))
            Text("End of the workday", style = MaterialTheme.typography.titleSmall)
            SwitchRow("Reminder notification", remindOn) { remindOn = it; Prefs.setBool(ctx, "remindOn", it) }
            if (remindOn) TimeSetting("Remind me at", Prefs.reminderMin(ctx)) { Prefs.setInt(ctx, "remindMin", it) }
            SwitchRow("Stop logging new places late in the day", cutoffOn) { cutoffOn = it; Prefs.setBool(ctx, "cutoffOn", it) }
            if (cutoffOn) TimeSetting("No new places after", Prefs.cutoffMin(ctx)) { Prefs.setInt(ctx, "cutoffMin", it) }
            SwitchRow("Ask to log drives (parts run / travel)", askDrives) {
                askDrives = it
                Prefs.setBool(ctx, "askDrives", it)
            }
            Text(
                "Tap \"Done for today\" on the reminder (or the Timesheet tab) when you leave your last job " +
                    "or the office. Your day ends there, and the drive home and anything after it isn't logged.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        HorizontalDivider()
        ChoiceRow("Log a stop after staying", listOf(5, 10, 15, 20, 30), minStay, { "$it min" }) {
            minStay = it; Prefs.setInt(ctx, "minStay", it)
        }
        ChoiceRow("Same-place radius", listOf(75, 100, 150, 250, 400), radius, { "$it m" }) {
            radius = it; Prefs.setInt(ctx, "radius", it)
        }
        ChoiceRow("Check location every", listOf(1, 2, 3, 5), interval, { "$it min" }) {
            interval = it; Prefs.setInt(ctx, "interval", it); restart()
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("High-accuracy GPS", style = MaterialTheme.typography.titleSmall)
                Text("More precise arrive/leave times, uses more battery.", style = MaterialTheme.typography.bodySmall)
            }
            Switch(checked = highAcc, onCheckedChange = {
                highAcc = it; Prefs.setBool(ctx, "highAcc", it); restart()
            })
        }
        HorizontalDivider()
        OutlinedButton(onClick = { exportCsv(ctx, Db.get(ctx).allEntries(), "timesheet-all.csv") }) {
            Text("Export all entries (CSV)")
        }
        Text(
            "How it works: while tracking is on, the app checks your location every few minutes. " +
                "When you stay within the radius for the set time, it logs a stop from when you arrived " +
                "until you leave. Times can be off by about one check interval, so tap any entry to adjust it. " +
                "Everything stays on your phone.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
fun ChoiceRow(title: String, options: List<Int>, selected: Int, label: (Int) -> String, onSelect: (Int) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(title, style = MaterialTheme.typography.titleSmall)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            options.forEach { o ->
                FilterChip(selected = o == selected, onClick = { onSelect(o) }, label = { Text(label(o)) })
            }
        }
    }
}

/** A tighter switch row for dialogs, so everything fits without scrolling. */
@Composable
fun CompactSwitchRow(text: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().height(40.dp).clickable { onChange(!checked) },
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(text, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
        Switch(checked = checked, onCheckedChange = onChange, modifier = Modifier.scale(0.8f))
    }
}

@Composable
fun SwitchRow(text: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(text, Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

/** Choose which days to include, sign, then print/save PDF or share the filled-in Excel form. */
@Composable
fun ExportDialog(weekStart: LocalDate, onEdit: () -> Unit, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val name = Prefs.name(ctx)
    val fri = true // Friday is always on the timesheet
    var sat by remember { mutableStateOf(Prefs.includeSaturday(ctx)) }
    var sun by remember { mutableStateOf(Prefs.includeSunday(ctx)) }
    var withSig by remember { mutableStateOf(Prefs.includeSignature(ctx)) }
    var sigVersion by remember { mutableIntStateOf(0) }
    var signing by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val version by Db.changes.collectAsState()
    val days = remember(version) { Timesheet.loadWeek(ctx, weekStart) }
    val unnamed = days.indices.filter { Timesheet.included(it, fri, sat, sun) }
        .sumOf { i -> days[i].rows.count { it.name == UNNAMED } }
    val missingBreaks = days.indices.count { i ->
        Timesheet.included(i, fri, sat, sun) && days[i].rows.isNotEmpty() && !days[i].hasBreak
    }
    val satHours = days[5].total
    val sunHours = days[6].total
    val sigBitmap = remember(sigVersion) {
        val f = Signature.file(ctx)
        if (f.exists()) BitmapFactory.decodeFile(f.path)?.asImageBitmap() else null
    }

    fun saveChoice() {
        Prefs.setBool(ctx, "incSat", sat)
        Prefs.setBool(ctx, "incSun", sun)
        Prefs.setBool(ctx, "incSig", withSig)
    }

    fun export(kind: String) {
                saveChoice()
                // Rebuilt from the database at the moment you tap, so it always has your latest changes.
                val days = Timesheet.loadWeek(ctx, weekStart)
                try {
                    when (kind) {
                        "pdf" -> Timesheet.sharePdf(
                            ctx, Timesheet.writePdf(ctx, name, weekStart, days, fri, sat, sun, withSig), name, weekStart,
                        )
                        "print" -> Timesheet.printPdf(
                            ctx, Timesheet.writePdf(ctx, name, weekStart, days, fri, sat, sun, withSig),
                        )
                        else -> Timesheet.shareXlsx(
                            ctx, Timesheet.writeXlsx(ctx, name, weekStart, days, fri, sat, sun, withSig), name, weekStart,
                        )
                    }
                    onDismiss()
                } catch (e: Exception) {
                    error = "Couldn't create the timesheet: ${e.message}"
                }
            }

    AlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier.fillMaxWidth(0.94f),
        properties = DialogProperties(usePlatformDefaultWidth = false),
        title = { Text("Timesheet", style = MaterialTheme.typography.titleMedium) },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(2.dp),
            ) {
                Text("$name · Week starting ${weekStart.format(WEEK_FMT)}", style = MaterialTheme.typography.bodySmall)
                CompactSwitchRow(
                    "Include Saturday" + if (satHours > 0) " (${fmtNum(satHours)} h)" else "",
                    sat,
                ) { sat = it }
                CompactSwitchRow(
                    "Include Sunday" + if (sunHours > 0) " (${fmtNum(sunHours)} h)" else "",
                    sun,
                ) { sun = it }
                val shownTotal = round1(days.indices.filter { Timesheet.included(it, fri, sat, sun) }.sumOf { days[it].total })
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Total: ${fmtNum(shownTotal)} h", Modifier.weight(1f), style = MaterialTheme.typography.titleSmall)
                    TextButton(onClick = onEdit) { Text("Review / edit") }
                }
                if (sigBitmap != null) {
                    CompactSwitchRow("Add my signature", withSig) { withSig = it }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.weight(1f).height(40.dp).background(Color.White),
                            contentAlignment = Alignment.Center,
                        ) {
                            Image(sigBitmap, contentDescription = "Your signature", modifier = Modifier.fillMaxHeight())
                        }
                        TextButton(onClick = { signing = true }) { Text("Sign again") }
                    }
                } else {
                    OutlinedButton(onClick = { signing = true }, modifier = Modifier.fillMaxWidth()) { Text("Sign timesheet") }
                }

                if (unnamed > 0) {
                    Text(
                        "$unnamed line${if (unnamed > 1) "s are" else " is"} still \"$UNNAMED\". Name them first if you can.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                    )
                }
                if (missingBreaks > 0) {
                    Text(
                        "$missingBreaks day${if (missingBreaks > 1) "s have" else " has"} no break entered.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                    )
                }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }

            }
        },
        confirmButton = {
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(onClick = { export("pdf") }, modifier = Modifier.fillMaxWidth()) { Text("Send as PDF") }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { export("xlsx") }, modifier = Modifier.weight(1f)) { Text("Send Excel") }
                    OutlinedButton(onClick = { export("print") }, modifier = Modifier.weight(1f)) { Text("Print PDF") }
                }
                TextButton(onClick = onDismiss, modifier = Modifier.align(Alignment.End)) { Text("Close") }
            }
        },
    )

    if (signing) {
        SignatureDialog(onDismiss = { signing = false }) {
            signing = false
            withSig = true
            sigVersion++
        }
    }
}

/** Set the break/lunch length for one day. */
@Composable
fun BreakDialog(date: LocalDate, current: Int, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var text by remember { mutableStateOf(if (current > 0) current.toString() else "") }
    var error by remember { mutableStateOf<String?>(null) }
    val save: (Int) -> Unit = { mins ->
        Db.get(ctx).setBreak(date, mins)
        onDismiss()
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Break on ${date.format(DAY_FMT)}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(0, 15, 30, 45, 48, 60).forEach { m ->
                        FilterChip(
                            selected = text == m.toString() || (m == 0 && text.isBlank()),
                            onClick = { text = if (m == 0) "" else m.toString() },
                            label = { Text(if (m == 0) "None" else "$m min") },
                        )
                    }
                }
                OutlinedTextField(
                    value = text, onValueChange = { text = it },
                    label = { Text("Minutes") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                )
                Text(
                    "Moved out of that day's site hours and into the BREAK column.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(onClick = confirm@{
                val m = if (text.isBlank()) 0 else text.trim().toIntOrNull()
                if (m == null || m < 0 || m > 600) {
                    error = "Enter minutes between 0 and 600."
                    return@confirm
                }
                save(m)
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

// ---------------------------------------------------------------- Time settings

fun fmtClockMin(m: Int): String {
    val h = m / 60
    val h12 = if (h % 12 == 0) 12 else h % 12
    return "$h12:${"%02d".format(m % 60)} ${if (h < 12) "AM" else "PM"}"
}

/** Accepts "4:30 PM", "4:30pm", "16:30", "5 pm". Returns minutes after midnight. */
fun parseClock(s: String): Int? {
    val m = Regex("""^\s*(\d{1,2})(?::(\d{2}))?\s*(?:([aApP])\.?\s*[mM]?\.?)?\s*$""").find(s) ?: return null
    var h = m.groupValues[1].toInt()
    val min = m.groupValues[2].ifEmpty { "0" }.toInt()
    val ap = m.groupValues[3].lowercase()
    if (min > 59) return null
    if (ap.isNotEmpty()) {
        if (h !in 1..12) return null
        if (ap == "p" && h != 12) h += 12
        if (ap == "a" && h == 12) h = 0
    } else if (h > 23) {
        return null
    }
    return h * 60 + min
}

@Composable
fun TimeSetting(title: String, initial: Int, onSave: (Int) -> Unit) {
    var text by remember { mutableStateOf(fmtClockMin(initial)) }
    val parsed = parseClock(text)
    OutlinedTextField(
        value = text,
        onValueChange = {
            text = it
            parseClock(it)?.let(onSave)
        },
        label = { Text(title) },
        singleLine = true,
        isError = parsed == null,
        supportingText = { Text(if (parsed == null) "Use a time like 4:30 PM" else "Set to ${fmtClockMin(parsed)}") },
        modifier = Modifier.fillMaxWidth(),
    )
}

// ---------------------------------------------------------------- Add place by address

data class NewPlace(val lat: Double, val lng: Double, val name: String)

@Suppress("DEPRECATION")
fun geocode(ctx: Context, query: String, cb: (Pair<Double, Double>?) -> Unit) {
    val main = Handler(Looper.getMainLooper())
    Thread {
        val result = try {
            if (!Geocoder.isPresent()) {
                null
            } else {
                Geocoder(ctx, Locale.getDefault()).getFromLocationName(query, 1)
                    ?.firstOrNull()?.let { it.latitude to it.longitude }
            }
        } catch (_: Exception) {
            null
        }
        main.post { cb(result) }
    }.start()
}

@Composable
fun AddressDialog(onDismiss: () -> Unit, onFound: (NewPlace) -> Unit) {
    val ctx = LocalContext.current
    var name by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add a place by address") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = name, onValueChange = { name = it }, label = { Text("Name (e.g. Home, Church)") },
                    singleLine = true, modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = address, onValueChange = { address = it },
                    label = { Text("Address, city, state") }, modifier = Modifier.fillMaxWidth(),
                )
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(enabled = !busy && address.isNotBlank(), onClick = {
                busy = true
                error = null
                geocode(ctx, address.trim()) { r ->
                    busy = false
                    if (r == null) {
                        error = "Couldn't find that address. Try adding the city and state."
                    } else {
                        onFound(NewPlace(r.first, r.second, name.trim()))
                    }
                }
            }) { Text(if (busy) "Searching…" else "Find") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

// ---------------------------------------------------------------- Timesheet editor

/**
 * Review and edit the week, day by day. Everything here edits your actual entries (the same ones
 * as the Timesheet tab), so changes show up everywhere and in every export. Changes save as you make them.
 */
@Composable
fun SheetEditorDialog(weekStart: LocalDate, initialDay: Int, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val db = remember { Db.get(ctx) }
    val version by Db.changes.collectAsState()
    val zone = ZoneId.systemDefault()
    val from = weekStart.atStartOfDay(zone).toInstant().toEpochMilli()
    val to = weekStart.plusDays(7).atStartOfDay(zone).toInstant().toEpochMilli()
    val entries = remember(version) { db.entriesBetween(from, to) }
    val drives = remember(version) { db.drivesBetween(from, to).filter { it.status != Drive.LOGGED } }
    val breaks = remember(version) { db.breaksBetween(weekStart, weekStart.plusDays(7)) }
    val notes = remember(version) { db.notesBetween(weekStart, weekStart.plusDays(7)) }
    val days = remember(version) {
        Timesheet.buildWeek(weekStart, entries, Prefs.defaultCategory(ctx), breaks, notes)
    }
    var dayIdx by remember { mutableIntStateOf(initialDay.coerceIn(0, 6)) }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(Modifier.fillMaxSize().safeDrawingPadding()) {
                Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "Review timesheet · week of ${weekStart.format(WEEK_FMT)}",
                        Modifier.weight(1f).padding(start = 8.dp),
                        style = MaterialTheme.typography.titleMedium,
                    )
                    IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, "Close") }
                }
                FlowRow(
                    Modifier.padding(horizontal = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    days.forEachIndexed { i, d ->
                        FilterChip(
                            selected = i == dayIdx,
                            onClick = { dayIdx = i },
                            label = { Text(Timesheet.DAY_NAMES[i] + if (d.total > 0) " ${fmtNum(d.total)}" else "") },
                        )
                    }
                }
                val date = weekStart.plusDays(dayIdx.toLong())
                key(dayIdx) {
                    DayEditor(
                        date = date,
                        sheet = days[dayIdx],
                        entries = entries.filter { it.start.toLocalDate() == date }.sortedBy { it.start },
                        drives = drives.filter { it.start.toLocalDate() == date },
                        breakMin = breaks[date] ?: 0,
                        note = notes[date] ?: "",
                    )
                }
            }
        }
    }
}

@Composable
fun DayEditor(
    date: LocalDate, sheet: SheetDay, entries: List<Entry>, drives: List<Drive>, breakMin: Int, note: String,
) {
    val ctx = LocalContext.current
    val db = remember { Db.get(ctx) }
    var adding by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Entry?>(null) }
    var noteText by remember { mutableStateOf(note) }
    var customBreak by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text(date.format(java.time.format.DateTimeFormatter.ofPattern("EEEE, MMMM d")), style = MaterialTheme.typography.titleLarge)

        // What this day will look like on the timesheet
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row {
                    Column(Modifier.weight(1f)) {
                        Text("Start", style = MaterialTheme.typography.labelMedium)
                        Text(sheet.start?.let { decimalToClock(it) } ?: "–", style = MaterialTheme.typography.titleMedium)
                    }
                    Column(Modifier.weight(1f)) {
                        Text("Stop", style = MaterialTheme.typography.labelMedium)
                        Text(sheet.stop?.let { decimalToClock(it) } ?: "–", style = MaterialTheme.typography.titleMedium)
                    }
                    Column(Modifier.weight(1f)) {
                        Text("Total", style = MaterialTheme.typography.labelMedium)
                        Text("${fmtNum(sheet.total)} h", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                    }
                }
                if (sheet.rows.isNotEmpty()) HorizontalDivider()
                sheet.rows.forEach { row ->
                    Text(
                        "${row.name}: " + row.hours.entries.joinToString(" · ") { (col, h) ->
                            "${Categories.of(col)?.name?.lowercase()?.replaceFirstChar { it.uppercase() } ?: col} ${fmtNum(h)}"
                        },
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
            }
        }

        Text("Entries", style = MaterialTheme.typography.titleSmall)
        if (entries.isEmpty()) {
            Text("Nothing on this day yet.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        entries.forEach { e -> EntryEditCard(e) { editing = e } }
        drives.forEach { d -> DriveRow(d) }
        OutlinedButton(onClick = { adding = true }) { Text("+ Add entry") }

        Text("Break / lunch", style = MaterialTheme.typography.titleSmall)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val presets = listOf(0, 15, 30, 45, 48, 60)
            presets.forEach { m ->
                FilterChip(
                    selected = breakMin == m,
                    onClick = { db.setBreak(date, m) },
                    label = { Text(if (m == 0) "None" else "$m min") },
                )
            }
            FilterChip(
                selected = breakMin !in presets,
                onClick = { customBreak = true },
                label = { Text(if (breakMin !in presets) "$breakMin min" else "Other…") },
            )
        }

        OutlinedTextField(
            value = noteText,
            onValueChange = {
                noteText = it
                db.setDayNote(date, it)
            },
            label = { Text("Notes for this day") },
            modifier = Modifier.fillMaxWidth(),
        )
        Text(
            "Changes save automatically and show up on the Timesheet tab and in every PDF and Excel you send.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }

    if (adding) EntryDialog(null, date) { adding = false }
    editing?.let { e -> EntryDialog(e, date) { editing = null } }
    if (customBreak) BreakDialog(date, breakMin) { customBreak = false }
}

/** One entry with its times on a normal 12-hour clock; picking a time saves it straight away. */
@Composable
fun EntryEditCard(e: Entry, onEdit: () -> Unit) {
    val ctx = LocalContext.current
    val db = remember { Db.get(ctx) }
    var error by remember(e) { mutableStateOf<String?>(null) }
    val date = e.start.toLocalDate()
    val startT = e.start.toZoned().toLocalTime()
    val endT = e.end.toZoned().toLocalTime()

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(e.label, Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                Text(fmtDur(e.end - e.start), style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PickerField("Start", fmt12(startT), Modifier.weight(1f)) {
                    pickTime(ctx, startT) { t ->
                        val ns = epochMs(date, t)
                        if (!e.ongoing && ns >= e.end) {
                            error = "Start has to be before the end time."
                        } else {
                            error = null
                            db.updateEntry(e.copy(start = ns))
                        }
                    }
                }
                PickerField("End", if (e.ongoing) "Still there" else fmt12(endT), Modifier.weight(1f)) {
                    pickTime(ctx, endT) { t ->
                        error = null
                        db.updateEntry(e.copy(end = endMs(date, startT, t), ongoing = false))
                    }
                }
            }
            CategoryPicker("Work type", e.category ?: Prefs.defaultCategory(ctx)) { db.updateEntry(e.copy(category = it)) }
            error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            TextButton(onClick = onEdit) { Text("Name, date, notes, delete…") }
        }
    }
}

// ---------------------------------------------------------------- Signature

private val INK = Color(0xFF0F1950)

@Composable
fun SignatureDialog(onDismiss: () -> Unit, onSaved: () -> Unit) {
    val ctx = LocalContext.current
    val density = LocalDensity.current
    val strokes = remember { mutableStateListOf<List<Offset>>() }
    var current by remember { mutableStateOf<List<Offset>>(emptyList()) }
    var error by remember { mutableStateOf<String?>(null) }

    // Turn the phone sideways while signing, for a wide signature; put it back afterwards.
    val activity = ctx as? android.app.Activity
    androidx.compose.runtime.DisposableEffect(Unit) {
        val before = activity?.requestedOrientation
        activity?.requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        onDispose {
            activity?.requestedOrientation = before ?: android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 8.dp), shape = MaterialTheme.shapes.large) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Sign with your finger", style = MaterialTheme.typography.titleMedium)
                Box(
                    Modifier.fillMaxWidth().height(170.dp).background(Color.White).border(1.dp, Color.Gray),
                ) {
                    Canvas(
                        Modifier.fillMaxSize().pointerInput(Unit) {
                            detectDragGestures(
                                onDragStart = { current = listOf(it) },
                                onDragEnd = {
                                    if (current.size > 1) strokes.add(current)
                                    current = emptyList()
                                },
                                onDragCancel = { current = emptyList() },
                            ) { change, _ ->
                                change.consume()
                                current = current + change.position
                            }
                        },
                    ) {
                        drawLine(
                            Color.LightGray, Offset(24f, size.height * 0.75f),
                            Offset(size.width - 24f, size.height * 0.75f), strokeWidth = 2f,
                        )
                        val w = 3.dp.toPx()
                        (strokes + listOf(current)).forEach { pts ->
                            if (pts.size > 1) {
                                val path = Path().apply {
                                    moveTo(pts[0].x, pts[0].y)
                                    pts.drop(1).forEach { lineTo(it.x, it.y) }
                                }
                                drawPath(path, INK, style = Stroke(width = w, cap = StrokeCap.Round, join = StrokeJoin.Round))
                            }
                        }
                    }
                }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { strokes.clear() }) { Text("Clear") }
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    Button(onClick = {
                        if (strokes.isEmpty()) {
                            error = "Sign in the white box first."
                        } else {
                            saveSignature(ctx, strokes.toList(), with(density) { 3.dp.toPx() })
                            onSaved()
                        }
                    }) { Text("Use signature") }
                }
            }
        }
    }
}

/** Crops the strokes to their bounds and saves a transparent PNG for the timesheet. */
fun saveSignature(ctx: Context, strokes: List<List<Offset>>, strokePx: Float) {
    val all = strokes.flatten()
    val pad = strokePx * 2
    val minX = all.minOf { it.x } - pad
    val minY = all.minOf { it.y } - pad
    val w = (all.maxOf { it.x } + pad - minX).toInt().coerceAtLeast(1)
    val h = (all.maxOf { it.y } + pad - minY).toInt().coerceAtLeast(1)
    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val canvas = android.graphics.Canvas(bmp)
    val paint = android.graphics.Paint().apply {
        color = android.graphics.Color.rgb(15, 25, 80)
        strokeWidth = strokePx
        style = android.graphics.Paint.Style.STROKE
        strokeCap = android.graphics.Paint.Cap.ROUND
        strokeJoin = android.graphics.Paint.Join.ROUND
        isAntiAlias = true
    }
    strokes.forEach { pts ->
        val path = android.graphics.Path()
        path.moveTo(pts[0].x - minX, pts[0].y - minY)
        pts.drop(1).forEach { path.lineTo(it.x - minX, it.y - minY) }
        canvas.drawPath(path, paint)
    }
    Signature.file(ctx).outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
}
