"""Job-task card art: one definition -> Pillow preview + generated Kotlin.

Coordinates are dp, origin at (card right edge - 10dp, card bottom); y grows downward (so art sits at negative y).
Styles: ink (stroke), faint (stroke), fill (ink*0.18), glass (ink*0.35), bg (card colour), solid (ink fill).
"""
import math

ST = {"ink": 0, "faint": 1, "fill": 2, "glass": 3, "bg": 4, "solid": 5}

def line(x1, y1, x2, y2, st="ink", sw=1.0):
    return ("line", x1, y1, x2, y2, st, sw)

def rect(x, y, w, h, r=0.0, st="fill", sw=1.0):
    return ("rect", x, y, w, h, r, st, sw)

def circ(cx, cy, r, st="fill", sw=1.0):
    return ("circle", cx, cy, r, st, sw)

def poly(pts, closed=True, st="fill", sw=1.0):
    return ("poly", [tuple(p) for p in pts], closed, st, sw)

def box(x, y, w, h, r=0.0, fill="fill", edge="ink"):
    return [rect(x, y, w, h, r, fill), rect(x, y, w, h, r, edge)]

def shape(pts, fill="fill", edge="ink"):
    return [poly(pts, True, fill), poly(pts, True, edge)]

def ring(cx, cy, r, fill="fill", edge="ink"):
    return [circ(cx, cy, r, fill), circ(cx, cy, r, edge)]

def arc(cx, cy, rx, ry, a0, a1, n=12):
    return [(cx + math.cos(math.radians(a0 + (a1 - a0) * i / n)) * rx,
             cy + math.sin(math.radians(a0 + (a1 - a0) * i / n)) * ry) for i in range(n + 1)]

def wave(x0, y0, x1, y1, amp=1.5, waves=2, n=16):
    pts = []
    for i in range(n + 1):
        t = i / n
        x = x0 + (x1 - x0) * t
        y = y0 + (y1 - y0) * t
        # perpendicular wiggle
        dx, dy = x1 - x0, y1 - y0
        L = math.hypot(dx, dy) or 1
        px, py = -dy / L, dx / L
        s = math.sin(t * waves * 2 * math.pi) * amp
        pts.append((x + px * s, y + py * s))
    return pts


def quad(p0, c, p1, n=12):
    return [((1 - t) ** 2 * p0[0] + 2 * (1 - t) * t * c[0] + t * t * p1[0],
             (1 - t) ** 2 * p0[1] + 2 * (1 - t) * t * c[1] + t * t * p1[1]) for t in [i / n for i in range(n + 1)]]


def rotate(pts, cx, cy, deg):
    a = math.radians(deg)
    ca, sa = math.cos(a), math.sin(a)
    return [(cx + (x - cx) * ca - (y - cy) * sa, cy + (x - cx) * sa + (y - cy) * ca) for x, y in pts]


def translate(prims, dx, dy):
    out = []
    for pr in prims:
        k = pr[0]
        if k == "line":
            out.append((k, pr[1] + dx, pr[2] + dy, pr[3] + dx, pr[4] + dy) + pr[5:])
        elif k in ("rect", "circle"):
            out.append((k, pr[1] + dx, pr[2] + dy) + pr[3:])
        else:
            out.append((k, [(x + dx, y + dy) for x, y in pr[1]]) + pr[2:])
    return out


ICONS = {}

# ---------------------------------------------------------------- E  Shop · Fab / piping: pipe spool (flange + elbow) and a welding hood
def _E():
    p = []
    # pipe spool: flange, run, elbow, riser
    p += box(-118, -12, 46, 10)
    p += box(-122, -17, 4, 20, 1)
    p += [circ(-120, -14, 0.8, "solid"), circ(-120, 0, 0.8, "solid")]
    outer = arc(-72, -18, 16, 16, 90, 0)
    inner = arc(-72, -18, 6, 6, 0, 90)
    p += shape(outer + inner)
    p += box(-66, -32, 10, 14)
    p += box(-68, -34, 14, 3, 1)                     # riser flange
    for x in (-98,):
        p.append(poly(wave(x, -12, x, -2, 0.8, 3), False, "faint"))
    p.append(poly(wave(-72, -12, -72, -2, 0.8, 3), False, "faint"))
    p.append(poly(wave(-66, -18, -56, -18, 0.8, 3), False, "faint"))
    # sheet-metal square-to-round transition (duct fab)
    p += shape([(-46, -10), (-20, -10), (-20, -3), (-46, -3)])                    # base collar, front
    p += shape([(-20, -10), (-13, -14), (-13, -7), (-20, -3)], "glass", "ink")     # base collar, side
    p += shape([(-46, -10), (-20, -10), (-24, -24), (-36, -24)])                  # transition, front
    p += shape([(-20, -10), (-13, -14), (-21, -25), (-24, -24)], "glass", "ink")   # transition, side
    for (bx, by), (tx, ty) in (((-46, -10), (-34, -24)), ((-20, -10), (-27, -24)), ((-20, -10), (-31, -24))):
        p.append(line(bx, by, tx, ty, "faint"))                                    # fold lines
    p += box(-36.5, -30, 13, 5.5, 0.5)                                             # round collar
    p.append(poly(arc(-30, -30, 6.5, 2, 0, 360, 20), True, "ink"))
    p.append(poly(arc(-30, -30, 6.5, 2, 0, 360, 20), True, "glass"))
    p.append(line(-46, -6.5, -20, -6.5, "faint"))                                  # Pittsburgh seam
    return p
ICONS["E"] = _E()

# ---------------------------------------------------------------- F  Shop · Misc: desk with a lamp and papers
def _F():
    p = []
    p += box(-96, -24, 70, 4, 1)                     # desktop
    p += box(-92, -20, 22, 20)                       # drawer pedestal
    for y in (-14, -8):
        p.append(line(-92, y, -70, y, "faint"))
    for y in (-17, -11, -5):
        p.append(line(-84, y, -78, y, "ink", 1.2))  # drawer pulls
    p += box(-32, -20, 3, 20)                        # right leg
    # lamp at the left end
    p += box(-92, -26, 10, 2, 1)
    p.append(line(-87, -26, -82, -36, "ink", 1.2))
    p.append(line(-82, -36, -74, -32, "ink", 1.2))
    p += shape([(-77, -35), (-68, -30), (-71, -27), (-78, -31)])
    # papers and a mug
    p += box(-60, -27, 16, 3, 0.5)
    p += box(-58, -30, 14, 3, 0.5)
    p += box(-40, -31, 7, 7, 1)
    p.append(poly(arc(-33, -27.5, 2.5, 2.5, -90, 90, 6), False, "ink"))
    return p
ICONS["F"] = _F()

# ---------------------------------------------------------------- G  Shop · Plan review: open drawing, rolled print and a pencil
def _G():
    p = []
    sheet = [(-82, -28), (-36, -28), (-32, -2), (-86, -2)]
    p += shape(sheet)
    for i in range(1, 5):                             # faint grid
        t = i / 5
        p.append(line(-82 + (-86 + 82) * t, -28 + 26 * t, -36 + (-32 + 36) * t, -28 + 26 * t, "faint"))
    # a little floor plan
    p.append(poly([(-74, -24), (-48, -24), (-46, -7), (-76, -7)], True, "ink"))
    p.append(line(-61, -24, -60, -14, "ink"))
    p.append(line(-75, -14, -54, -14, "ink"))
    # rolled print behind, to the left
    p += box(-122, -10, 34, 8, 4)
    p += ring(-118, -6, 4)
    p.append(circ(-118, -6, 1.5, "ink"))
    # pencil lying across the corner
    pen = [(-28, -4), (-6, -18), (-4, -15), (-26, -1)]
    p += shape(pen)
    p += shape([(-28, -4), (-26, -1), (-31, 0)], "glass", "ink")
    return p
ICONS["G"] = _G()

# ---------------------------------------------------------------- H  Job site · Install duct: a section of duct and aviation snips
def _H():
    p = []
    p += shape([(-96, -20), (-38, -20), (-38, -2), (-96, -2)])                   # long face
    p += shape([(-96, -20), (-38, -20), (-30, -27), (-88, -27)], "glass", "ink")  # top face
    p += shape([(-38, -20), (-38, -2), (-30, -9), (-30, -27)], "fill", "ink")     # end face
    p.append(line(-38, -20, -30, -9, "faint"))                                    # cross-break
    p.append(line(-38, -2, -30, -27, "faint"))
    p.append(line(-67, -20, -67, -2, "faint"))                                     # joint
    p.append(line(-67, -20, -59, -27, "faint"))
    for x in (-92, -80, -54, -44):
        p.append(circ(x, -5, 0.7, "solid"))                                        # screws
    # aviation snips (compound action), jaws toward the duct
    p += shape([(-121, -12.5), (-108, -11.2), (-101, -9.3), (-121, -9.2)], "glass", "ink")   # top jaw
    p += shape([(-121, -8.8), (-101, -9.0), (-108, -7.0), (-121, -5.6)], "glass", "ink")    # bottom jaw
    p += box(-129, -13, 10, 8.5, 2)                                                      # linkage plate
    p += [circ(-126, -11, 1.1, "ink"), circ(-122, -7, 1.1, "ink")]
    p += shape([(-129, -12.6), (-139, -14.2), (-139, -11.6), (-129, -10.6)])               # steel handles
    p += shape([(-129, -6.9), (-139, -5.9), (-139, -3.3), (-129, -4.9)])
    p += box(-162, -15, 24, 4, 2, "glass", "ink")                                        # rubber grips
    p += box(-162, -6.6, 24, 4, 2, "glass", "ink")
    p.append(line(-139, -13, -139, -12.2, "ink"))
    p.append(poly(wave(-136, -10.8, -136, -6.8, 0.8, 2), False, "faint"))                  # spring
    p.append(poly(arc(-162, -8.8, 3, 4.6, 90, 270, 8), False, "faint"))                   # latch loop
    return p
ICONS["H"] = _H()

# ---------------------------------------------------------------- I  Job site · Millwright: precision level and a gear
def _I():
    p = []
    p += box(-114, -9, 70, 7, 1.5)
    p += box(-83, -8, 10, 5, 2, "glass", "faint")
    p.append(circ(-78, -5.5, 1.4, "bg"))
    for x in (-108, -54):
        p.append(line(x, -9, x, -2, "faint"))
    teeth = []
    n = 10
    for i in range(n):
        a0 = i * 360 / n
        for da, r in ((-9, 10), (-5, 13), (5, 13), (9, 10)):
            a = math.radians(a0 + da)
            teeth.append((-24 + math.cos(a) * r, -14 + math.sin(a) * r))
    p += shape(teeth)
    p.append(circ(-24, -14, 6, "faint"))
    p.append(circ(-24, -14, 3, "bg"))
    p.append(circ(-24, -14, 3, "ink"))
    return p
ICONS["I"] = _I()

# ---------------------------------------------------------------- J  Job site · Piping: a threaded tee and a pipe wrench
def _J():
    p = []
    tee = [(-110, -12), (-88, -12), (-88, -26), (-78, -26), (-78, -12), (-62, -12),
           (-62, -2), (-110, -2)]
    p += shape(tee)
    for x in (-107, -104, -68, -65):
        p.append(line(x, -12, x, -2, "faint"))
    for y in (-23, -20):
        p.append(line(-88, y, -78, y, "faint"))
    # pipe wrench: I-beam handle with hang hole, housing, hook jaw, knurled nut
    handle = [(-54, -7.5), (-22, -9), (-22, -2), (-54, -3.5)]
    p += shape(handle)
    p.append(circ(-50, -5.5, 1.3, "bg"))
    p.append(circ(-50, -5.5, 1.3, "ink"))
    p.append(line(-46, -5.5, -26, -5.5, "faint"))
    p += shape([(-24, -14), (-12, -14), (-12, -2), (-24, -2)])                    # frame / housing
    heel = [(-34, -10), (-24, -10), (-24, -14)]
    for x in (-26, -28.5, -31, -33.5):
        heel += [(x, -15.6), (x - 1.25, -14)]
    p += shape(heel)                                                               # heel jaw with teeth
    p += box(-18, -31, 5, 17, 1)                                                   # hook shank
    p += shape([(-35, -31), (-13, -31), (-13, -27.5), (-21, -26.6)] +
               [pt for x in (-21, -23.5, -26, -28.5, -31, -33.5) for pt in ((x - 1.25, -25), (x - 2.5, -26.6))] +
               [(-35, -26.6)])                                                     # hook jaw with teeth
    p += box(-21.5, -23, 12, 6, 2, "glass", "ink")                                 # knurled nut
    for x in (-18.5, -15.5, -12.5):
        p.append(line(x, -23, x, -17, "faint"))
    return p
ICONS["J"] = _J()

# ---------------------------------------------------------------- K  Job site · Electrical: screwdriver and a coil of wire
def _K():
    p = []
    # screwdriver: grip with flutes, ferrule, shaft, tip
    p += box(-110, -11, 22, 9, 4)
    for x in (-104, -99, -94):
        p.append(line(x, -10, x, -3, "faint"))
    p += box(-89, -9, 3, 5, 1, "glass", "ink")
    p += box(-86, -7.5, 24, 2, 1)
    p += shape([(-62, -7.8), (-57, -7.2), (-57, -5.8), (-62, -5.2)], "glass", "ink")
    # coil of wire with a stripped end and a couple of wire nuts
    for rx, ry in ((13, 9.5), (10.5, 7.5), (8, 5.5)):
        p.append(poly(arc(-30, -12, rx, ry, 0, 360, 24), True, "ink"))
    p.append(poly(quad((-17, -10), (-12, -4), (-6, -6), 8), False, "ink", 1.2))
    p.append(line(-6, -6, -3, -7, "faint", 1.2))
    for cx in (-50, -45):
        p += shape([(cx - 2.6, -2), (cx + 2.6, -2), (cx + 1.2, -8), (cx - 1.2, -8)], "glass", "ink")
        p.append(line(cx - 1.8, -4.5, cx + 1.8, -4.5, "faint"))
    return p
ICONS["K"] = _K()

# ---------------------------------------------------------------- L  Job site · Controls: thermostat and a multimeter with leads
def _L():
    p = []
    p += box(-38, -28, 26, 26, 6)
    p.append(circ(-25, -15, 9, "faint"))
    p += box(-30, -18, 10, 5, 1, "glass", "faint")
    p.append(line(-25, -24, -25, -22, "ink", 1.2))
    # multimeter
    p += box(-80, -30, 20, 28, 3)
    p += box(-77, -27, 14, 7, 1, "glass", "faint")
    p += ring(-70, -12, 4.5)
    p.append(line(-70, -12, -67, -15, "ink", 1.2))
    p.append(poly(wave(-76, -2, -110, -4, 1.5, 1), False, "ink"))
    p.append(poly(wave(-64, -2, -104, 0, 1.5, 1), False, "faint"))
    p += box(-116, -6, 6, 3, 1)
    return p
ICONS["L"] = _L()

# ---------------------------------------------------------------- M  Job site · Insulating: tape measure and utility knife
def _M():
    p = []
    # tape measure: case with rounded back, belt clip, lock, window, blade + hook
    case = arc(-24, -16, 14, 14, 270, 450, 14) + [(-38, -2), (-38, -24), (-36, -28), (-24, -30)]
    p += shape(case)
    p += box(-12, -24, 3, 16, 1.5)                                                # belt clip
    p += ring(-24, -16, 8, "bg", "faint")
    p.append(circ(-24, -16, 4.5, "faint"))
    p.append(circ(-24, -16, 1.4, "solid"))
    p += box(-35, -27, 9, 3.5, 1.7, "glass", "ink")                                # lock slider
    p += box(-38, -9, 3, 7, 1, "glass", "ink")                                    # blade exit / bumper
    p += shape([(-96, -6), (-38, -6.5), (-38, -2), (-96, -2)])                    # blade (slightly cupped)
    for i, x in enumerate(range(-92, -40, 4)):
        p.append(line(x, -6, x, -3.2 if i % 4 == 0 else -4.6, "faint"))
    p += box(-98, -8, 2.5, 8, 0.6, "solid")                                       # hook
    # fillet knife: long thin flexible blade with an upswept tip
    kn = []
    blade = quad((-66, -21.5), (-100, -22.5), (-126, -24.5)) + quad((-126, -24.5), (-104, -17), (-66, -16.5))
    kn += shape(blade, "glass", "ink")
    kn.append(poly(quad((-70, -18.2), (-98, -18.6), (-120, -22.2), 10), False, "faint"))   # edge bevel
    kn += box(-68, -24, 3, 10, 1)                                                  # finger guard
    kn += box(-65, -22.5, 24, 7.5, 3.75)                                           # handle
    kn += [circ(-58, -18.75, 0.9, "solid"), circ(-49, -18.75, 0.9, "solid")]
    kn.append(circ(-44, -18.75, 1.1, "faint"))                                     # lanyard hole
    p += translate(kn, -5, -1)
    return p
ICONS["M"] = _M()

# ---------------------------------------------------------------- N  Job site · Demo: sledgehammer and rubble
def _N():
    p = []
    # sledgehammer: tapered hickory handle, steel head with beveled faces
    p += shape([(-120, -6.5), (-60, -8), (-60, -3), (-120, -2.5)])
    p += box(-122, -7.5, 6, 6, 2.5)                                               # knob end
    p.append(line(-112, -4.5, -96, -4.9, "faint"))
    head = [(-64, -17), (-50, -17), (-48, -15), (-48, 1), (-50, 3), (-64, 3), (-66, 1), (-66, -15)]
    p += shape(head)
    p.append(line(-66, -13, -48, -13, "faint"))
    p.append(line(-66, -1, -48, -1, "faint"))
    p += box(-60, -10, 6, 7, 1, "glass", "faint")                                 # wedge / eye
    # broken cinder block and chunks
    block = [(-40, -2), (-40, -16), (-26, -16), (-23, -12), (-25, -8), (-22, -5), (-23, -2)]
    p += shape(block)
    p += box(-37, -13, 5, 8, 1, "glass", "faint")                                 # core hole
    p.append(poly([(-30, -16), (-31, -11), (-28, -8), (-30, -4)], False, "faint"))  # crack
    for pts in ([(-18, -2), (-16, -7), (-11, -8), (-8, -2)],
                [(-20, -10), (-17, -14), (-13, -12), (-15, -9)]):
        p += shape(pts)
    for (x, y) in ((-6, -10), (-9, -13), (-4, -6), (-21, -18)):
        p.append(circ(x, y, 0.8, "faint"))                                        # dust
    return p
ICONS["N"] = _N()

# ---------------------------------------------------------------- O  Job site · Gen. labor / misc: hard hat and a shovel
def _O():
    p = []
    # cap-style hard hat with ribs, front bill and a sticker
    dome = arc(-30, -7, 15, 16, 180, 360, 16)
    p += shape(dome)
    p += shape(quad((-46, -7), (-30, -4.5), (-14, -7)) + [(-12, -6), (-10, -4)] +
               quad((-10, -4), (-30, -1.5), (-48, -4.5)), "fill", "ink")          # brim with front bill
    for dx in (-5, 0, 5):
        p.append(poly(quad((-30 + dx * 2.2, -7.5), (-30 + dx * 1.5, -20), (-30 + dx * 0.4, -22.5), 8), False, "faint"))
    p += ring(-21, -14, 2.4, "glass", "faint")                                    # sticker
    # round-point shovel with D-grip
    p += box(-124, -10, 9, 8, 3, "bg", "ink")
    p += box(-116, -7.5, 48, 3, 1.5)
    p += box(-70, -8.5, 5, 5, 1)                                                  # socket
    blade = quad((-66, -12), (-56, -13), (-50, -6)) + quad((-50, -6), (-56, 1), (-66, 0))
    p += shape(blade)
    p.append(line(-64, -6, -54, -6, "faint"))
    return p
ICONS["O"] = _O()

# ---------------------------------------------------------------- P  Job site · Coordination / supervisory: clipboard and radio
def _P():
    p = []
    p += box(-80, -30, 22, 28, 2)
    p += box(-73, -32, 8, 4, 1, "glass", "ink")
    for y in (-23, -16, -9):
        p.append(poly([(-77, y), (-75.5, y + 1.5), (-73, y - 2)], False, "ink"))
        p.append(line(-70, y, -62, y, "faint"))
    # radio
    p += box(-48, -24, 13, 22, 3)
    p.append(line(-38, -24, -38, -31, "ink", 1.6))
    p += box(-45, -21, 7, 5, 1, "glass", "faint")
    for y in (-12, -9, -6):
        p.append(line(-45, y, -38, y, "faint"))
    return p
ICONS["P"] = _P()

# ---------------------------------------------------------------- Q  Job site · Warranty / punchlist / service: toolbox and gauge manifold
def _Q():
    p = []
    # manifold with two gauges and hoses
    p += box(-82, -12, 40, 7, 2)
    for cx in (-72, -52):
        p += ring(cx, -21, 8)
        p.append(line(cx, -21, cx + 4, -25, "ink", 1.2))
        p.append(poly(arc(cx, -21, 5.5, 5.5, 150, 390, 8), False, "faint"))
    p.append(poly(wave(-78, -5, -92, 0, 1, 1), False, "ink"))
    p.append(poly(wave(-62, -5, -58, 2, 1, 1), False, "ink"))
    p.append(poly(wave(-46, -5, -36, 0, 1, 1), False, "ink"))
    # small service toolbox
    p += box(-30, -14, 26, 12, 1.5)
    p.append(line(-30, -10, -4, -10, "faint"))
    p.append(poly(arc(-17, -14, 5, 4, 180, 360, 8), False, "ink", 1.6))
    p += box(-19, -11, 4, 3, 0.5, "glass", "ink")
    return p
ICONS["Q"] = _Q()

# ---------------------------------------------------------------- T  School: stack of books with a grad cap, and a pencil
def _T():
    p = []
    p += box(-100, -8, 40, 6, 1)
    p += box(-96, -14, 34, 6, 1, "glass", "ink")
    p += box(-102, -20, 38, 6, 1)
    for x in (-66, -66, -68):
        pass
    p.append(line(-64, -7, -64, -3, "faint"))
    p.append(line(-66, -13, -66, -9, "faint"))
    p.append(line(-68, -19, -68, -15, "faint"))
    p += shape([(-83, -32), (-66, -27), (-83, -22), (-100, -27)])
    p += box(-89, -25, 12, 5, 1)
    p.append(line(-83, -27, -70, -24, "ink"))
    p.append(line(-70, -24, -70, -18, "ink", 1.2))
    # pencil
    p += shape([(-48, -6), (-14, -6), (-14, -2), (-48, -2)])
    p += shape([(-14, -6), (-6, -4), (-14, -2)], "glass", "ink")
    p += box(-52, -6, 4, 4, 1, "glass", "ink")
    return p
ICONS["T"] = _T()

# ---------------------------------------------------------------- U  Paid time off: fishing rod, bobber and ripples
def _U():
    p = []
    # water line with gentle waves
    p.append(poly(wave(-128, -2, -6, -2, 0.8, 9, 48), False, "faint"))
    # bent rod: cork grip, reel, guides, and line to a bobber
    rod = quad((-12, -6), (-52, -22), (-96, -31), 16)
    p.append(poly(rod, False, "ink", 1.6))
    p.append(line(-12, -6, -24, -11.5, "ink", 3.4))                              # cork grip
    p.append(line(-13, -6.5, -23, -11, "bg", 1.4))
    p += ring(-28, -9, 4)                                                         # reel
    p.append(line(-28, -9, -32, -5.5, "ink", 1.1))
    p.append(circ(-32, -5.5, 0.9, "solid"))
    for t in (0.35, 0.6, 0.82):
        x, y = rod[int(t * 16)]
        p.append(circ(x, y + 1.2, 0.9, "faint"))
    p.append(poly(quad((-96, -31), (-105, -21), (-112, -11), 10), False, "faint"))  # line
    p += shape(arc(-112, -8, 3.4, 3.4, 180, 360, 8) + [(-108.6, -8)], "glass", "ink")   # bobber top
    p += shape(arc(-112, -8, 3.4, 3.4, 0, 180, 8), "fill", "ink")                     # bobber bottom
    p.append(line(-112, -11.4, -112, -13.5, "ink", 1.0))
    for rx in (6.5, 10):
        p.append(poly(arc(-112, -4.5, rx, 1.8, 200, 340, 10), False, "faint"))
    # a little fish jumping
    fish = arc(-66, -12, 6, 3, 0, 360, 16)
    fish = rotate(fish, -66, -12, -20)
    p += shape(fish)
    p += shape(rotate([(-72, -12), (-76, -15), (-76, -9)], -66, -12, -20))
    p.append(circ(*rotate([(-62.5, -12.6)], -66, -12, -20)[0], 0.7, "solid"))
    p.append(poly(rotate(quad((-64, -14.4), (-65, -12), (-64, -9.6), 4), -66, -12, -20), False, "faint"))
    for (x, y) in ((-58, -5), (-61, -7.5), (-56, -8.5)):
        p.append(circ(x, y, 0.8, "faint"))                                        # splash drops
    # sun peeking in
    p.append(circ(-124, -30, 4.5, "fill"))
    p.append(circ(-124, -30, 4.5, "ink"))
    for a in range(0, 360, 45):
        r0, r1 = 6.5, 9
        p.append(line(-124 + math.cos(math.radians(a)) * r0, -30 + math.sin(math.radians(a)) * r0,
                      -124 + math.cos(math.radians(a)) * r1, -30 + math.sin(math.radians(a)) * r1, "faint", 1.1))
    return p
ICONS["U"] = _U()

# ---------------------------------------------------------------- V  Break: lunch pail and a coffee cup
def _V():
    p = []
    # dome-top lunch pail with latch and handle
    p += box(-76, -16, 36, 14, 2)
    p += shape(arc(-58, -16, 18, 7, 180, 360, 14))
    p.append(poly(arc(-58, -23.5, 7, 5, 180, 360, 10), False, "ink", 1.6))
    p += box(-60, -13, 4, 4, 0.8, "glass", "ink")
    p.append(line(-76, -9, -40, -9, "faint"))
    # mug with a saucer and curly steam
    p += box(-34, -5, 22, 3, 1.5, "fill", "ink")
    p += box(-31, -19, 14, 14, 3)
    p.append(poly(arc(-17, -13, 4, 3.6, -90, 90, 10), False, "ink", 1.3))
    p.append(line(-29, -16, -19, -16, "faint"))
    for x in (-27, -21.5):
        p.append(poly(wave(x, -21, x + 0.5, -31, 1.4, 1.25), False, "faint", 1.1))
    return p
ICONS["V"] = _V()


# ---------------------------------------------------------------- BREAK card: cheeseburger and fries
def _BREAK():
    p = []
    # fries standing in their carton (sticks first so the carton covers their bottoms)
    for x, top in ((-20.5, -27), (-17, -31), (-13.5, -28.5), (-10, -30.5), (-6.8, -26.5)):
        p += box(x, top, 2.6, -12 - top, 0.8)
    carton = quad((-23.5, -17), (-13, -11.5), (-2.5, -17), 10) + [(-4.5, -2), (-21.5, -2)]
    p += shape(carton, "glass", "ink")
    p.append(poly(arc(-13, -8, 3.2, 2.2, 0, 360, 14), True, "faint"))   # little logo on the carton
    # cheeseburger, side view
    p += box(-61, -9, 33, 7, 3.5)                                      # bottom bun
    p += box(-63, -14, 37, 5, 2.5, "glass", "ink")                     # patty
    p += shape([(-62, -15.6), (-27, -15.6), (-27, -14), (-33, -14), (-35, -10.2), (-37.5, -14), (-62, -14)])  # cheese + drip
    p.append(poly(wave(-64, -17, -25, -17, 1.1, 5, 40), False, "ink", 1.2))   # lettuce
    p += shape(arc(-44.5, -18, 17.5, 13, 180, 360, 18))                       # top bun
    for (x, y) in ((-52, -24.5), (-46, -28), (-40, -26), (-48, -21), (-38.5, -21.5), (-43.5, -23.5)):
        p.append(poly(rotate(arc(x, y, 1.3, 0.7, 0, 360, 8), x, y, -25), True, "glass"))  # sesame seeds
    return p
ICONS["BREAK"] = _BREAK()


# ================================================================ Kotlin generator
def fnum(v):
    v = round(v, 2)
    s = ("%.2f" % v).rstrip("0").rstrip(".")
    if s in ("-0", ""):
        s = "0"
    return s + "f"

def kotlin():
    out = []
    out.append('/** Faint task art for job cards, drawn in the same style as the travel vans. Generated from jobart.py. */')
    out.append('private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawJobArt(cat: String?, ink: Color, bg: Color) {')
    out.append('    val k = density')
    out.append('    val ox = size.width - 10 * k')
    out.append('    val oy = size.height')
    out.append('    val faint = ink.copy(alpha = ink.alpha * 0.55f)')
    out.append('    val fill = ink.copy(alpha = ink.alpha * 0.18f)')
    out.append('    val glass = ink.copy(alpha = ink.alpha * 0.35f)')
    out.append('    fun c(st: Int) = when (st) { 0 -> ink; 1 -> faint; 2 -> fill; 3 -> glass; 4 -> bg; else -> ink }')
    out.append('    fun ln(x1: Float, y1: Float, x2: Float, y2: Float, st: Int, sw: Float) =')
    out.append('        drawLine(c(st), Offset(ox + x1 * k, oy + y1 * k), Offset(ox + x2 * k, oy + y2 * k), strokeWidth = sw * k, cap = StrokeCap.Round)')
    out.append('    fun rc(x: Float, y: Float, w: Float, h: Float, r: Float, st: Int, sw: Float) {')
    out.append('        val tl = Offset(ox + x * k, oy + y * k)')
    out.append('        val sz = androidx.compose.ui.geometry.Size(w * k, h * k)')
    out.append('        val cr = androidx.compose.ui.geometry.CornerRadius(r * k)')
    out.append('        if (st >= 2) drawRoundRect(c(st), tl, sz, cr) else drawRoundRect(c(st), tl, sz, cr, style = Stroke(width = sw * k))')
    out.append('    }')
    out.append('    fun ci(x: Float, y: Float, r: Float, st: Int, sw: Float) {')
    out.append('        val ctr = Offset(ox + x * k, oy + y * k)')
    out.append('        if (st >= 2) drawCircle(c(st), r * k, ctr) else drawCircle(c(st), r * k, ctr, style = Stroke(width = sw * k))')
    out.append('    }')
    out.append('    fun pg(st: Int, sw: Float, closed: Boolean, vararg p: Float) {')
    out.append('        val path = Path()')
    out.append('        path.moveTo(ox + p[0] * k, oy + p[1] * k)')
    out.append('        var i = 2')
    out.append('        while (i < p.size) {')
    out.append('            path.lineTo(ox + p[i] * k, oy + p[i + 1] * k)')
    out.append('            i += 2')
    out.append('        }')
    out.append('        if (closed) path.close()')
    out.append('        if (st >= 2) {')
    out.append('            drawPath(path, c(st))')
    out.append('        } else {')
    out.append('            drawPath(path, c(st), style = Stroke(width = sw * k, cap = StrokeCap.Round, join = StrokeJoin.Round))')
    out.append('        }')
    out.append('    }')
    out.append('    when (cat) {')
    for col in sorted(ICONS):
        out.append('        "%s" -> {' % col)
        for pr in ICONS[col]:
            kind = pr[0]
            if kind == "line":
                _, x1, y1, x2, y2, st, sw = pr
                out.append('            ln(%s, %s, %s, %s, %d, %s)' % (fnum(x1), fnum(y1), fnum(x2), fnum(y2), ST[st], fnum(sw)))
            elif kind == "rect":
                _, x, y, w, h, r, st, sw = pr
                out.append('            rc(%s, %s, %s, %s, %s, %d, %s)' % (fnum(x), fnum(y), fnum(w), fnum(h), fnum(r), ST[st], fnum(sw)))
            elif kind == "circle":
                _, x, y, r, st, sw = pr
                out.append('            ci(%s, %s, %s, %d, %s)' % (fnum(x), fnum(y), fnum(r), ST[st], fnum(sw)))
            elif kind == "poly":
                _, pts, closed, st, sw = pr
                nums = ", ".join("%s, %s" % (fnum(x), fnum(y)) for x, y in pts)
                out.append('            pg(%d, %s, %s, %s)' % (ST[st], fnum(sw), "true" if closed else "false", nums))
        out.append('        }')
    out.append('    }')
    out.append('}')
    return "\n".join(out) + "\n"


# ================================================================ Pillow renderer
def render(d, prims, ox, oy, K, ink, bg):
    from PIL import Image, ImageDraw
    img = d._image

    def stroke(colr, fn):
        m = Image.new("L", img.size, 0)
        fn(ImageDraw.Draw(m))
        layer = Image.new("RGBA", img.size, colr[:3] + (0,))
        layer.putalpha(m.point(lambda v: v * colr[3] // 255))
        base = img.convert("RGBA")
        base.alpha_composite(layer)
        img.paste(base.convert(img.mode))

    def col(st):
        a = ink[3] / 255
        return {"ink": ink, "faint": ink[:3] + (round(a * 0.55 * 255),), "fill": ink[:3] + (round(a * 0.18 * 255),),
                "glass": ink[:3] + (round(a * 0.35 * 255),), "bg": bg, "solid": ink}[st]
    P = lambda x, y: (ox + x * K, oy + y * K)
    for pr in prims:
        kind = pr[0]
        if kind == "line":
            _, x1, y1, x2, y2, st, sw = pr
            if ST[st] >= 2:
                d.line([P(x1, y1), P(x2, y2)], fill=col(st), width=max(1, round(sw * K)))
            else:
                stroke(col(st), lambda m: m.line([P(x1, y1), P(x2, y2)], fill=255, width=max(1, round(sw * K))))
        elif kind == "rect":
            _, x, y, w, h, r, st, sw = pr
            box_ = [*P(x, y), *P(x + w, y + h)]
            if ST[st] >= 2:
                d.rounded_rectangle(box_, radius=r * K, fill=col(st))
            else:
                stroke(col(st), lambda m: m.rounded_rectangle(box_, radius=r * K, outline=255, width=max(1, round(sw * K))))
        elif kind == "circle":
            _, x, y, r, st, sw = pr
            cx, cy = P(x, y)
            b = [cx - r * K, cy - r * K, cx + r * K, cy + r * K]
            if ST[st] >= 2:
                d.ellipse(b, fill=col(st))
            else:
                stroke(col(st), lambda m: m.ellipse(b, outline=255, width=max(1, round(sw * K))))
        elif kind == "poly":
            _, pts, closed, st, sw = pr
            pp = [P(x, y) for x, y in pts]
            if ST[st] >= 2:
                d.polygon(pp, fill=col(st))
            else:
                if closed:
                    pp = pp + [pp[0]]
                stroke(col(st), lambda m: m.line(pp, fill=255, width=max(1, round(sw * K)), joint="curve"))
