package com.sitetime.app

import android.location.Location

const val UNNAMED = "Unnamed stop"

/** Pending drives show as "Drive to <place>". */
const val DRIVE_PREFIX = "Drive to "

/** Logged travel is named "Parts run for <job>" / "Travel for <job>"; its hours go on that job's line. */
const val PARTS_PREFIX = "Parts run for "
const val TRAVEL_PREFIX = "Travel for "
val TRAVEL_PREFIXES = listOf(PARTS_PREFIX, TRAVEL_PREFIX, DRIVE_PREFIX)

fun travelPrefix(cat: String) = if (cat == "R") PARTS_PREFIX else TRAVEL_PREFIX

/** A short stop at a business, logged with its drive as "Parts run to Menards for <job>". */
const val ERRAND_PREFIX = "Parts run to "

/** A short stop logged as lunch ("Lunch at Culver's"): goes in the BREAK column. */
const val LUNCH_PREFIX = "Lunch"

fun isDriveEntry(e: Entry) =
    (e.category == "R" || e.category == "S") &&
        (TRAVEL_PREFIXES.any { e.label.startsWith(it) } || isErrandLabel(e.label))

private fun isErrandLabel(label: String) =
    label.startsWith(ERRAND_PREFIX) && label.lastIndexOf(" for ") > ERRAND_PREFIX.length

fun isLunchEntry(e: Entry) = e.category == Categories.BREAK && e.label.startsWith(LUNCH_PREFIX)

/** "Parts run to Menards for Shop", or "Parts run for Shop" when the business isn't known. */
fun errandLabel(place: String?, job: String): String =
    if (place.isNullOrBlank() || place == UNNAMED) PARTS_PREFIX + job else "$ERRAND_PREFIX$place for $job"

/** The business in "Parts run to Menards for Shop" ("Menards"), or null. */
fun errandPlaceOf(label: String): String? =
    if (isErrandLabel(label)) label.substring(ERRAND_PREFIX.length, label.lastIndexOf(" for ")) else null

/** The job a travel entry is for ("Travel for Shop" -> "Shop"); for anything else, its own name. */
fun jobOf(label: String): String {
    if (isErrandLabel(label)) return label.substring(label.lastIndexOf(" for ") + 5)
    for (p in TRAVEL_PREFIXES) if (label.startsWith(p)) return label.removePrefix(p)
    return label
}

/** The timesheet line an entry belongs on: travel goes on the line of the job it was for. */
fun sheetLine(e: Entry) = if (isDriveEntry(e)) jobOf(e.label) else e.label

data class Site(
    val id: Long,
    val name: String,
    val lat: Double,
    val lng: Double,
    val radius: Double,
    val ignored: Boolean,
    val category: String? = null,
    /** Count the morning drive here as travel (otherwise the workday starts on arrival). */
    val morningTravel: Boolean = false,
)

data class Entry(
    val id: Long,
    val siteId: Long?,
    val label: String,
    val lat: Double?,
    val lng: Double?,
    val start: Long,
    val end: Long,
    val ongoing: Boolean,
    val note: String,
    val category: String? = null,
    val breakMin: Int = 0,
    /** A short stop somewhere that isn't a job site (see [Errands]): [ERRAND_MAYBE] while you're there, [ERRAND_ASK] once you've left. */
    val errand: Int = 0,
    /** What Google says the place is: "food" for restaurants and cafes, else null. */
    val placeKind: String? = null,
)

const val ERRAND_MAYBE = 1
const val ERRAND_ASK = 2

/** One location fix, kept for the map's route line. */
data class Fix(val t: Long, val lat: Double, val lng: Double, val acc: Float)

/** A drive detected between two work places. */
data class Drive(
    val id: Long,
    val start: Long,
    val end: Long,
    val from: String,
    val to: String,
    val status: Int,
    val entryId: Long?,
    /** The job this drive counts for, when it isn't simply where you arrived (e.g. a trip home for tools). */
    val job: String? = null,
    /** The short stop (parts run or lunch) this drive went to or from; it's answered along with that stop. */
    val errandId: Long? = null,
) {
    companion object {
        const val PENDING = 0
        const val LOGGED = 1
        const val SKIPPED = 2
        /** A drive to or from lunch: its time is already part of the break, so it's never logged. */
        const val LUNCH = 3
        /** Your first drive of the day, to a place where work starts when you arrive: kept aside, not counted. */
        const val IGNORED = 4
    }
}

fun distanceM(lat1: Double, lng1: Double, lat2: Double, lng2: Double): Float {
    val out = FloatArray(1)
    Location.distanceBetween(lat1, lng1, lat2, lng2, out)
    return out[0]
}
