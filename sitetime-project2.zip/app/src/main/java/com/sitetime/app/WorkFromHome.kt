package com.sitetime.app

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime

/**
 * Work-from-home mode: no GPS by default. You clock in and out yourself, and "Switch task" ends the
 * current line and starts the next one. "Track location today" turns normal tracking on for one day.
 */
object WorkFromHome {
    /** Turns the mode on or off (from setup or Settings). */
    fun setMode(ctx: Context, on: Boolean) {
        Prefs.setWfh(ctx, on)
        if (on) {
            Prefs.setWfhLocDay(ctx, "")
            Prefs.setLogOn(ctx, false)
            TrackingService.stop(ctx)
            Db.get(ctx).closeStaleOngoing(-1L, Prefs.clockId(ctx))
        } else {
            Prefs.setTrackingEnabled(ctx, true)
            if (Perms.hasLocation(ctx)) {
                try {
                    TrackingService.start(ctx)
                } catch (_: Exception) {
                }
            }
        }
        WfhReminders.schedule(ctx)
        Db.get(ctx).touch()
    }

    /** "Track location today": normal tracking (stops, drives, parts runs) until tomorrow morning. */
    fun setLocationToday(ctx: Context, on: Boolean) {
        if (on) {
            Prefs.setWfhLocDay(ctx, LocalDate.now().toString())
            Prefs.setTrackingEnabled(ctx, true)
            Prefs.setLogOn(ctx, true)
            try {
                TrackingService.send(ctx, TrackingService.ACTION_TRACK_DAY)
            } catch (_: Exception) {
            }
        } else {
            Prefs.setWfhLocDay(ctx, "")
            Prefs.setLogOn(ctx, false)
            TrackingService.stop(ctx)
            Db.get(ctx).closeStaleOngoing(-1L, Prefs.clockId(ctx))
        }
        Db.get(ctx).touch()
    }
}

/** The clock-in timesheet line for people working from home. */
object WorkClock {
    private const val SAME_TASK_MS = 2 * 60_000L

    /** The line you're clocked in on, or null. */
    fun current(ctx: Context): Entry? {
        val id = Prefs.clockId(ctx)
        if (id < 0) return null
        val e = Db.get(ctx).entry(id)
        if (e == null || !e.ongoing) {
            Prefs.setClockId(ctx, -1L)
            return null
        }
        return e
    }

    fun clockIn(ctx: Context, job: String = Prefs.wfhJob(ctx), cat: String = Prefs.wfhCategory(ctx)) {
        if (current(ctx) != null) return
        start(ctx, job, cat, System.currentTimeMillis())
    }

    fun clockOut(ctx: Context) {
        val e = current(ctx) ?: return
        Db.get(ctx).setEntryEnd(e.id, maxOf(System.currentTimeMillis(), e.start), ongoing = false)
        Prefs.setClockId(ctx, -1L)
        WfhReminders.clear(ctx)
    }

    /** Ends the current line and starts the next one (or just renames it if you only just started). */
    fun switchTask(ctx: Context, job: String, cat: String) {
        val db = Db.get(ctx)
        val now = System.currentTimeMillis()
        val e = current(ctx)
        if (e != null && now - e.start < SAME_TASK_MS) {
            db.updateEntry(e.copy(label = job, category = cat, end = now))
            remember(ctx, job, cat)
            return
        }
        if (e != null) db.setEntryEnd(e.id, now, ongoing = false)
        start(ctx, job, cat, now)
    }

    private fun start(ctx: Context, job: String, cat: String, at: Long) {
        val id = Db.get(ctx).insertEntry(
            Entry(
                id = 0, siteId = null, label = job, lat = null, lng = null, start = at, end = at,
                ongoing = true, note = "", category = cat,
            )
        )
        Prefs.setClockId(ctx, id)
        remember(ctx, job, cat)
        WfhReminders.clear(ctx)
    }

    private fun remember(ctx: Context, job: String, cat: String) {
        Prefs.setWfhJob(ctx, job)
        Prefs.setWfhCategory(ctx, cat)
    }

    /** Keeps the clocked-in line's end at "now". A line left open overnight ends at that day's workday end. */
    fun refresh(ctx: Context) {
        val e = current(ctx) ?: return
        val db = Db.get(ctx)
        val day = e.start.toLocalDate()
        if (day != LocalDate.now()) {
            val m = Prefs.workdayEndMin(ctx)
            val endAt = day.atStartOfDay(ZoneId.systemDefault()).plusMinutes(m.toLong()).toInstant().toEpochMilli()
            db.setEntryEnd(e.id, maxOf(e.start, endAt), ongoing = false)
            Prefs.setClockId(ctx, -1L)
        } else {
            db.setEntryEnd(e.id, maxOf(e.start, System.currentTimeMillis()), ongoing = true)
        }
    }
}

/**
 * Reminders when working from home (the tracking service isn't running then, so they use an alarm):
 * "Clock in?" on weekday mornings at the start-work reminder time, "Clock out?" at the wrapping-up time.
 */
object WfhReminders {
    const val ACTION_FIRE = "com.sitetime.app.WFH_REMIND"
    const val ACTION_CLOCK_IN = "com.sitetime.app.CLOCK_IN"
    const val ACTION_CLOCK_OUT = "com.sitetime.app.CLOCK_OUT"
    private const val CHANNEL = "reminders"
    private const val NOTIF_ID = 6
    private const val WINDOW_MIN = 30

    private fun intent(ctx: Context, action: String, code: Int) = PendingIntent.getBroadcast(
        ctx, code, Intent(ctx, WfhReceiver::class.java).setAction(action),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    fun clear(ctx: Context) = ctx.getSystemService(NotificationManager::class.java).cancel(NOTIF_ID)

    /** Sets the alarm for the next reminder time (or cancels it when not working from home). */
    fun schedule(ctx: Context) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val fire = intent(ctx, ACTION_FIRE, 40)
        val times = buildList {
            if (Prefs.startRemindOn(ctx)) add(Prefs.startRemindMin(ctx))
            if (Prefs.reminderOn(ctx)) add(Prefs.reminderMin(ctx))
        }
        if (!Prefs.wfh(ctx) || times.isEmpty()) {
            am.cancel(fire)
            return
        }
        val now = ZonedDateTime.now()
        var next: ZonedDateTime? = null
        for (d in 0L..7L) {
            for (m in times) {
                val t = now.toLocalDate().plusDays(d).atStartOfDay(now.zone).plusMinutes(m.toLong())
                if (t.isAfter(now.plusSeconds(30)) && (next == null || t.isBefore(next))) next = t
            }
        }
        val at = next?.toInstant()?.toEpochMilli() ?: return
        try {
            if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, fire)
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, fire)
            }
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, fire)
        }
    }

    fun fire(ctx: Context) {
        schedule(ctx)
        if (!Prefs.wfh(ctx)) return
        val now = ZonedDateTime.now()
        val m = now.hour * 60 + now.minute
        val weekend = now.dayOfWeek == DayOfWeek.SATURDAY || now.dayOfWeek == DayOfWeek.SUNDAY
        val clocked = WorkClock.current(ctx)
        val zone = ZoneId.systemDefault()
        val today = now.toLocalDate()
        val todays = Db.get(ctx).entriesBetween(
            today.atStartOfDay(zone).toInstant().toEpochMilli(),
            today.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli(),
        )
        when {
            Prefs.startRemindOn(ctx) && !weekend && clocked == null && todays.isEmpty() &&
                kotlin.math.abs(m - Prefs.startRemindMin(ctx)) <= WINDOW_MIN ->
                notify(ctx, "Clock in?", "Tap Clock in to start your timesheet for today.", "Clock in", ACTION_CLOCK_IN)
            Prefs.reminderOn(ctx) && clocked != null && kotlin.math.abs(m - Prefs.reminderMin(ctx)) <= WINDOW_MIN ->
                notify(
                    ctx, "Clock out?",
                    "Clocked in since ${fmtTime(clocked.start)} on ${clocked.label}. Tap Clock out when you're done.",
                    "Clock out", ACTION_CLOCK_OUT,
                )
        }
    }

    private fun notify(ctx: Context, title: String, text: String, button: String, action: String) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "End-of-day reminder", NotificationManager.IMPORTANCE_HIGH))
        val open = PendingIntent.getActivity(
            ctx, 41, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val n = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_pm)
            .setColor(0xFF283890.toInt())
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(open)
            .setAutoCancel(true)
            .addAction(0, button, intent(ctx, action, 42))
            .build()
        nm.notify(NOTIF_ID, n)
    }
}

/** The work-from-home reminder alarm and its Clock in / Clock out buttons. */
class WfhReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        when (intent.action) {
            WfhReminders.ACTION_FIRE -> WfhReminders.fire(ctx)
            WfhReminders.ACTION_CLOCK_IN -> WorkClock.clockIn(ctx)
            WfhReminders.ACTION_CLOCK_OUT -> WorkClock.clockOut(ctx)
        }
    }
}
