package com.sitetime.app

import android.content.Context
import android.location.Geocoder
import java.util.Locale

/**
 * Your home (an ignored place with any nickname; always the house pin on the map) and the office,
 * both pinned at the top of the Sites tab.
 */
object HomeOffice {
    const val OFFICE_NAME = "Office"
    const val OFFICE_ADDRESS = "429 Sanderson St, Poynette, WI 53955"

    /** Your home, or null if it isn't set yet. Older installs: a saved ignored place called "Home". */
    fun home(ctx: Context): Site? {
        val db = Db.get(ctx)
        val id = Prefs.homeSiteId(ctx)
        if (id >= 0) db.site(id)?.let { return it }
        val found = db.sites().firstOrNull { it.ignored && it.name.contains("home", ignoreCase = true) } ?: return null
        Prefs.setHomeSiteId(ctx, found.id)
        return found
    }

    /** Saves (or moves / renames) your home. It's always an ignored place, so time there never counts. */
    fun setHome(ctx: Context, lat: Double, lng: Double, name: String) {
        val db = Db.get(ctx)
        val cur = home(ctx)
        val id = if (cur != null) {
            db.updateSite(cur.copy(name = name.ifBlank { cur.name }, lat = lat, lng = lng, ignored = true, morningTravel = false))
            cur.id
        } else {
            db.addSite(name.ifBlank { "Home" }, lat, lng, Prefs.radiusM(ctx).toDouble(), true).also { Prefs.setHomeSiteId(ctx, it) }
        }
        db.site(id)?.let { db.assignUnnamedNear(it) }
        db.touch()
    }

    fun office(ctx: Context): Site? {
        val id = Prefs.officeSiteId(ctx)
        return if (id >= 0) Db.get(ctx).site(id) else null
    }

    /** Adds the office as a saved site once (looks up its address). Safe to call often. */
    fun ensureOffice(ctx: Context) {
        if (office(ctx) != null) return
        val db = Db.get(ctx)
        db.sites().firstOrNull { it.name.equals(OFFICE_NAME, ignoreCase = true) && !it.ignored }?.let {
            Prefs.setOfficeSiteId(ctx, it.id)
            db.touch()
            return
        }
        Thread {
            val spot = try {
                @Suppress("DEPRECATION")
                Geocoder(ctx, Locale.US).getFromLocationName(OFFICE_ADDRESS, 1)?.firstOrNull()
            } catch (_: Exception) {
                null
            } ?: return@Thread
            if (office(ctx) != null) return@Thread
            val id = db.addSite(OFFICE_NAME, spot.latitude, spot.longitude, Prefs.radiusM(ctx).toDouble(), false, Prefs.defaultCategory(ctx))
            Prefs.setOfficeSiteId(ctx, id)
            db.site(id)?.let { db.assignUnnamedNear(it) }
            db.touch()
        }.start()
    }
}
