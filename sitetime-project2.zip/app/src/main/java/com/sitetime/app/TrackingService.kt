package com.sitetime.app

import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority

class TrackingService : Service() {

    companion object {
        private const val CHANNEL = "tracking"
        private const val REMIND_CHANNEL = "reminders"
        private const val NOTIF_ID = 1
        private const val REMIND_ID = 2
        const val ACTION_DONE = "com.sitetime.app.DONE"
        const val ACTION_CONTINUE = "com.sitetime.app.CONTINUE"
        const val ACTION_RESUME = "com.sitetime.app.RESUME"
        const val ACTION_START_WORK = "com.sitetime.app.START_WORK"
        const val ACTION_WAKE = "com.sitetime.app.WAKE"
        const val ACTION_TRACK_DAY = "com.sitetime.app.TRACK_DAY"
        const val ACTION_LOG_OFF = "com.sitetime.app.LOG_OFF"
        private const val START_ID = 3
        /** While driving: a real GPS reading this often, so the route follows the roads. */
        private const val DRIVING_MS = 15_000L
        /** About 9 mph: faster than walking around a job site. */
        private const val MOVING_MPS = 4f
        /** Back to the normal interval after this long without moving. */
        private const val STILL_MS = 3 * 60_000L
        private const val WAKE_PROMPT_ID = 4

        /** Sends "Done for today" / "Resume" to the running service. */
        fun send(ctx: Context, action: String) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, TrackingService::class.java).setAction(action))
        }

        /** Starts tracking, or re-applies settings if it's already running. */
        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, TrackingService::class.java))
        }

        fun stop(ctx: Context) {
            cancelWake(ctx)
            Prefs.setResting(ctx, false)
            ctx.stopService(Intent(ctx, TrackingService::class.java))
        }

        private fun wakeIntent(ctx: Context) = PendingIntent.getBroadcast(
            ctx, 30, Intent(ctx, WakeReceiver::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

        /** Next time tracking hours begin (today if it's still early, otherwise tomorrow). */
        fun nextHoursStart(ctx: Context): Long {
            val now = java.time.ZonedDateTime.now()
            var t = now.toLocalDate().atStartOfDay(now.zone).plusMinutes(Prefs.hoursStartMin(ctx).toLong())
            if (!t.isAfter(now)) t = t.plusDays(1)
            return t.toInstant().toEpochMilli()
        }

        /** Alarm that switches tracking back on in the morning. */
        fun scheduleWake(ctx: Context) {
            val am = ctx.getSystemService(AlarmManager::class.java)
            val at = nextHoursStart(ctx)
            try {
                if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, wakeIntent(ctx))
                } else {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, wakeIntent(ctx))
                }
            } catch (e: SecurityException) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, wakeIntent(ctx))
            }
        }

        fun cancelWake(ctx: Context) {
            ctx.getSystemService(AlarmManager::class.java).cancel(wakeIntent(ctx))
        }

        /** If Android won't let the alarm restart tracking on its own, ask with a notification instead. */
        fun postWakePrompt(ctx: Context) {
            val start = PendingIntent.getForegroundService(
                ctx, 31, Intent(ctx, TrackingService::class.java).setAction(ACTION_WAKE),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            )
            val n = NotificationCompat.Builder(ctx, REMIND_CHANNEL)
                .setSmallIcon(R.drawable.ic_stat_pm)
                .setColor(0xFF283890.toInt())
                .setContentTitle("Start tracking for the day")
                .setContentText("Tap to turn location tracking back on.")
                .setContentIntent(start)
                .setAutoCancel(true)
                .build()
            ctx.getSystemService(NotificationManager::class.java).notify(WAKE_PROMPT_ID, n)
        }
    }

    private lateinit var fused: FusedLocationProviderClient
    private lateinit var detector: StayDetector

    /** Last stop checked for a business name, so each new stop is looked up once. */
    private var lastNamedId = -1L

    private fun nameTodaysStops() {
        val app = applicationContext
        kotlin.concurrent.thread { Places.nameUnnamedDay(app, java.time.LocalDate.now()) }
    }

    /**
     * Once a day, the first time tracking runs: weekdays turn Track day on (filling in the morning so far),
     * weekends turn it off. After that, whatever you set by hand stays for the rest of the day.
     */
    private fun applyAutoDay() {
        if (!Prefs.autoWeekdays(this) || Prefs.wfh(this)) return
        val today = java.time.LocalDate.now()
        if (Prefs.lastAutoDay(this) == today.toString()) return
        Prefs.setLastAutoDay(this, today.toString())
        val weekend = today.dayOfWeek == java.time.DayOfWeek.SATURDAY || today.dayOfWeek == java.time.DayOfWeek.SUNDAY
        if (!weekend && !Prefs.logOn(this)) {
            trackDay()
        } else if (weekend && Prefs.logOn(this)) {
            Prefs.setLogOn(this, false)
            detector.stop()
            Db.get(this).touch()
        }
    }

    // Driving: frequent high-accuracy readings (only while Track day is on); normal interval otherwise.
    private var driving = false
    private var lastMovingAt = 0L
    private var prevLoc: android.location.Location? = null

    private fun updateDriving(loc: android.location.Location) {
        val prev = prevLoc
        prevLoc = loc
        val speed = when {
            loc.hasSpeed() && loc.accuracy <= 100f -> loc.speed
            prev != null && loc.time > prev.time -> {
                val d = prev.distanceTo(loc)
                // Small jumps between rough readings aren't movement.
                if (d > maxOf(prev.accuracy, loc.accuracy) + 50f) d / ((loc.time - prev.time) / 1000f) else 0f
            }
            else -> 0f
        }
        if (speed >= MOVING_MPS) lastMovingAt = loc.time
        val want = Prefs.logOn(this) && System.currentTimeMillis() >= Prefs.pausedUntil(this) &&
            loc.time - lastMovingAt < STILL_MS
        if (want != driving) {
            driving = want
            requestUpdates()
        }
    }

    private val callback = object : LocationCallback() {
        override fun onLocationResult(result: LocationResult) {
            applyAutoDay()
            for (loc in result.locations) {
                detector.onLocation(loc.latitude, loc.longitude, loc.accuracy, loc.time)
                updateDriving(loc)
            }
            if (detector.activeId >= 0 && detector.activeId != lastNamedId) {
                lastNamedId = detector.activeId
                nameTodaysStops()
            }
            getSystemService(NotificationManager::class.java)
                .notify(NOTIF_ID, buildNotification(detector.status()))
            maybeRemind()
            maybeStartReminder()
            if (shouldRest()) rest(result.lastLocation)
        }
    }

    override fun onCreate() {
        super.onCreate()
        Prefs.migrate(this)
        fused = LocationServices.getFusedLocationProviderClient(this)
        detector = StayDetector(this)
        // Keep the work-from-home clock-in line open too.
        Db.get(this).closeStaleOngoing(detector.activeId, Prefs.clockId(this))
        Db.get(this).pruneFixes(System.currentTimeMillis())
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Location tracking", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(REMIND_CHANNEL, "End-of-day reminder", NotificationManager.IMPORTANCE_HIGH)
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            ServiceCompat.startForeground(
                this, NOTIF_ID, buildNotification(detector.status()),
                if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION else 0,
            )
        } catch (e: Exception) {
            // Usually: no location permission, or Android refused a background start.
            stopSelf()
            return START_NOT_STICKY
        }
        if (Prefs.wfh(this) && !Prefs.wfhLocToday(this)) {
            // Working from home, and location was only turned on for an earlier day.
            stopSelf()
            return START_NOT_STICKY
        }
        val nm = getSystemService(NotificationManager::class.java)
        if (Prefs.resting(this)) {
            // Coming back on after the night (alarm, app opened, a notification button, or a reboot).
            Prefs.setResting(this, false)
            cancelWake(this)
            detector.wake()
        }
        nm.cancel(WAKE_PROMPT_ID)
        applyAutoDay()
        when (intent?.action) {
            ACTION_DONE -> {
                detector.endDay(System.currentTimeMillis())
                nm.cancel(REMIND_ID)
            }
            ACTION_CONTINUE -> nm.cancel(REMIND_ID)
            ACTION_RESUME -> detector.resume()
            ACTION_START_WORK -> {
                if (!Prefs.logOn(this)) trackDay()
                detector.startWork(System.currentTimeMillis())
                nm.cancel(START_ID)
            }
            ACTION_TRACK_DAY -> trackDay()
            ACTION_LOG_OFF -> {
                Prefs.setLogOn(this, false)
                detector.stop()
                Db.get(this).touch()
            }
        }
        nm.notify(NOTIF_ID, buildNotification(detector.status()))
        if (!requestUpdates()) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    @SuppressLint("MissingPermission")
    private fun requestUpdates(): Boolean {
        if (!Perms.hasLocation(this)) return false
        val intervalMs = if (driving) DRIVING_MS else Prefs.intervalMin(this) * 60_000L
        val priority = if (driving || Prefs.highAccuracy(this)) Priority.PRIORITY_HIGH_ACCURACY
        else Priority.PRIORITY_BALANCED_POWER_ACCURACY
        val request = LocationRequest.Builder(priority, intervalMs)
            .setMinUpdateIntervalMillis(intervalMs / 2)
            .build()
        return try {
            fused.removeLocationUpdates(callback)
            fused.requestLocationUpdates(request, callback, Looper.getMainLooper())
            true
        } catch (e: SecurityException) {
            false
        }
    }

    /**
     * Outside tracking hours, shut off completely (no notification) once nothing is being logged:
     * you're home or at another ignored place, or done for the day. At a job site it keeps going.
     */
    /**
     * "Track day": turn logging on and fill in today from the location history saved so far,
     * then carry on live from wherever you are now.
     */
    private fun trackDay() {
        Prefs.setLogOn(this, true)
        Prefs.setPausedUntil(this, 0L)
        val replayed = History.replayToday(this)
        if (detector.activeId >= 0) {
            // Already logging a stop right now: keep it, and just take the filled-in gaps.
            replayed.stop()
        } else {
            detector.copyFrom(replayed)
        }
        replayed.saveDayState()
        Db.get(this).touch()
        nameTodaysStops()
    }

    private fun shouldRest(): Boolean {
        if (!Prefs.hoursOn(this)) return false
        val now = System.currentTimeMillis()
        if (Prefs.inTrackingHours(this, now)) return false
        if (!detector.canRest()) return false
        // Tapped "Start work" before hours begin: stay on so the drive is tracked.
        val z = now.toZoned()
        val early = z.hour * 60 + z.minute < Prefs.hoursStartMin(this)
        if (early && Prefs.workDay(this) == z.toLocalDate().toString() && Prefs.workStartManual(this)) return false
        return true
    }

    private fun rest(loc: android.location.Location?) {
        detector.rest(loc?.latitude, loc?.longitude, System.currentTimeMillis())
        Prefs.setResting(this, true)
        scheduleWake(this)
        fused.removeLocationUpdates(callback)
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    /** Once a day, at the reminder time, if you've worked today and haven't tapped "Done" yet. */
    private fun maybeRemind() {
        if (!Prefs.reminderOn(this)) return
        val now = java.time.ZonedDateTime.now()
        val today = now.toLocalDate()
        if (Prefs.lastReminderDay(this) == today.toString()) return
        if (now.hour * 60 + now.minute < Prefs.reminderMin(this)) return
        if (System.currentTimeMillis() < Prefs.pausedUntil(this)) return
        val start = today.atStartOfDay(now.zone).toInstant().toEpochMilli()
        val todays = Db.get(this).entriesBetween(start, today.plusDays(1).atStartOfDay(now.zone).toInstant().toEpochMilli())
        if (todays.isEmpty()) return // day off: no reminder
        Prefs.setLastReminderDay(this, today.toString())

        val current = todays.lastOrNull { it.ongoing }
        val total = todays.sumOf { it.end - it.start }
        val text = (current?.let { "At ${it.label} since ${fmtTime(it.start)}. " } ?: "") +
            "${fmtDur(total)} logged today. Tap Done when you leave work."
        fun action(a: String, code: Int) = PendingIntent.getForegroundService(
            this, code, Intent(this, TrackingService::class.java).setAction(a),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val open = PendingIntent.getActivity(
            this, 3, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val n = NotificationCompat.Builder(this, REMIND_CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_pm)
            .setColor(0xFF283890.toInt())
            .setContentTitle("Wrapping up for the day?")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(open)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .addAction(0, "Done for today", action(ACTION_DONE, 10))
            .addAction(0, "Still working", action(ACTION_CONTINUE, 11))
            .build()
        getSystemService(NotificationManager::class.java).notify(REMIND_ID, n)
    }

    /** Weekday mornings at the set time: offer "Start work" if your workday hasn't started yet. */
    private fun maybeStartReminder() {
        if (!Prefs.startRemindOn(this)) return
        val now = java.time.ZonedDateTime.now()
        if (now.dayOfWeek == java.time.DayOfWeek.SATURDAY || now.dayOfWeek == java.time.DayOfWeek.SUNDAY) return
        val today = now.toLocalDate().toString()
        if (Prefs.lastStartRemindDay(this) == today) return
        val m = now.hour * 60 + now.minute
        val at = Prefs.startRemindMin(this)
        if (m < at || m > at + 3 * 60) return
        if (Prefs.workDay(this) == today || Prefs.arrivedDay(this) == today) return
        Prefs.setLastStartRemindDay(this, today)
        val text = "Heading straight to a job site? Tap Start work and your drive counts as travel. " +
            "Going to the office? Ignore this. Your day starts when you get there."
        val start = PendingIntent.getForegroundService(
            this, 20, Intent(this, TrackingService::class.java).setAction(ACTION_START_WORK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val n = NotificationCompat.Builder(this, REMIND_CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_pm)
            .setColor(0xFF283890.toInt())
            .setContentTitle("Starting your workday?")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .addAction(0, "Start work", start)
            .build()
        getSystemService(NotificationManager::class.java).notify(START_ID, n)
    }

    private fun buildNotification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_pm)
            .setColor(0xFF283890.toInt())
            .setContentTitle("Timesheet is tracking")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    override fun onDestroy() {
        fused.removeLocationUpdates(callback)
        // Only close the current stay if the user actually switched tracking off.
        if (!Prefs.trackingEnabled(this)) detector.stop()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
