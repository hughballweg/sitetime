package com.sitetime.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import java.time.LocalDate
import java.time.ZoneId

/**
 * Short stops at places that aren't job sites: under [MAX_MS] somewhere that isn't a saved site
 * (and not a place you already worked at that day). When you leave, you're asked whether it was
 * a parts run for a job (logged with the drive as "Parts run to Menards for <job>", and added to the
 * day's notes), your lunch break (off the clock, in the BREAK column), or a job after all.
 * The drives there and back are answered along with the stop.
 */
object Errands {
    const val MAX_MS = 3 * 60 * 60_000L
    const val ACTION_PARTS = "com.sitetime.app.ERRAND_PARTS"
    const val ACTION_LUNCH = "com.sitetime.app.ERRAND_LUNCH"
    const val ACTION_JOB = "com.sitetime.app.ERRAND_JOB"
    const val ACTION_SKIP = "com.sitetime.app.ERRAND_SKIP"
    private const val CHANNEL = "drives"

    private fun notifId(entryId: Long) = 500_000 + (entryId % 100_000L).toInt()

    private fun cancel(ctx: Context, entryId: Long) =
        ctx.getSystemService(NotificationManager::class.java).cancel(notifId(entryId))

    /** The business name, if Google found one. */
    fun place(e: Entry): String? = e.label.takeIf { it.isNotBlank() && it != UNNAMED }

    fun isFood(e: Entry) = e.placeKind == "food"

    private fun dayEntries(ctx: Context, e: Entry): List<Entry> {
        val zone = ZoneId.systemDefault()
        val day = e.start.toLocalDate()
        return Db.get(ctx).entriesBetween(
            day.atStartOfDay(zone).toInstant().toEpochMilli(),
            day.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli(),
        ).filter { it.id != e.id && it.errand == 0 && !isLunchEntry(it) && sheetLine(it) != UNNAMED }
    }

    /** The job a parts run was most likely for: the one you came from, else the one you went to next. */
    fun guessJob(ctx: Context, e: Entry): String? {
        val day = dayEntries(ctx, e)
        val before = day.filter { it.start < e.start }.maxByOrNull { it.start }
        val after = day.filter { it.start >= e.end }.minByOrNull { it.start }
        return (before ?: after)?.let { sheetLine(it) }
    }

    /** Jobs to offer for a parts run: that day's jobs, the likeliest first. */
    fun jobChoices(ctx: Context, e: Entry): List<String> {
        val guess = guessJob(ctx, e)
        val all = dayEntries(ctx, e).sortedBy { it.start }.map { sheetLine(it) }
        return (listOfNotNull(guess) + all).distinct()
    }

    /** From the start of the drive there to the end of the drive away (as far as it's known yet). */
    fun span(ctx: Context, e: Entry): Pair<Long, Long> {
        val drives = Db.get(ctx).drivesForErrand(e.id)
        return minOf(e.start, drives.minOfOrNull { it.start } ?: e.start) to
            maxOf(e.end, drives.maxOfOrNull { it.end } ?: e.end)
    }

    /** Folds the stop's drives into it (any travel already logged for them is replaced). */
    private fun absorbDrives(db: Db, e: Entry, status: Int): Pair<Long, Long> {
        var s = e.start
        var en = e.end
        for (d in db.drivesForErrand(e.id)) {
            val old = d.entryId
            if (d.status == Drive.LOGGED && old != null && old != e.id) db.deleteEntry(old)
            db.setDriveStatus(d.id, status, e.id)
            s = minOf(s, d.start)
            en = maxOf(en, d.end)
        }
        return s to en
    }

    private fun minutes(ms: Long) = ((ms + 30_000L) / 60_000L).toInt()

    /** "Parts run to Menards for <job>", drive included, and a line in the day's notes. */
    fun partsRun(ctx: Context, entryId: Long, job: String) {
        cancel(ctx, entryId)
        val db = Db.get(ctx)
        val e = db.entry(entryId) ?: return
        val j = job.trim()
        if (j.isEmpty()) return
        val (s, en) = absorbDrives(db, e, Drive.LOGGED)
        val label = errandLabel(place(e), j)
        db.updateEntry(
            e.copy(siteId = null, label = label, start = s, end = en, ongoing = false, category = Drives.PARTS_RUN, errand = 0)
        )
        db.appendDayNote(e.start.toLocalDate(), label)
    }

    /** Lunch: the drive and the stop go in the BREAK column, and the day's break covers it. */
    fun lunch(ctx: Context, entryId: Long) {
        cancel(ctx, entryId)
        val db = Db.get(ctx)
        val e = db.entry(entryId) ?: return
        val (s, en) = absorbDrives(db, e, Drive.LUNCH)
        db.updateEntry(
            e.copy(
                siteId = null, label = place(e)?.let { "$LUNCH_PREFIX at $it" } ?: LUNCH_PREFIX,
                start = s, end = en, ongoing = false, category = Categories.BREAK, errand = 0,
            )
        )
        db.breakAtLeast(e.start.toLocalDate(), minutes(en - s))
    }

    /**
     * Not for work (groceries on the way home): the stop is removed, and its drives are kept under
     * the day's "not counted" drives, so nothing goes on the timesheet.
     */
    fun dismiss(ctx: Context, entryId: Long) {
        cancel(ctx, entryId)
        val db = Db.get(ctx)
        for (d in db.drivesForErrand(entryId)) {
            val old = d.entryId
            if (d.status == Drive.LOGGED && old != null && old != entryId) db.deleteEntry(old)
            db.setDriveStatus(d.id, Drive.IGNORED, null)
        }
        db.deleteEntry(entryId)
    }

    /** It was a job after all: it stays as a stop, and its drives can be logged like any other. */
    fun job(ctx: Context, entryId: Long) {
        cancel(ctx, entryId)
        Db.get(ctx).setErrand(entryId, 0)
    }

    /** You stayed long enough that it's a job: ask about the drive there like any other drive. */
    fun becameJob(ctx: Context, entryId: Long, ask: Boolean) {
        val db = Db.get(ctx)
        db.setErrand(entryId, 0)
        if (!ask || !Prefs.askDrives(ctx)) return
        for (d in db.drivesForErrand(entryId)) {
            if (d.status == Drive.PENDING) Drives.ask(ctx, d.id, d.start, d.end, d.from, d.to, d.job ?: d.to)
        }
    }

    /**
     * You drove away from a short stop. The drive goes with it: held until you answer, or added to
     * the parts run / lunch you already chose. Returns false if it should be asked about on its own.
     */
    fun driveOut(ctx: Context, driveId: Long, entryId: Long): Boolean {
        val db = Db.get(ctx)
        db.setDriveErrand(driveId, entryId)
        val e = db.entry(entryId)
        if (e == null) {
            // You said the stop didn't count: the drive away doesn't either.
            val dismissed = db.drivesForErrand(entryId).any { it.id != driveId && it.status == Drive.IGNORED }
            if (dismissed) db.setDriveStatus(driveId, Drive.IGNORED, null)
            return dismissed
        }
        val d = db.drive(driveId) ?: return false
        return when {
            e.errand > 0 -> true
            isLunchEntry(e) -> {
                db.setDriveStatus(d.id, Drive.LUNCH, e.id)
                db.setEntryEnd(e.id, maxOf(e.end, d.end), ongoing = false)
                db.breakAtLeast(e.start.toLocalDate(), minutes(maxOf(e.end, d.end) - e.start))
                true
            }
            e.category == Drives.PARTS_RUN && e.label.startsWith("Parts run") -> {
                db.setDriveStatus(d.id, Drive.LOGGED, e.id)
                db.setEntryEnd(e.id, maxOf(e.end, d.end), ongoing = false)
                true
            }
            else -> false
        }
    }

    /** "Parts run to Menards?" — asked when you leave a short stop. */
    fun ask(ctx: Context, entryId: Long) {
        if (!Prefs.askDrives(ctx)) return
        val e = Db.get(ctx).entry(entryId) ?: return
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Drive time questions", NotificationManager.IMPORTANCE_HIGH)
        )
        val id = notifId(entryId)
        val where = place(e) ?: "an unnamed place"
        val job = guessJob(ctx, e)
        val food = isFood(e)
        fun action(action: String, code: Int): PendingIntent {
            val i = Intent(ctx, DriveReceiver::class.java)
                .setAction(action)
                .putExtra("entry", entryId)
                .putExtra("job", job)
            return PendingIntent.getBroadcast(
                ctx, id * 4 + code, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            )
        }
        val open = PendingIntent.getActivity(
            ctx, id, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val text = "${fmtTime(e.start)} – ${fmtTime(e.end)} at $where. " +
            if (job != null) "A parts run for $job, your lunch break, or not for work?"
            else "A parts run, your lunch break, or not for work? Open the app to pick the job."
        val parts = if (job != null) action(ACTION_PARTS, 1) else open
        // All four choices: Android shows at most three normal buttons, so they're in an expanded
        // layout (pull the notification down to see them). Restaurants put Lunch first.
        val choices = listOf(
            (if (job != null) "Parts run" else "Parts run…") to parts,
            "Lunch" to action(ACTION_LUNCH, 2),
            "It's a job" to action(ACTION_JOB, 3),
            "Don't count" to action(ACTION_SKIP, 0),
        ).let { if (food) listOf(it[1], it[0], it[2], it[3]) else it }
        val title = if (food) "Lunch at $where?" else "Parts run to $where?"
        val big = android.widget.RemoteViews(ctx.packageName, R.layout.notif_errand).apply {
            setTextViewText(R.id.title, title)
            setTextViewText(R.id.text, text)
            listOf(R.id.choice1, R.id.choice2, R.id.choice3, R.id.choice4).forEachIndexed { i, v ->
                setTextViewText(v, choices[i].first)
                setOnClickPendingIntent(v, choices[i].second)
            }
        }
        val b = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_pm)
            .setColor(0xFF283890.toInt())
            .setContentTitle(title)
            .setContentText("Pull down for: Parts run, Lunch, It's a job, Don't count")
            .setStyle(NotificationCompat.DecoratedCustomViewStyle())
            .setCustomBigContentView(big)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(open)
            .setAutoCancel(true)
        nm.notify(id, b.build())
    }

    /** Short stops between [from] and [to] (exclusive) still waiting for an answer. */
    fun pendingOn(ctx: Context, from: LocalDate, to: LocalDate): List<Entry> =
        Db.get(ctx).pendingErrands().filter { val d = it.start.toLocalDate(); !d.isBefore(from) && d.isBefore(to) }
}
