package com.sitetime.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Restarts tracking after the phone reboots or the app is updated. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        Prefs.migrate(ctx)
        WfhReminders.schedule(ctx)
        if (Prefs.trackingEnabled(ctx) && Perms.hasLocation(ctx) && Perms.hasBackground(ctx)) {
            try {
                TrackingService.start(ctx)
            } catch (_: Exception) {
                // Android may refuse; tracking resumes next time the app is opened.
            }
        }
    }
}
