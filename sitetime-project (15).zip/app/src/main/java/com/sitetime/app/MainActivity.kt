@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.sitetime.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import kotlinx.coroutines.launch
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.draw.scale
import androidx.compose.foundation.layout.size
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.drawBehind
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.SwitchDefaults
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.res.painterResource
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.location.Geocoder
import android.os.Handler
import android.os.Looper
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Surface
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import java.util.Locale
import android.os.PowerManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.LifecycleResumeEffect
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.TemporalAdjusters

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ThemeState.load(this)
        enableEdgeToEdge()
        setContent {
            val dark = ThemeState.mode == ThemeMode.DARK
            LaunchedEffect(dark) {
                enableEdgeToEdge(
                    statusBarStyle = if (dark) {
                        androidx.activity.SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
                    } else {
                        androidx.activity.SystemBarStyle.light(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT)
                    },
                    navigationBarStyle = if (dark) {
                        androidx.activity.SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
                    } else {
                        androidx.activity.SystemBarStyle.light(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT)
                    },
                )
            }
            AppTheme { App() }
        }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    var needName by remember { mutableStateOf(Prefs.name(ctx).isBlank()) }
    if (needName) NameDialog { needName = false }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val tabs = listOf("Timesheet", "Map", "Sites", "Settings")
    val icons = listOf(Icons.Default.DateRange, MapIcon, Icons.Default.Place, Icons.Default.Settings)
    Scaffold(
        topBar = { BrandHeader() },
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest, tonalElevation = 0.dp) {
                tabs.forEachIndexed { i, t ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Icon(icons[i], contentDescription = null) },
                        label = { Text(t) },
                    )
                }
            }
        },
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> TimesheetScreen()
                1 -> MapScreen()
                2 -> SitesScreen()
                else -> SettingsScreen()
            }
        }
    }
}

/** Shown once on first launch. It can't be dismissed without a name. */
@Composable
fun NameDialog(onDone: () -> Unit) {
    val ctx = LocalContext.current
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = { },
        title = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Image(
                    painterResource(R.drawable.prime_logo), contentDescription = "PRIME Mechanical of Wisconsin",
                    modifier = Modifier.fillMaxWidth(),
                    colorFilter = if (LocalDark.current) ColorFilter.tint(Color.White) else null,
                )
                Text("Welcome to Timesheet")
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Enter your name as it should appear on your timesheets. You can change it later in Settings.")
                OutlinedTextField(
                    value = name, onValueChange = { name = it }, label = { Text("Your name") },
                    singleLine = true, modifier = Modifier.fillMaxWidth(),
                )
            }
        },
        confirmButton = {
            TextButton(enabled = name.isNotBlank(), onClick = {
                Prefs.setName(ctx, name)
                onDone()
            }) { Text("Continue") }
        },
    )
}

@Composable
fun CategoryPicker(title: String, selected: String?, exclude: Set<String> = emptySet(), onSelect: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Column {
        if (title.isNotEmpty()) {
            Text(title, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Box {
            OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) {
                Text(Categories.labelOf(selected), maxLines = 1)
            }
            DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                Categories.all.filter { it.col !in exclude }.forEach { c ->
                    DropdownMenuItem(text = { Text(c.label) }, onClick = { onSelect(c.col); open = false })
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Timesheet

@Composable
fun TimesheetScreen() {
    val ctx = LocalContext.current
    val db = remember { Db.get(ctx) }
    val version by Db.changes.collectAsState()
    val thisWeek = remember { LocalDate.now().with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY)) }
    var weekStart by remember { mutableStateOf(thisWeek) }
    val zone = ZoneId.systemDefault()
    val from = weekStart.atStartOfDay(zone).toInstant().toEpochMilli()
    val to = weekStart.plusDays(7).atStartOfDay(zone).toInstant().toEpochMilli()
    val entries = remember(version, from) { db.entriesBetween(from, to) }
    val breaks = remember(version, from) { db.breaksBetween(weekStart, weekStart.plusDays(7)) }
    var breakDay by remember { mutableStateOf<LocalDate?>(null) }
    var editorDay by remember { mutableStateOf<Int?>(null) }
    // Drives waiting for a decision are pinned at the top; skipped ones stay in their day so you can still log them.
    val pending = remember(version) { db.pendingDrives() }
    val drives = remember(version, from) { db.drivesBetween(from, to).filter { it.status == Drive.SKIPPED } }
    var newestFirst by remember { mutableStateOf(Prefs.newestFirst(ctx)) }
    // Today (newest) at the top, earlier days below it.
    val days = (entries.map { it.start.toLocalDate() } + drives.map { it.start.toLocalDate() }).toSortedSet().reversed()
    var refreshing by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    var editing by remember { mutableStateOf<Entry?>(null) }
    var adding by remember { mutableStateOf(false) }
    var exporting by remember { mutableStateOf(false) }

    androidx.compose.material3.pulltorefresh.PullToRefreshBox(
        isRefreshing = refreshing,
        onRefresh = {
            refreshing = true
            scope.launch {
                // Ask for a fresh location fix and reload everything on screen.
                if (Prefs.trackingEnabled(ctx) && Perms.hasLocation(ctx)) {
                    try {
                        TrackingService.start(ctx)
                    } catch (_: Exception) {
                    }
                }
                db.touch()
                kotlinx.coroutines.delay(700)
                refreshing = false
            }
        },
        modifier = Modifier.fillMaxSize(),
    ) {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        if (pending.isNotEmpty()) {
            item(key = "pending") { PendingBox(pending) }
        }
        item { TrackingCard() }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { weekStart = weekStart.minusWeeks(1) }) {
                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, "Previous week")
                }
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        if (weekStart == thisWeek) "This week" else "Week of ${weekStart.format(WEEK_FMT)}",
                        style = MaterialTheme.typography.titleMedium,
                    )
                    Text(
                        "${weekStart.format(java.time.format.DateTimeFormatter.ofPattern("MMM d"))} – " +
                            "${weekStart.plusDays(6).format(java.time.format.DateTimeFormatter.ofPattern("MMM d"))} · " +
                            fmtDur(entries.sumOf { it.end - it.start }),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary,
                    )
                }
                IconButton(onClick = { weekStart = weekStart.plusWeeks(1) }) {
                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, "Next week")
                }
            }
        }
        item {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    val today = LocalDate.now()
                    editorDay = if (!today.isBefore(weekStart) && today.isBefore(weekStart.plusDays(7))) {
                        (today.toEpochDay() - weekStart.toEpochDay()).toInt()
                    } else {
                        0
                    }
                }) { Text("Review / edit sheet") }
                OutlinedButton(onClick = { adding = true }) {
                    Icon(Icons.Default.Add, null)
                    Spacer(Modifier.width(6.dp))
                    Text("Add entry")
                }
                Button(onClick = { exporting = true }) {
                    Icon(Icons.Default.Share, null)
                    Spacer(Modifier.width(6.dp))
                    Text("Timesheet")
                }
            }
        }
        if (entries.isEmpty() && drives.isEmpty()) {
            item {
                Text(
                    "Nothing logged this week. Once tracking is on, any place you stay " +
                        "${Prefs.minStayMin(ctx)}+ minutes shows up here automatically.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        for (date in days) {
            val list = entries.filter { it.start.toLocalDate() == date }
            val dayDrives = drives.filter { it.start.toLocalDate() == date }
            item(key = "day-$date") {
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        date.format(DAY_FMT), Modifier.weight(1f),
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.primary,
                    )
                    TextButton(
                        onClick = {
                            newestFirst = !newestFirst
                            Prefs.setBool(ctx, "newestFirst", newestFirst)
                        },
                        contentPadding = PaddingValues(horizontal = 6.dp),
                    ) {
                        Icon(
                            if (newestFirst) Icons.Default.KeyboardArrowDown else Icons.Default.KeyboardArrowUp,
                            contentDescription = null, modifier = Modifier.size(18.dp),
                        )
                        Text(if (newestFirst) "Newest" else "Oldest", style = MaterialTheme.typography.labelMedium)
                    }
                    val mins = breaks[date] ?: 0
                    TextButton(onClick = { breakDay = date }, contentPadding = PaddingValues(horizontal = 6.dp)) {
                        Text(if (mins > 0) "Break $mins min" else "Add break", style = MaterialTheme.typography.labelMedium)
                    }
                    Text(
                        fmtDur(list.sumOf { it.end - it.start }),
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.primary,
                    )
                }
            }
            val ordered: List<Any> = (list + dayDrives).sortedBy { if (it is Entry) it.start else (it as Drive).start }
            // Newest first: where you are now on top, your earliest stop at the bottom of the day.
            val rows = if (newestFirst) ordered.reversed() else ordered
            items(rows, key = { if (it is Entry) "e${it.id}" else "d${(it as Drive).id}" }) { row ->
                if (row is Entry) EntryRow(row) { editing = row } else DriveRow(row as Drive)
            }
        }
    }
    }

    editing?.let { e -> EntryDialog(e, e.start.toLocalDate()) { editing = null } }
    if (exporting) {
        ExportDialog(
            weekStart,
            onEdit = {
                exporting = false
                val today = LocalDate.now()
                editorDay = if (!today.isBefore(weekStart) && today.isBefore(weekStart.plusDays(7))) {
                    (today.toEpochDay() - weekStart.toEpochDay()).toInt()
                } else {
                    0
                }
            },
        ) { exporting = false }
    }
    editorDay?.let { d -> SheetEditorDialog(weekStart, d) { editorDay = null } }
    breakDay?.let { d -> BreakDialog(d, breaks[d] ?: 0) { breakDay = null } }
    if (adding) {
        val today = LocalDate.now()
        val default = if (!today.isBefore(weekStart) && today.isBefore(weekStart.plusDays(7))) today else weekStart
        EntryDialog(null, default) { adding = false }
    }
}

/** Drives waiting for you to log or skip them, pinned at the top of the Timesheet tab. */
@Composable
fun PendingBox(pending: List<Drive>) {
    Card(
        Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)),
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                "Pending your review (${pending.size})",
                style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary,
            )
            pending.forEach { d -> key(d.id) { DriveRow(d, showDay = true) } }
        }
    }
}

/** A drive that hasn't been added to the timesheet. */
@Composable
fun DriveRow(d: Drive, showDay: Boolean = false) {
    val ctx = LocalContext.current
    val version by Db.changes.collectAsState()
    val dest = remember(d, version) { Drives.destination(ctx, d) }
    Card(
        Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
    ) {
        Column(Modifier.padding(start = 16.dp, end = 8.dp, top = 10.dp, bottom = 4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("$DRIVE_PREFIX${d.job?.let { d.to } ?: dest}", style = MaterialTheme.typography.titleSmall)
                    Text(
                        (if (showDay) d.start.toLocalDate().format(DAY_FMT) + " · " else "") +
                            "${fmtTime(d.start)} – ${fmtTime(d.end)} · from ${d.from}" +
                            (if (d.job != null) " · counts for $dest" else "") +
                            if (d.status == Drive.SKIPPED) " · not on timesheet" else "",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Text(fmtDur(d.end - d.start), style = MaterialTheme.typography.titleSmall)
            }
            FlowRow {
                TextButton(onClick = { Drives.log(ctx, d.id, Drives.TRAVEL) }) { Text("Log as Travel") }
                TextButton(onClick = { Drives.log(ctx, d.id, Drives.PARTS_RUN) }) { Text("Log as Parts run") }
                if (d.status == Drive.PENDING) {
                    TextButton(onClick = { Drives.skip(ctx, d.id) }) { Text("Don't log") }
                }
            }
        }
    }
}

@Composable
fun EntryRow(e: Entry, onClick: () -> Unit) {
    if (isDriveEntry(e)) {
        TravelRow(e, onClick)
        return
    }
    val unnamed = e.siteId == null && e.lat != null && e.label == UNNAMED
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        colors = if (unnamed) CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer)
        else CardDefaults.cardColors(),
    ) {
        val dark = LocalDark.current
        val ink = if (dark) Color.White.copy(alpha = 0.16f) else PrimeNavy.copy(alpha = 0.20f)
        val bg = MaterialTheme.colorScheme.surfaceContainerHighest
        val art = if (unnamed) null else e.category
        Box(Modifier.fillMaxWidth().drawBehind { drawJobArt(art, ink, bg) }) {
            Row(Modifier.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(e.label, style = MaterialTheme.typography.titleMedium)
                    val times = "${fmtTime(e.start)} – ${if (e.ongoing) "now" else fmtTime(e.end)}"
                    Text(
                        when {
                            unnamed -> "$times · tap to name"
                            e.note.isNotBlank() -> "$times · ${e.note}"
                            else -> times
                        },
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    Text(
                        Categories.labelOf(e.category),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Text(fmtDur(e.end - e.start), style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
            }
        }
    }
}

/** Logged travel: a plain card with a faint van drawn in (Parts run carries boxes; Travel is empty, with a cobweb). */
@Composable
fun TravelRow(e: Entry, onClick: () -> Unit) {
    val parts = e.category == "R"
    val dark = LocalDark.current
    val bg = MaterialTheme.colorScheme.surfaceContainerHighest
    val ink = if (dark) Color.White.copy(alpha = 0.16f) else PrimeNavy.copy(alpha = 0.20f)
    val tire = if (dark) Color.White.copy(alpha = 0.26f) else Color(0xFF2B2F3A).copy(alpha = 0.30f)
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = bg)) {
        Box(Modifier.fillMaxWidth().drawBehind { drawTravelArt(parts, dark, ink, tire, bg) }) {
            Row(
                Modifier.padding(start = 16.dp, end = 16.dp, top = 18.dp, bottom = 18.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text(e.label, style = MaterialTheme.typography.titleMedium)
                    Text(
                        "${fmtTime(e.start)} – ${fmtTime(e.end)}" + if (e.note.isNotBlank()) " · ${e.note}" else "",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    Text(
                        if (parts) "Parts run" else "Travel",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Text(fmtDur(e.end - e.start), style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
            }
        }
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawTravelArt(
    parts: Boolean, dark: Boolean, ink: Color, tire: Color, bg: Color,
) {
    val w = size.width
    val h = size.height
    val dp = density
    val faint = ink.copy(alpha = ink.alpha * 0.55f)
    // Van body: windshield up front (right), a belt line, a door seam and wheel arches.
    val glass = Path().apply {
        moveTo(w - 50 * dp, 20 * dp)
        lineTo(w - 24 * dp, 20 * dp)
        lineTo(w - 7 * dp, h * 0.52f)
        lineTo(w - 50 * dp, h * 0.52f)
        close()
    }
    drawPath(glass, ink.copy(alpha = ink.alpha * 0.35f))
    drawPath(glass, faint, style = Stroke(width = 1f * dp))
    val floor = h * 0.75f
    val seam = w * 0.58f
    drawLine(faint, Offset(6 * dp, floor), Offset(w - 6 * dp, floor), strokeWidth = 1f * dp)
    drawLine(faint, Offset(seam, h * 0.3f), Offset(seam, h - 8 * dp), strokeWidth = 1f * dp)
    drawLine(faint, Offset(seam + 8 * dp, h * 0.68f), Offset(seam + 16 * dp, h * 0.68f), strokeWidth = 2f * dp)
    for (fx in listOf(0.16f, 0.84f)) {
        drawArc(
            faint, startAngle = 180f, sweepAngle = 180f, useCenter = false,
            topLeft = Offset(w * fx - 13 * dp, h - 16 * dp), size = androidx.compose.ui.geometry.Size(26 * dp, 26 * dp),
            style = Stroke(width = 1f * dp),
        )
    }
    // Modern lights: a tall LED headlight up front (right), a tall pastel-red taillight low on the back (left), Transit-style.
    val radius = androidx.compose.ui.geometry.CornerRadius(3 * dp)
    val headTop = h * 0.54f
    drawRoundRect(
        Color(0xFFF4F8FF).copy(alpha = if (dark) 0.55f else 1f), topLeft = Offset(w - 6 * dp, headTop),
        size = androidx.compose.ui.geometry.Size(6 * dp, 16 * dp), cornerRadius = radius,
    )
    drawRoundRect(
        faint, topLeft = Offset(w - 6 * dp, headTop),
        size = androidx.compose.ui.geometry.Size(6 * dp, 16 * dp), cornerRadius = radius, style = Stroke(width = 1f * dp),
    )
    drawRoundRect(
        Color(0xFFF2A0A0).copy(alpha = if (dark) 0.45f else 0.6f), topLeft = Offset(0f, floor - 23 * dp),
        size = androidx.compose.ui.geometry.Size(5 * dp, 22 * dp), cornerRadius = radius,
    )
    // Wheels peeking out under the bottom edge.
    for (fx in listOf(0.16f, 0.84f)) {
        val c = Offset(w * fx, h - 3 * dp)
        drawCircle(tire, radius = 9 * dp, center = c)
        drawCircle(bg, radius = 4 * dp, center = c)
        drawCircle(tire, radius = 1.5f * dp, center = c)
    }
    if (parts) {
        // Ladder rack: two posts, with a ladder lying across them.
        val stroke = 1.6f * dp
        for (fx in listOf(0.24f, 0.76f)) {
            drawLine(ink, Offset(w * fx, 8 * dp), Offset(w * fx, 14 * dp), strokeWidth = 2.2f * dp)
        }
        val x0 = w * 0.14f
        val x1 = w * 0.86f
        drawLine(ink, Offset(x0, 3 * dp), Offset(x1, 3 * dp), strokeWidth = stroke)
        drawLine(ink, Offset(x0, 8 * dp), Offset(x1, 8 * dp), strokeWidth = stroke)
        var x = x0
        while (x <= x1 + 0.5f) {
            drawLine(ink, Offset(x, 3 * dp), Offset(x, 8 * dp), strokeWidth = 1.2f * dp)
            x += 12 * dp
        }
        // A few boxes stacked on the cargo floor, just behind the door seam.
        val boxFill = ink.copy(alpha = ink.alpha * 0.18f)
        fun box(left: Float, top: Float, bw: Float, bh: Float) {
            val tl = Offset(left, top)
            val sz = androidx.compose.ui.geometry.Size(bw, bh)
            drawRect(boxFill, topLeft = tl, size = sz)
            drawRect(faint, topLeft = tl, size = sz, style = Stroke(width = 1f * dp))
            drawLine(faint, Offset(left + bw / 2, top), Offset(left + bw / 2, top + bh * 0.35f), strokeWidth = 1f * dp)
        }
        box(seam - 21 * dp, floor - 13 * dp, 17 * dp, 13 * dp)
        box(seam - 35 * dp, floor - 10 * dp, 12 * dp, 10 * dp)
        box(seam - 18 * dp, floor - 23 * dp, 11 * dp, 10 * dp)
    } else {
        // Empty van: a cobweb in the top-back (left) corner, kept low and wide so it stays clear of the text.
        val rx = 36 * dp
        val ry = 17 * dp
        val angles = listOf(0.0, 22.5, 45.0, 67.5, 90.0).map { Math.toRadians(it) }
        fun at(a: Double, f: Float) = Offset((Math.cos(a) * rx * f).toFloat(), (Math.sin(a) * ry * f).toFloat())
        val stroke = Stroke(width = 1f * dp)
        angles.forEach { a -> drawLine(ink, Offset.Zero, at(a, 1f), strokeWidth = 1f * dp) }
        for (f in listOf(0.3f, 0.55f, 0.8f, 0.97f)) {
            val path = Path()
            angles.forEachIndexed { i, a ->
                val p = at(a, f)
                if (i == 0) {
                    path.moveTo(p.x, p.y)
                } else {
                    // threads sag a little toward the corner between spokes
                    val c = at((a + angles[i - 1]) / 2, f * 0.86f)
                    path.quadraticBezierTo(c.x, c.y, p.x, p.y)
                }
            }
            drawPath(path, ink, style = stroke)
        }
    }
}

/** Faint task art for job cards, drawn in the same style as the travel vans. Generated from jobart.py. */
private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawJobArt(cat: String?, ink: Color, bg: Color) {
    val k = density
    val ox = size.width - 10 * k
    val oy = size.height
    val faint = ink.copy(alpha = ink.alpha * 0.55f)
    val fill = ink.copy(alpha = ink.alpha * 0.18f)
    val glass = ink.copy(alpha = ink.alpha * 0.35f)
    fun c(st: Int) = when (st) { 0 -> ink; 1 -> faint; 2 -> fill; 3 -> glass; 4 -> bg; else -> ink }
    fun ln(x1: Float, y1: Float, x2: Float, y2: Float, st: Int, sw: Float) =
        drawLine(c(st), Offset(ox + x1 * k, oy + y1 * k), Offset(ox + x2 * k, oy + y2 * k), strokeWidth = sw * k, cap = StrokeCap.Round)
    fun rc(x: Float, y: Float, w: Float, h: Float, r: Float, st: Int, sw: Float) {
        val tl = Offset(ox + x * k, oy + y * k)
        val sz = androidx.compose.ui.geometry.Size(w * k, h * k)
        val cr = androidx.compose.ui.geometry.CornerRadius(r * k)
        if (st >= 2) drawRoundRect(c(st), tl, sz, cr) else drawRoundRect(c(st), tl, sz, cr, style = Stroke(width = sw * k))
    }
    fun ci(x: Float, y: Float, r: Float, st: Int, sw: Float) {
        val ctr = Offset(ox + x * k, oy + y * k)
        if (st >= 2) drawCircle(c(st), r * k, ctr) else drawCircle(c(st), r * k, ctr, style = Stroke(width = sw * k))
    }
    fun pg(st: Int, sw: Float, closed: Boolean, vararg p: Float) {
        val path = Path()
        path.moveTo(ox + p[0] * k, oy + p[1] * k)
        var i = 2
        while (i < p.size) {
            path.lineTo(ox + p[i] * k, oy + p[i + 1] * k)
            i += 2
        }
        if (closed) path.close()
        if (st >= 2) {
            drawPath(path, c(st))
        } else {
            drawPath(path, c(st), style = Stroke(width = sw * k, cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
    }
    when (cat) {
        "E" -> {
            rc(-118f, -12f, 46f, 10f, 0f, 2, 1f)
            rc(-118f, -12f, 46f, 10f, 0f, 0, 1f)
            rc(-122f, -17f, 4f, 20f, 1f, 2, 1f)
            rc(-122f, -17f, 4f, 20f, 1f, 0, 1f)
            ci(-120f, -14f, 0.8f, 5, 1f)
            ci(-120f, 0f, 0.8f, 5, 1f)
            pg(2, 1f, true, -72f, -2f, -69.91f, -2.14f, -67.86f, -2.55f, -65.88f, -3.22f, -64f, -4.14f, -62.26f, -5.31f, -60.69f, -6.69f, -59.31f, -8.26f, -58.14f, -10f, -57.22f, -11.88f, -56.55f, -13.86f, -56.14f, -15.91f, -56f, -18f, -66f, -18f, -66.05f, -17.22f, -66.2f, -16.45f, -66.46f, -15.7f, -66.8f, -15f, -67.24f, -14.35f, -67.76f, -13.76f, -68.35f, -13.24f, -69f, -12.8f, -69.7f, -12.46f, -70.45f, -12.2f, -71.22f, -12.05f, -72f, -12f)
            pg(0, 1f, true, -72f, -2f, -69.91f, -2.14f, -67.86f, -2.55f, -65.88f, -3.22f, -64f, -4.14f, -62.26f, -5.31f, -60.69f, -6.69f, -59.31f, -8.26f, -58.14f, -10f, -57.22f, -11.88f, -56.55f, -13.86f, -56.14f, -15.91f, -56f, -18f, -66f, -18f, -66.05f, -17.22f, -66.2f, -16.45f, -66.46f, -15.7f, -66.8f, -15f, -67.24f, -14.35f, -67.76f, -13.76f, -68.35f, -13.24f, -69f, -12.8f, -69.7f, -12.46f, -70.45f, -12.2f, -71.22f, -12.05f, -72f, -12f)
            rc(-66f, -32f, 10f, 14f, 0f, 2, 1f)
            rc(-66f, -32f, 10f, 14f, 0f, 0, 1f)
            rc(-68f, -34f, 14f, 3f, 1f, 2, 1f)
            rc(-68f, -34f, 14f, 3f, 1f, 0, 1f)
            pg(1, 1f, false, -98f, -12f, -98.74f, -11.38f, -98.57f, -10.75f, -97.69f, -10.12f, -97.2f, -9.5f, -97.69f, -8.88f, -98.57f, -8.25f, -98.74f, -7.62f, -98f, -7f, -97.26f, -6.38f, -97.43f, -5.75f, -98.31f, -5.12f, -98.8f, -4.5f, -98.31f, -3.88f, -97.43f, -3.25f, -97.26f, -2.62f, -98f, -2f)
            pg(1, 1f, false, -72f, -12f, -72.74f, -11.38f, -72.57f, -10.75f, -71.69f, -10.12f, -71.2f, -9.5f, -71.69f, -8.88f, -72.57f, -8.25f, -72.74f, -7.62f, -72f, -7f, -71.26f, -6.38f, -71.43f, -5.75f, -72.31f, -5.12f, -72.8f, -4.5f, -72.31f, -3.88f, -71.43f, -3.25f, -71.26f, -2.62f, -72f, -2f)
            pg(1, 1f, false, -66f, -18f, -65.38f, -17.26f, -64.75f, -17.43f, -64.12f, -18.31f, -63.5f, -18.8f, -62.88f, -18.31f, -62.25f, -17.43f, -61.62f, -17.26f, -61f, -18f, -60.38f, -18.74f, -59.75f, -18.57f, -59.12f, -17.69f, -58.5f, -17.2f, -57.88f, -17.69f, -57.25f, -18.57f, -56.62f, -18.74f, -56f, -18f)
            pg(2, 1f, true, -46f, -10f, -20f, -10f, -20f, -3f, -46f, -3f)
            pg(0, 1f, true, -46f, -10f, -20f, -10f, -20f, -3f, -46f, -3f)
            pg(3, 1f, true, -20f, -10f, -13f, -14f, -13f, -7f, -20f, -3f)
            pg(0, 1f, true, -20f, -10f, -13f, -14f, -13f, -7f, -20f, -3f)
            pg(2, 1f, true, -46f, -10f, -20f, -10f, -24f, -24f, -36f, -24f)
            pg(0, 1f, true, -46f, -10f, -20f, -10f, -24f, -24f, -36f, -24f)
            pg(3, 1f, true, -20f, -10f, -13f, -14f, -21f, -25f, -24f, -24f)
            pg(0, 1f, true, -20f, -10f, -13f, -14f, -21f, -25f, -24f, -24f)
            ln(-46f, -10f, -34f, -24f, 1, 1f)
            ln(-20f, -10f, -27f, -24f, 1, 1f)
            ln(-20f, -10f, -31f, -24f, 1, 1f)
            rc(-36.5f, -30f, 13f, 5.5f, 0.5f, 2, 1f)
            rc(-36.5f, -30f, 13f, 5.5f, 0.5f, 0, 1f)
            pg(0, 1f, true, -23.5f, -30f, -23.82f, -29.38f, -24.74f, -28.82f, -26.18f, -28.38f, -27.99f, -28.1f, -30f, -28f, -32.01f, -28.1f, -33.82f, -28.38f, -35.26f, -28.82f, -36.18f, -29.38f, -36.5f, -30f, -36.18f, -30.62f, -35.26f, -31.18f, -33.82f, -31.62f, -32.01f, -31.9f, -30f, -32f, -27.99f, -31.9f, -26.18f, -31.62f, -24.74f, -31.18f, -23.82f, -30.62f, -23.5f, -30f)
            pg(3, 1f, true, -23.5f, -30f, -23.82f, -29.38f, -24.74f, -28.82f, -26.18f, -28.38f, -27.99f, -28.1f, -30f, -28f, -32.01f, -28.1f, -33.82f, -28.38f, -35.26f, -28.82f, -36.18f, -29.38f, -36.5f, -30f, -36.18f, -30.62f, -35.26f, -31.18f, -33.82f, -31.62f, -32.01f, -31.9f, -30f, -32f, -27.99f, -31.9f, -26.18f, -31.62f, -24.74f, -31.18f, -23.82f, -30.62f, -23.5f, -30f)
            ln(-46f, -6.5f, -20f, -6.5f, 1, 1f)
        }
        "F" -> {
            rc(-96f, -24f, 70f, 4f, 1f, 2, 1f)
            rc(-96f, -24f, 70f, 4f, 1f, 0, 1f)
            rc(-92f, -20f, 22f, 20f, 0f, 2, 1f)
            rc(-92f, -20f, 22f, 20f, 0f, 0, 1f)
            ln(-92f, -14f, -70f, -14f, 1, 1f)
            ln(-92f, -8f, -70f, -8f, 1, 1f)
            ln(-84f, -17f, -78f, -17f, 0, 1.2f)
            ln(-84f, -11f, -78f, -11f, 0, 1.2f)
            ln(-84f, -5f, -78f, -5f, 0, 1.2f)
            rc(-32f, -20f, 3f, 20f, 0f, 2, 1f)
            rc(-32f, -20f, 3f, 20f, 0f, 0, 1f)
            rc(-92f, -26f, 10f, 2f, 1f, 2, 1f)
            rc(-92f, -26f, 10f, 2f, 1f, 0, 1f)
            ln(-87f, -26f, -82f, -36f, 0, 1.2f)
            ln(-82f, -36f, -74f, -32f, 0, 1.2f)
            pg(2, 1f, true, -77f, -35f, -68f, -30f, -71f, -27f, -78f, -31f)
            pg(0, 1f, true, -77f, -35f, -68f, -30f, -71f, -27f, -78f, -31f)
            rc(-60f, -27f, 16f, 3f, 0.5f, 2, 1f)
            rc(-60f, -27f, 16f, 3f, 0.5f, 0, 1f)
            rc(-58f, -30f, 14f, 3f, 0.5f, 2, 1f)
            rc(-58f, -30f, 14f, 3f, 0.5f, 0, 1f)
            rc(-40f, -31f, 7f, 7f, 1f, 2, 1f)
            rc(-40f, -31f, 7f, 7f, 1f, 0, 1f)
            pg(0, 1f, false, -33f, -30f, -31.75f, -29.67f, -30.83f, -28.75f, -30.5f, -27.5f, -30.83f, -26.25f, -31.75f, -25.33f, -33f, -25f)
        }
        "G" -> {
            pg(2, 1f, true, -82f, -28f, -36f, -28f, -32f, -2f, -86f, -2f)
            pg(0, 1f, true, -82f, -28f, -36f, -28f, -32f, -2f, -86f, -2f)
            ln(-82.8f, -22.8f, -35.2f, -22.8f, 1, 1f)
            ln(-83.6f, -17.6f, -34.4f, -17.6f, 1, 1f)
            ln(-84.4f, -12.4f, -33.6f, -12.4f, 1, 1f)
            ln(-85.2f, -7.2f, -32.8f, -7.2f, 1, 1f)
            pg(0, 1f, true, -74f, -24f, -48f, -24f, -46f, -7f, -76f, -7f)
            ln(-61f, -24f, -60f, -14f, 0, 1f)
            ln(-75f, -14f, -54f, -14f, 0, 1f)
            rc(-122f, -10f, 34f, 8f, 4f, 2, 1f)
            rc(-122f, -10f, 34f, 8f, 4f, 0, 1f)
            ci(-118f, -6f, 4f, 2, 1f)
            ci(-118f, -6f, 4f, 0, 1f)
            ci(-118f, -6f, 1.5f, 0, 1f)
            pg(2, 1f, true, -28f, -4f, -6f, -18f, -4f, -15f, -26f, -1f)
            pg(0, 1f, true, -28f, -4f, -6f, -18f, -4f, -15f, -26f, -1f)
            pg(3, 1f, true, -28f, -4f, -26f, -1f, -31f, 0f)
            pg(0, 1f, true, -28f, -4f, -26f, -1f, -31f, 0f)
        }
        "H" -> {
            pg(2, 1f, true, -96f, -20f, -38f, -20f, -38f, -2f, -96f, -2f)
            pg(0, 1f, true, -96f, -20f, -38f, -20f, -38f, -2f, -96f, -2f)
            pg(3, 1f, true, -96f, -20f, -38f, -20f, -30f, -27f, -88f, -27f)
            pg(0, 1f, true, -96f, -20f, -38f, -20f, -30f, -27f, -88f, -27f)
            pg(2, 1f, true, -38f, -20f, -38f, -2f, -30f, -9f, -30f, -27f)
            pg(0, 1f, true, -38f, -20f, -38f, -2f, -30f, -9f, -30f, -27f)
            ln(-38f, -20f, -30f, -9f, 1, 1f)
            ln(-38f, -2f, -30f, -27f, 1, 1f)
            ln(-67f, -20f, -67f, -2f, 1, 1f)
            ln(-67f, -20f, -59f, -27f, 1, 1f)
            ci(-92f, -5f, 0.7f, 5, 1f)
            ci(-80f, -5f, 0.7f, 5, 1f)
            ci(-54f, -5f, 0.7f, 5, 1f)
            ci(-44f, -5f, 0.7f, 5, 1f)
            pg(3, 1f, true, -121f, -12.5f, -108f, -11.2f, -101f, -9.3f, -121f, -9.2f)
            pg(0, 1f, true, -121f, -12.5f, -108f, -11.2f, -101f, -9.3f, -121f, -9.2f)
            pg(3, 1f, true, -121f, -8.8f, -101f, -9f, -108f, -7f, -121f, -5.6f)
            pg(0, 1f, true, -121f, -8.8f, -101f, -9f, -108f, -7f, -121f, -5.6f)
            rc(-129f, -13f, 10f, 8.5f, 2f, 2, 1f)
            rc(-129f, -13f, 10f, 8.5f, 2f, 0, 1f)
            ci(-126f, -11f, 1.1f, 0, 1f)
            ci(-122f, -7f, 1.1f, 0, 1f)
            pg(2, 1f, true, -129f, -12.6f, -139f, -14.2f, -139f, -11.6f, -129f, -10.6f)
            pg(0, 1f, true, -129f, -12.6f, -139f, -14.2f, -139f, -11.6f, -129f, -10.6f)
            pg(2, 1f, true, -129f, -6.9f, -139f, -5.9f, -139f, -3.3f, -129f, -4.9f)
            pg(0, 1f, true, -129f, -6.9f, -139f, -5.9f, -139f, -3.3f, -129f, -4.9f)
            rc(-162f, -15f, 24f, 4f, 2f, 3, 1f)
            rc(-162f, -15f, 24f, 4f, 2f, 0, 1f)
            rc(-162f, -6.6f, 24f, 4f, 2f, 3, 1f)
            rc(-162f, -6.6f, 24f, 4f, 2f, 0, 1f)
            ln(-139f, -13f, -139f, -12.2f, 0, 1f)
            pg(1, 1f, false, -136f, -10.8f, -136.57f, -10.55f, -136.8f, -10.3f, -136.57f, -10.05f, -136f, -9.8f, -135.43f, -9.55f, -135.2f, -9.3f, -135.43f, -9.05f, -136f, -8.8f, -136.57f, -8.55f, -136.8f, -8.3f, -136.57f, -8.05f, -136f, -7.8f, -135.43f, -7.55f, -135.2f, -7.3f, -135.43f, -7.05f, -136f, -6.8f)
            pg(1, 1f, false, -162f, -4.2f, -163.15f, -4.55f, -164.12f, -5.55f, -164.77f, -7.04f, -165f, -8.8f, -164.77f, -10.56f, -164.12f, -12.05f, -163.15f, -13.05f, -162f, -13.4f)
        }
        "I" -> {
            rc(-114f, -9f, 70f, 7f, 1.5f, 2, 1f)
            rc(-114f, -9f, 70f, 7f, 1.5f, 0, 1f)
            rc(-83f, -8f, 10f, 5f, 2f, 3, 1f)
            rc(-83f, -8f, 10f, 5f, 2f, 1, 1f)
            ci(-78f, -5.5f, 1.4f, 4, 1f)
            ln(-108f, -9f, -108f, -2f, 1, 1f)
            ln(-54f, -9f, -54f, -2f, 1, 1f)
            pg(2, 1f, true, -14.12f, -15.56f, -11.05f, -15.13f, -11.05f, -12.87f, -14.12f, -12.44f, -15.09f, -9.46f, -12.86f, -7.3f, -14.19f, -5.47f, -16.93f, -6.93f, -19.46f, -5.09f, -18.92f, -2.03f, -21.08f, -1.33f, -22.44f, -4.12f, -25.56f, -4.12f, -26.92f, -1.33f, -29.08f, -2.03f, -28.54f, -5.09f, -31.07f, -6.93f, -33.81f, -5.47f, -35.14f, -7.3f, -32.91f, -9.46f, -33.88f, -12.44f, -36.95f, -12.87f, -36.95f, -15.13f, -33.88f, -15.56f, -32.91f, -18.54f, -35.14f, -20.7f, -33.81f, -22.53f, -31.07f, -21.07f, -28.54f, -22.91f, -29.08f, -25.97f, -26.92f, -26.67f, -25.56f, -23.88f, -22.44f, -23.88f, -21.08f, -26.67f, -18.92f, -25.97f, -19.46f, -22.91f, -16.93f, -21.07f, -14.19f, -22.53f, -12.86f, -20.7f, -15.09f, -18.54f)
            pg(0, 1f, true, -14.12f, -15.56f, -11.05f, -15.13f, -11.05f, -12.87f, -14.12f, -12.44f, -15.09f, -9.46f, -12.86f, -7.3f, -14.19f, -5.47f, -16.93f, -6.93f, -19.46f, -5.09f, -18.92f, -2.03f, -21.08f, -1.33f, -22.44f, -4.12f, -25.56f, -4.12f, -26.92f, -1.33f, -29.08f, -2.03f, -28.54f, -5.09f, -31.07f, -6.93f, -33.81f, -5.47f, -35.14f, -7.3f, -32.91f, -9.46f, -33.88f, -12.44f, -36.95f, -12.87f, -36.95f, -15.13f, -33.88f, -15.56f, -32.91f, -18.54f, -35.14f, -20.7f, -33.81f, -22.53f, -31.07f, -21.07f, -28.54f, -22.91f, -29.08f, -25.97f, -26.92f, -26.67f, -25.56f, -23.88f, -22.44f, -23.88f, -21.08f, -26.67f, -18.92f, -25.97f, -19.46f, -22.91f, -16.93f, -21.07f, -14.19f, -22.53f, -12.86f, -20.7f, -15.09f, -18.54f)
            ci(-24f, -14f, 6f, 1, 1f)
            ci(-24f, -14f, 3f, 4, 1f)
            ci(-24f, -14f, 3f, 0, 1f)
        }
        "J" -> {
            pg(2, 1f, true, -110f, -12f, -88f, -12f, -88f, -26f, -78f, -26f, -78f, -12f, -62f, -12f, -62f, -2f, -110f, -2f)
            pg(0, 1f, true, -110f, -12f, -88f, -12f, -88f, -26f, -78f, -26f, -78f, -12f, -62f, -12f, -62f, -2f, -110f, -2f)
            ln(-107f, -12f, -107f, -2f, 1, 1f)
            ln(-104f, -12f, -104f, -2f, 1, 1f)
            ln(-68f, -12f, -68f, -2f, 1, 1f)
            ln(-65f, -12f, -65f, -2f, 1, 1f)
            ln(-88f, -23f, -78f, -23f, 1, 1f)
            ln(-88f, -20f, -78f, -20f, 1, 1f)
            pg(2, 1f, true, -54f, -7.5f, -22f, -9f, -22f, -2f, -54f, -3.5f)
            pg(0, 1f, true, -54f, -7.5f, -22f, -9f, -22f, -2f, -54f, -3.5f)
            ci(-50f, -5.5f, 1.3f, 4, 1f)
            ci(-50f, -5.5f, 1.3f, 0, 1f)
            ln(-46f, -5.5f, -26f, -5.5f, 1, 1f)
            pg(2, 1f, true, -24f, -14f, -12f, -14f, -12f, -2f, -24f, -2f)
            pg(0, 1f, true, -24f, -14f, -12f, -14f, -12f, -2f, -24f, -2f)
            pg(2, 1f, true, -34f, -10f, -24f, -10f, -24f, -14f, -26f, -15.6f, -27.25f, -14f, -28.5f, -15.6f, -29.75f, -14f, -31f, -15.6f, -32.25f, -14f, -33.5f, -15.6f, -34.75f, -14f)
            pg(0, 1f, true, -34f, -10f, -24f, -10f, -24f, -14f, -26f, -15.6f, -27.25f, -14f, -28.5f, -15.6f, -29.75f, -14f, -31f, -15.6f, -32.25f, -14f, -33.5f, -15.6f, -34.75f, -14f)
            rc(-18f, -31f, 5f, 17f, 1f, 2, 1f)
            rc(-18f, -31f, 5f, 17f, 1f, 0, 1f)
            pg(2, 1f, true, -35f, -31f, -13f, -31f, -13f, -27.5f, -21f, -26.6f, -22.25f, -25f, -23.5f, -26.6f, -24.75f, -25f, -26f, -26.6f, -27.25f, -25f, -28.5f, -26.6f, -29.75f, -25f, -31f, -26.6f, -32.25f, -25f, -33.5f, -26.6f, -34.75f, -25f, -36f, -26.6f, -35f, -26.6f)
            pg(0, 1f, true, -35f, -31f, -13f, -31f, -13f, -27.5f, -21f, -26.6f, -22.25f, -25f, -23.5f, -26.6f, -24.75f, -25f, -26f, -26.6f, -27.25f, -25f, -28.5f, -26.6f, -29.75f, -25f, -31f, -26.6f, -32.25f, -25f, -33.5f, -26.6f, -34.75f, -25f, -36f, -26.6f, -35f, -26.6f)
            rc(-21.5f, -23f, 12f, 6f, 2f, 3, 1f)
            rc(-21.5f, -23f, 12f, 6f, 2f, 0, 1f)
            ln(-18.5f, -23f, -18.5f, -17f, 1, 1f)
            ln(-15.5f, -23f, -15.5f, -17f, 1, 1f)
            ln(-12.5f, -23f, -12.5f, -17f, 1, 1f)
        }
        "K" -> {
            rc(-110f, -11f, 22f, 9f, 4f, 2, 1f)
            rc(-110f, -11f, 22f, 9f, 4f, 0, 1f)
            ln(-104f, -10f, -104f, -3f, 1, 1f)
            ln(-99f, -10f, -99f, -3f, 1, 1f)
            ln(-94f, -10f, -94f, -3f, 1, 1f)
            rc(-89f, -9f, 3f, 5f, 1f, 3, 1f)
            rc(-89f, -9f, 3f, 5f, 1f, 0, 1f)
            rc(-86f, -7.5f, 24f, 2f, 1f, 2, 1f)
            rc(-86f, -7.5f, 24f, 2f, 1f, 0, 1f)
            pg(3, 1f, true, -62f, -7.8f, -57f, -7.2f, -57f, -5.8f, -62f, -5.2f)
            pg(0, 1f, true, -62f, -7.8f, -57f, -7.2f, -57f, -5.8f, -62f, -5.2f)
            pg(0, 1f, true, -17f, -12f, -17.44f, -9.54f, -18.74f, -7.25f, -20.81f, -5.28f, -23.5f, -3.77f, -26.64f, -2.82f, -30f, -2.5f, -33.36f, -2.82f, -36.5f, -3.77f, -39.19f, -5.28f, -41.26f, -7.25f, -42.56f, -9.54f, -43f, -12f, -42.56f, -14.46f, -41.26f, -16.75f, -39.19f, -18.72f, -36.5f, -20.23f, -33.36f, -21.18f, -30f, -21.5f, -26.64f, -21.18f, -23.5f, -20.23f, -20.81f, -18.72f, -18.74f, -16.75f, -17.44f, -14.46f, -17f, -12f)
            pg(0, 1f, true, -19.5f, -12f, -19.86f, -10.06f, -20.91f, -8.25f, -22.58f, -6.7f, -24.75f, -5.5f, -27.28f, -4.76f, -30f, -4.5f, -32.72f, -4.76f, -35.25f, -5.5f, -37.42f, -6.7f, -39.09f, -8.25f, -40.14f, -10.06f, -40.5f, -12f, -40.14f, -13.94f, -39.09f, -15.75f, -37.42f, -17.3f, -35.25f, -18.5f, -32.72f, -19.24f, -30f, -19.5f, -27.28f, -19.24f, -24.75f, -18.5f, -22.58f, -17.3f, -20.91f, -15.75f, -19.86f, -13.94f, -19.5f, -12f)
            pg(0, 1f, true, -22f, -12f, -22.27f, -10.58f, -23.07f, -9.25f, -24.34f, -8.11f, -26f, -7.24f, -27.93f, -6.69f, -30f, -6.5f, -32.07f, -6.69f, -34f, -7.24f, -35.66f, -8.11f, -36.93f, -9.25f, -37.73f, -10.58f, -38f, -12f, -37.73f, -13.42f, -36.93f, -14.75f, -35.66f, -15.89f, -34f, -16.76f, -32.07f, -17.31f, -30f, -17.5f, -27.93f, -17.31f, -26f, -16.76f, -24.34f, -15.89f, -23.07f, -14.75f, -22.27f, -13.42f, -22f, -12f)
            pg(0, 1.2f, false, -17f, -10f, -15.73f, -8.62f, -14.44f, -7.5f, -13.11f, -6.62f, -11.75f, -6f, -10.36f, -5.62f, -8.94f, -5.5f, -7.48f, -5.62f, -6f, -6f)
            ln(-6f, -6f, -3f, -7f, 1, 1.2f)
            pg(3, 1f, true, -52.6f, -2f, -47.4f, -2f, -48.8f, -8f, -51.2f, -8f)
            pg(0, 1f, true, -52.6f, -2f, -47.4f, -2f, -48.8f, -8f, -51.2f, -8f)
            ln(-51.8f, -4.5f, -48.2f, -4.5f, 1, 1f)
            pg(3, 1f, true, -47.6f, -2f, -42.4f, -2f, -43.8f, -8f, -46.2f, -8f)
            pg(0, 1f, true, -47.6f, -2f, -42.4f, -2f, -43.8f, -8f, -46.2f, -8f)
            ln(-46.8f, -4.5f, -43.2f, -4.5f, 1, 1f)
        }
        "L" -> {
            rc(-38f, -28f, 26f, 26f, 6f, 2, 1f)
            rc(-38f, -28f, 26f, 26f, 6f, 0, 1f)
            ci(-25f, -15f, 9f, 1, 1f)
            rc(-30f, -18f, 10f, 5f, 1f, 3, 1f)
            rc(-30f, -18f, 10f, 5f, 1f, 1, 1f)
            ln(-25f, -24f, -25f, -22f, 0, 1.2f)
            rc(-80f, -30f, 20f, 28f, 3f, 2, 1f)
            rc(-80f, -30f, 20f, 28f, 3f, 0, 1f)
            rc(-77f, -27f, 14f, 7f, 1f, 3, 1f)
            rc(-77f, -27f, 14f, 7f, 1f, 1, 1f)
            ci(-70f, -12f, 4.5f, 2, 1f)
            ci(-70f, -12f, 4.5f, 0, 1f)
            ln(-70f, -12f, -67f, -15f, 0, 1.2f)
            pg(0, 1f, false, -76f, -2f, -78.09f, -2.7f, -80.19f, -3.31f, -82.29f, -3.76f, -84.41f, -4f, -86.54f, -4.01f, -88.69f, -3.81f, -90.84f, -3.45f, -93f, -3f, -95.16f, -2.55f, -97.31f, -2.19f, -99.46f, -1.99f, -101.59f, -2f, -103.71f, -2.24f, -105.81f, -2.69f, -107.91f, -3.3f, -110f, -4f)
            pg(1, 1f, false, -64f, -2f, -66.53f, -2.45f, -69.05f, -2.81f, -71.57f, -3.01f, -74.07f, -3f, -76.57f, -2.76f, -79.05f, -2.31f, -81.53f, -1.7f, -84f, -1f, -86.47f, -0.3f, -88.95f, 0.31f, -91.43f, 0.76f, -93.93f, 1f, -96.43f, 1.01f, -98.95f, 0.81f, -101.47f, 0.45f, -104f, 0f)
            rc(-116f, -6f, 6f, 3f, 1f, 2, 1f)
            rc(-116f, -6f, 6f, 3f, 1f, 0, 1f)
        }
        "M" -> {
            pg(2, 1f, true, -24f, -30f, -20.88f, -29.65f, -17.93f, -28.61f, -15.27f, -26.95f, -13.05f, -24.73f, -11.39f, -22.07f, -10.35f, -19.12f, -10f, -16f, -10.35f, -12.88f, -11.39f, -9.93f, -13.05f, -7.27f, -15.27f, -5.05f, -17.93f, -3.39f, -20.88f, -2.35f, -24f, -2f, -38f, -2f, -38f, -24f, -36f, -28f, -24f, -30f)
            pg(0, 1f, true, -24f, -30f, -20.88f, -29.65f, -17.93f, -28.61f, -15.27f, -26.95f, -13.05f, -24.73f, -11.39f, -22.07f, -10.35f, -19.12f, -10f, -16f, -10.35f, -12.88f, -11.39f, -9.93f, -13.05f, -7.27f, -15.27f, -5.05f, -17.93f, -3.39f, -20.88f, -2.35f, -24f, -2f, -38f, -2f, -38f, -24f, -36f, -28f, -24f, -30f)
            rc(-12f, -24f, 3f, 16f, 1.5f, 2, 1f)
            rc(-12f, -24f, 3f, 16f, 1.5f, 0, 1f)
            ci(-24f, -16f, 8f, 4, 1f)
            ci(-24f, -16f, 8f, 1, 1f)
            ci(-24f, -16f, 4.5f, 1, 1f)
            ci(-24f, -16f, 1.4f, 5, 1f)
            rc(-35f, -27f, 9f, 3.5f, 1.7f, 3, 1f)
            rc(-35f, -27f, 9f, 3.5f, 1.7f, 0, 1f)
            rc(-38f, -9f, 3f, 7f, 1f, 3, 1f)
            rc(-38f, -9f, 3f, 7f, 1f, 0, 1f)
            pg(2, 1f, true, -96f, -6f, -38f, -6.5f, -38f, -2f, -96f, -2f)
            pg(0, 1f, true, -96f, -6f, -38f, -6.5f, -38f, -2f, -96f, -2f)
            ln(-92f, -6f, -92f, -3.2f, 1, 1f)
            ln(-88f, -6f, -88f, -4.6f, 1, 1f)
            ln(-84f, -6f, -84f, -4.6f, 1, 1f)
            ln(-80f, -6f, -80f, -4.6f, 1, 1f)
            ln(-76f, -6f, -76f, -3.2f, 1, 1f)
            ln(-72f, -6f, -72f, -4.6f, 1, 1f)
            ln(-68f, -6f, -68f, -4.6f, 1, 1f)
            ln(-64f, -6f, -64f, -4.6f, 1, 1f)
            ln(-60f, -6f, -60f, -3.2f, 1, 1f)
            ln(-56f, -6f, -56f, -4.6f, 1, 1f)
            ln(-52f, -6f, -52f, -4.6f, 1, 1f)
            ln(-48f, -6f, -48f, -4.6f, 1, 1f)
            ln(-44f, -6f, -44f, -3.2f, 1, 1f)
            rc(-98f, -8f, 2.5f, 8f, 0.6f, 5, 1f)
            rc(-98f, -8f, 2.5f, 8f, 0.6f, 0, 1f)
            pg(3, 1f, true, -71f, -22.5f, -76.61f, -22.67f, -82.11f, -22.86f, -87.5f, -23.06f, -92.78f, -23.28f, -97.94f, -23.51f, -103f, -23.75f, -107.94f, -24.01f, -112.78f, -24.28f, -117.5f, -24.56f, -122.11f, -24.86f, -126.61f, -25.17f, -131f, -25.5f, -131f, -25.5f, -127.22f, -24.3f, -123.22f, -23.19f, -119f, -22.19f, -114.56f, -21.28f, -109.89f, -20.47f, -105f, -19.75f, -99.89f, -19.13f, -94.56f, -18.61f, -89f, -18.19f, -83.22f, -17.86f, -77.22f, -17.63f, -71f, -17.5f)
            pg(0, 1f, true, -71f, -22.5f, -76.61f, -22.67f, -82.11f, -22.86f, -87.5f, -23.06f, -92.78f, -23.28f, -97.94f, -23.51f, -103f, -23.75f, -107.94f, -24.01f, -112.78f, -24.28f, -117.5f, -24.56f, -122.11f, -24.86f, -126.61f, -25.17f, -131f, -25.5f, -131f, -25.5f, -127.22f, -24.3f, -123.22f, -23.19f, -119f, -22.19f, -114.56f, -21.28f, -109.89f, -20.47f, -105f, -19.75f, -99.89f, -19.13f, -94.56f, -18.61f, -89f, -18.19f, -83.22f, -17.86f, -77.22f, -17.63f, -71f, -17.5f)
            pg(1, 1f, false, -75f, -19.2f, -80.54f, -19.31f, -85.96f, -19.49f, -91.26f, -19.73f, -96.44f, -20.03f, -101.5f, -20.4f, -106.44f, -20.83f, -111.26f, -21.33f, -115.96f, -21.89f, -120.54f, -22.51f, -125f, -23.2f)
            rc(-73f, -25f, 3f, 10f, 1f, 2, 1f)
            rc(-73f, -25f, 3f, 10f, 1f, 0, 1f)
            rc(-70f, -23.5f, 24f, 7.5f, 3.75f, 2, 1f)
            rc(-70f, -23.5f, 24f, 7.5f, 3.75f, 0, 1f)
            ci(-63f, -19.75f, 0.9f, 5, 1f)
            ci(-54f, -19.75f, 0.9f, 5, 1f)
            ci(-49f, -19.75f, 1.1f, 1, 1f)
        }
        "N" -> {
            pg(2, 1f, true, -120f, -6.5f, -60f, -8f, -60f, -3f, -120f, -2.5f)
            pg(0, 1f, true, -120f, -6.5f, -60f, -8f, -60f, -3f, -120f, -2.5f)
            rc(-122f, -7.5f, 6f, 6f, 2.5f, 2, 1f)
            rc(-122f, -7.5f, 6f, 6f, 2.5f, 0, 1f)
            ln(-112f, -4.5f, -96f, -4.9f, 1, 1f)
            pg(2, 1f, true, -64f, -17f, -50f, -17f, -48f, -15f, -48f, 1f, -50f, 3f, -64f, 3f, -66f, 1f, -66f, -15f)
            pg(0, 1f, true, -64f, -17f, -50f, -17f, -48f, -15f, -48f, 1f, -50f, 3f, -64f, 3f, -66f, 1f, -66f, -15f)
            ln(-66f, -13f, -48f, -13f, 1, 1f)
            ln(-66f, -1f, -48f, -1f, 1, 1f)
            rc(-60f, -10f, 6f, 7f, 1f, 3, 1f)
            rc(-60f, -10f, 6f, 7f, 1f, 1, 1f)
            pg(2, 1f, true, -40f, -2f, -40f, -16f, -26f, -16f, -23f, -12f, -25f, -8f, -22f, -5f, -23f, -2f)
            pg(0, 1f, true, -40f, -2f, -40f, -16f, -26f, -16f, -23f, -12f, -25f, -8f, -22f, -5f, -23f, -2f)
            rc(-37f, -13f, 5f, 8f, 1f, 3, 1f)
            rc(-37f, -13f, 5f, 8f, 1f, 1, 1f)
            pg(1, 1f, false, -30f, -16f, -31f, -11f, -28f, -8f, -30f, -4f)
            pg(2, 1f, true, -18f, -2f, -16f, -7f, -11f, -8f, -8f, -2f)
            pg(0, 1f, true, -18f, -2f, -16f, -7f, -11f, -8f, -8f, -2f)
            pg(2, 1f, true, -20f, -10f, -17f, -14f, -13f, -12f, -15f, -9f)
            pg(0, 1f, true, -20f, -10f, -17f, -14f, -13f, -12f, -15f, -9f)
            ci(-6f, -10f, 0.8f, 1, 1f)
            ci(-9f, -13f, 0.8f, 1, 1f)
            ci(-4f, -6f, 0.8f, 1, 1f)
            ci(-21f, -18f, 0.8f, 1, 1f)
        }
        "O" -> {
            pg(2, 1f, true, -45f, -7f, -44.71f, -10.12f, -43.86f, -13.12f, -42.47f, -15.89f, -40.61f, -18.31f, -38.33f, -20.3f, -35.74f, -21.78f, -32.93f, -22.69f, -30f, -23f, -27.07f, -22.69f, -24.26f, -21.78f, -21.67f, -20.3f, -19.39f, -18.31f, -17.53f, -15.89f, -16.14f, -13.12f, -15.29f, -10.12f, -15f, -7f)
            pg(0, 1f, true, -45f, -7f, -44.71f, -10.12f, -43.86f, -13.12f, -42.47f, -15.89f, -40.61f, -18.31f, -38.33f, -20.3f, -35.74f, -21.78f, -32.93f, -22.69f, -30f, -23f, -27.07f, -22.69f, -24.26f, -21.78f, -21.67f, -20.3f, -19.39f, -18.31f, -17.53f, -15.89f, -16.14f, -13.12f, -15.29f, -10.12f, -15f, -7f)
            pg(2, 1f, true, -46f, -7f, -43.33f, -6.62f, -40.67f, -6.31f, -38f, -6.06f, -35.33f, -5.89f, -32.67f, -5.78f, -30f, -5.75f, -27.33f, -5.78f, -24.67f, -5.89f, -22f, -6.06f, -19.33f, -6.31f, -16.67f, -6.62f, -14f, -7f, -12f, -6f, -10f, -4f, -10f, -4f, -13.32f, -3.62f, -16.61f, -3.32f, -19.88f, -3.09f, -23.11f, -2.94f, -26.32f, -2.87f, -29.5f, -2.88f, -32.65f, -2.95f, -35.78f, -3.11f, -38.88f, -3.34f, -41.94f, -3.65f, -44.99f, -4.04f, -48f, -4.5f)
            pg(0, 1f, true, -46f, -7f, -43.33f, -6.62f, -40.67f, -6.31f, -38f, -6.06f, -35.33f, -5.89f, -32.67f, -5.78f, -30f, -5.75f, -27.33f, -5.78f, -24.67f, -5.89f, -22f, -6.06f, -19.33f, -6.31f, -16.67f, -6.62f, -14f, -7f, -12f, -6f, -10f, -4f, -10f, -4f, -13.32f, -3.62f, -16.61f, -3.32f, -19.88f, -3.09f, -23.11f, -2.94f, -26.32f, -2.87f, -29.5f, -2.88f, -32.65f, -2.95f, -35.78f, -3.11f, -38.88f, -3.34f, -41.94f, -3.65f, -44.99f, -4.04f, -48f, -4.5f)
            pg(1, 1f, false, -41f, -7.5f, -40.09f, -10.47f, -39.12f, -13.12f, -38.09f, -15.47f, -37f, -17.5f, -35.84f, -19.22f, -34.62f, -20.62f, -33.34f, -21.72f, -32f, -22.5f)
            pg(1, 1f, false, -30f, -7.5f, -30f, -10.47f, -30f, -13.12f, -30f, -15.47f, -30f, -17.5f, -30f, -19.22f, -30f, -20.62f, -30f, -21.72f, -30f, -22.5f)
            pg(1, 1f, false, -19f, -7.5f, -19.91f, -10.47f, -20.88f, -13.12f, -21.91f, -15.47f, -23f, -17.5f, -24.16f, -19.22f, -25.38f, -20.62f, -26.66f, -21.72f, -28f, -22.5f)
            ci(-21f, -14f, 2.4f, 3, 1f)
            ci(-21f, -14f, 2.4f, 1, 1f)
            rc(-124f, -10f, 9f, 8f, 3f, 4, 1f)
            rc(-124f, -10f, 9f, 8f, 3f, 0, 1f)
            rc(-116f, -7.5f, 48f, 3f, 1.5f, 2, 1f)
            rc(-116f, -7.5f, 48f, 3f, 1.5f, 0, 1f)
            rc(-70f, -8.5f, 5f, 5f, 1f, 2, 1f)
            rc(-70f, -8.5f, 5f, 5f, 1f, 0, 1f)
            pg(2, 1f, true, -66f, -12f, -64.36f, -12.11f, -62.78f, -12.11f, -61.25f, -12f, -59.78f, -11.78f, -58.36f, -11.44f, -57f, -11f, -55.69f, -10.44f, -54.44f, -9.78f, -53.25f, -9f, -52.11f, -8.11f, -51.03f, -7.11f, -50f, -6f, -50f, -6f, -51.03f, -4.89f, -52.11f, -3.89f, -53.25f, -3f, -54.44f, -2.22f, -55.69f, -1.56f, -57f, -1f, -58.36f, -0.56f, -59.78f, -0.22f, -61.25f, 0f, -62.78f, 0.11f, -64.36f, 0.11f, -66f, 0f)
            pg(0, 1f, true, -66f, -12f, -64.36f, -12.11f, -62.78f, -12.11f, -61.25f, -12f, -59.78f, -11.78f, -58.36f, -11.44f, -57f, -11f, -55.69f, -10.44f, -54.44f, -9.78f, -53.25f, -9f, -52.11f, -8.11f, -51.03f, -7.11f, -50f, -6f, -50f, -6f, -51.03f, -4.89f, -52.11f, -3.89f, -53.25f, -3f, -54.44f, -2.22f, -55.69f, -1.56f, -57f, -1f, -58.36f, -0.56f, -59.78f, -0.22f, -61.25f, 0f, -62.78f, 0.11f, -64.36f, 0.11f, -66f, 0f)
            ln(-64f, -6f, -54f, -6f, 1, 1f)
        }
        "P" -> {
            rc(-80f, -30f, 22f, 28f, 2f, 2, 1f)
            rc(-80f, -30f, 22f, 28f, 2f, 0, 1f)
            rc(-73f, -32f, 8f, 4f, 1f, 3, 1f)
            rc(-73f, -32f, 8f, 4f, 1f, 0, 1f)
            pg(0, 1f, false, -77f, -23f, -75.5f, -21.5f, -73f, -25f)
            ln(-70f, -23f, -62f, -23f, 1, 1f)
            pg(0, 1f, false, -77f, -16f, -75.5f, -14.5f, -73f, -18f)
            ln(-70f, -16f, -62f, -16f, 1, 1f)
            pg(0, 1f, false, -77f, -9f, -75.5f, -7.5f, -73f, -11f)
            ln(-70f, -9f, -62f, -9f, 1, 1f)
            rc(-48f, -24f, 13f, 22f, 3f, 2, 1f)
            rc(-48f, -24f, 13f, 22f, 3f, 0, 1f)
            ln(-38f, -24f, -38f, -31f, 0, 1.6f)
            rc(-45f, -21f, 7f, 5f, 1f, 3, 1f)
            rc(-45f, -21f, 7f, 5f, 1f, 1, 1f)
            ln(-45f, -12f, -38f, -12f, 1, 1f)
            ln(-45f, -9f, -38f, -9f, 1, 1f)
            ln(-45f, -6f, -38f, -6f, 1, 1f)
        }
        "Q" -> {
            rc(-82f, -12f, 40f, 7f, 2f, 2, 1f)
            rc(-82f, -12f, 40f, 7f, 2f, 0, 1f)
            ci(-72f, -21f, 8f, 2, 1f)
            ci(-72f, -21f, 8f, 0, 1f)
            ln(-72f, -21f, -68f, -25f, 0, 1.2f)
            pg(1, 1f, false, -76.76f, -18.25f, -77.5f, -21f, -76.76f, -23.75f, -74.75f, -25.76f, -72f, -26.5f, -69.25f, -25.76f, -67.24f, -23.75f, -66.5f, -21f, -67.24f, -18.25f)
            ci(-52f, -21f, 8f, 2, 1f)
            ci(-52f, -21f, 8f, 0, 1f)
            ln(-52f, -21f, -48f, -25f, 0, 1.2f)
            pg(1, 1f, false, -56.76f, -18.25f, -57.5f, -21f, -56.76f, -23.75f, -54.75f, -25.76f, -52f, -26.5f, -49.25f, -25.76f, -47.24f, -23.75f, -46.5f, -21f, -47.24f, -18.25f)
            pg(0, 1f, false, -78f, -5f, -79f, -5.05f, -79.99f, -5.04f, -80.94f, -4.93f, -81.84f, -4.69f, -82.69f, -4.31f, -83.49f, -3.79f, -84.25f, -3.17f, -85f, -2.5f, -85.75f, -1.83f, -86.51f, -1.21f, -87.31f, -0.69f, -88.16f, -0.31f, -89.06f, -0.07f, -90.01f, 0.04f, -91f, 0.05f, -92f, 0f)
            pg(0, 1f, false, -62f, -5f, -62.08f, -4.37f, -62.11f, -3.77f, -62.05f, -3.23f, -61.87f, -2.75f, -61.55f, -2.35f, -61.11f, -2.02f, -60.58f, -1.75f, -60f, -1.5f, -59.42f, -1.25f, -58.89f, -0.98f, -58.45f, -0.65f, -58.13f, -0.25f, -57.95f, 0.23f, -57.89f, 0.77f, -57.92f, 1.37f, -58f, 2f)
            pg(0, 1f, false, -46f, -5f, -45.55f, -4.35f, -45.07f, -3.74f, -44.54f, -3.24f, -43.95f, -2.86f, -43.29f, -2.61f, -42.57f, -2.49f, -41.8f, -2.47f, -41f, -2.5f, -40.2f, -2.53f, -39.43f, -2.51f, -38.71f, -2.39f, -38.05f, -2.14f, -37.46f, -1.76f, -36.93f, -1.26f, -36.45f, -0.65f, -36f, 0f)
            rc(-30f, -14f, 26f, 12f, 1.5f, 2, 1f)
            rc(-30f, -14f, 26f, 12f, 1.5f, 0, 1f)
            ln(-30f, -10f, -4f, -10f, 1, 1f)
            pg(0, 1.6f, false, -22f, -14f, -21.62f, -15.53f, -20.54f, -16.83f, -18.91f, -17.7f, -17f, -18f, -15.09f, -17.7f, -13.46f, -16.83f, -12.38f, -15.53f, -12f, -14f)
            rc(-19f, -11f, 4f, 3f, 0.5f, 3, 1f)
            rc(-19f, -11f, 4f, 3f, 0.5f, 0, 1f)
        }
        "T" -> {
            rc(-100f, -8f, 40f, 6f, 1f, 2, 1f)
            rc(-100f, -8f, 40f, 6f, 1f, 0, 1f)
            rc(-96f, -14f, 34f, 6f, 1f, 3, 1f)
            rc(-96f, -14f, 34f, 6f, 1f, 0, 1f)
            rc(-102f, -20f, 38f, 6f, 1f, 2, 1f)
            rc(-102f, -20f, 38f, 6f, 1f, 0, 1f)
            ln(-64f, -7f, -64f, -3f, 1, 1f)
            ln(-66f, -13f, -66f, -9f, 1, 1f)
            ln(-68f, -19f, -68f, -15f, 1, 1f)
            pg(2, 1f, true, -83f, -32f, -66f, -27f, -83f, -22f, -100f, -27f)
            pg(0, 1f, true, -83f, -32f, -66f, -27f, -83f, -22f, -100f, -27f)
            rc(-89f, -25f, 12f, 5f, 1f, 2, 1f)
            rc(-89f, -25f, 12f, 5f, 1f, 0, 1f)
            ln(-83f, -27f, -70f, -24f, 0, 1f)
            ln(-70f, -24f, -70f, -18f, 0, 1.2f)
            pg(2, 1f, true, -48f, -6f, -14f, -6f, -14f, -2f, -48f, -2f)
            pg(0, 1f, true, -48f, -6f, -14f, -6f, -14f, -2f, -48f, -2f)
            pg(3, 1f, true, -14f, -6f, -6f, -4f, -14f, -2f)
            pg(0, 1f, true, -14f, -6f, -6f, -4f, -14f, -2f)
            rc(-52f, -6f, 4f, 4f, 1f, 3, 1f)
            rc(-52f, -6f, 4f, 4f, 1f, 0, 1f)
        }
        "U" -> {
            pg(1, 1f, false, -128f, -2f, -125.46f, -1.26f, -122.92f, -1.43f, -120.38f, -2.31f, -117.83f, -2.8f, -115.29f, -2.31f, -112.75f, -1.43f, -110.21f, -1.26f, -107.67f, -2f, -105.12f, -2.74f, -102.58f, -2.57f, -100.04f, -1.69f, -97.5f, -1.2f, -94.96f, -1.69f, -92.42f, -2.57f, -89.88f, -2.74f, -87.33f, -2f, -84.79f, -1.26f, -82.25f, -1.43f, -79.71f, -2.31f, -77.17f, -2.8f, -74.62f, -2.31f, -72.08f, -1.43f, -69.54f, -1.26f, -67f, -2f, -64.46f, -2.74f, -61.92f, -2.57f, -59.38f, -1.69f, -56.83f, -1.2f, -54.29f, -1.69f, -51.75f, -2.57f, -49.21f, -2.74f, -46.67f, -2f, -44.12f, -1.26f, -41.58f, -1.43f, -39.04f, -2.31f, -36.5f, -2.8f, -33.96f, -2.31f, -31.42f, -1.43f, -28.88f, -1.26f, -26.33f, -2f, -23.79f, -2.74f, -21.25f, -2.57f, -18.71f, -1.69f, -16.17f, -1.2f, -13.62f, -1.69f, -11.08f, -2.57f, -8.54f, -2.74f, -6f, -2f)
            pg(0, 1.6f, false, -12f, -6f, -17.02f, -7.97f, -22.06f, -9.89f, -27.14f, -11.75f, -32.25f, -13.56f, -37.39f, -15.32f, -42.56f, -17.02f, -47.77f, -18.66f, -53f, -20.25f, -58.27f, -21.79f, -63.56f, -23.27f, -68.89f, -24.69f, -74.25f, -26.06f, -79.64f, -27.38f, -85.06f, -28.64f, -90.52f, -29.85f, -96f, -31f)
            ln(-12f, -6f, -24f, -11.5f, 0, 3.4f)
            ln(-13f, -6.5f, -23f, -11f, 4, 1.4f)
            ci(-28f, -9f, 4f, 2, 1f)
            ci(-28f, -9f, 4f, 0, 1f)
            ln(-28f, -9f, -32f, -5.5f, 0, 1.1f)
            ci(-32f, -5.5f, 0.9f, 5, 1f)
            ci(-37.39f, -14.12f, 0.9f, 1, 1f)
            ci(-58.27f, -20.59f, 0.9f, 1, 1f)
            ci(-79.64f, -26.18f, 0.9f, 1, 1f)
            pg(1, 1f, false, -96f, -31f, -97.78f, -29f, -99.52f, -27f, -101.22f, -25f, -102.88f, -23f, -104.5f, -21f, -106.08f, -19f, -107.62f, -17f, -109.12f, -15f, -110.58f, -13f, -112f, -11f)
            pg(3, 1f, true, -115.4f, -8f, -115.14f, -9.3f, -114.4f, -10.4f, -113.3f, -11.14f, -112f, -11.4f, -110.7f, -11.14f, -109.6f, -10.4f, -108.86f, -9.3f, -108.6f, -8f, -108.6f, -8f)
            pg(0, 1f, true, -115.4f, -8f, -115.14f, -9.3f, -114.4f, -10.4f, -113.3f, -11.14f, -112f, -11.4f, -110.7f, -11.14f, -109.6f, -10.4f, -108.86f, -9.3f, -108.6f, -8f, -108.6f, -8f)
            pg(2, 1f, true, -108.6f, -8f, -108.86f, -6.7f, -109.6f, -5.6f, -110.7f, -4.86f, -112f, -4.6f, -113.3f, -4.86f, -114.4f, -5.6f, -115.14f, -6.7f, -115.4f, -8f)
            pg(0, 1f, true, -108.6f, -8f, -108.86f, -6.7f, -109.6f, -5.6f, -110.7f, -4.86f, -112f, -4.6f, -113.3f, -4.86f, -114.4f, -5.6f, -115.14f, -6.7f, -115.4f, -8f)
            ln(-112f, -11.4f, -112f, -13.5f, 0, 1f)
            pg(1, 1f, false, -118.11f, -5.12f, -117.39f, -5.51f, -116.35f, -5.84f, -115.05f, -6.09f, -113.57f, -6.25f, -112f, -6.3f, -110.43f, -6.25f, -108.95f, -6.09f, -107.65f, -5.84f, -106.61f, -5.51f, -105.89f, -5.12f)
            pg(1, 1f, false, -121.4f, -5.12f, -120.29f, -5.51f, -118.69f, -5.84f, -116.69f, -6.09f, -114.42f, -6.25f, -112f, -6.3f, -109.58f, -6.25f, -107.31f, -6.09f, -105.31f, -5.84f, -103.71f, -5.51f, -102.6f, -5.12f)
            pg(2, 1f, true, -60.36f, -14.05f, -60.4f, -12.82f, -61.29f, -11.46f, -62.89f, -10.18f, -64.97f, -9.18f, -67.21f, -8.61f, -69.26f, -8.56f, -70.82f, -9.03f, -71.64f, -9.95f, -71.6f, -11.18f, -70.71f, -12.54f, -69.11f, -13.82f, -67.03f, -14.82f, -64.79f, -15.39f, -62.74f, -15.44f, -61.18f, -14.97f, -60.36f, -14.05f)
            pg(0, 1f, true, -60.36f, -14.05f, -60.4f, -12.82f, -61.29f, -11.46f, -62.89f, -10.18f, -64.97f, -9.18f, -67.21f, -8.61f, -69.26f, -8.56f, -70.82f, -9.03f, -71.64f, -9.95f, -71.6f, -11.18f, -70.71f, -12.54f, -69.11f, -13.82f, -67.03f, -14.82f, -64.79f, -15.39f, -62.74f, -15.44f, -61.18f, -14.97f, -60.36f, -14.05f)
            pg(2, 1f, true, -71.64f, -9.95f, -76.42f, -11.4f, -74.37f, -5.76f)
            pg(0, 1f, true, -71.64f, -9.95f, -76.42f, -11.4f, -74.37f, -5.76f)
            ci(-62.92f, -13.76f, 0.7f, 5, 1f)
            pg(1, 1f, false, -64.94f, -14.94f, -64.88f, -13.68f, -64.59f, -12.51f, -64.06f, -11.43f, -63.3f, -10.43f)
            ci(-58f, -5f, 0.8f, 1, 1f)
            ci(-61f, -7.5f, 0.8f, 1, 1f)
            ci(-56f, -8.5f, 0.8f, 1, 1f)
            ci(-124f, -30f, 4.5f, 2, 1f)
            ci(-124f, -30f, 4.5f, 0, 1f)
            ln(-117.5f, -30f, -115f, -30f, 1, 1.1f)
            ln(-119.4f, -25.4f, -117.64f, -23.64f, 1, 1.1f)
            ln(-124f, -23.5f, -124f, -21f, 1, 1.1f)
            ln(-128.6f, -25.4f, -130.36f, -23.64f, 1, 1.1f)
            ln(-130.5f, -30f, -133f, -30f, 1, 1.1f)
            ln(-128.6f, -34.6f, -130.36f, -36.36f, 1, 1.1f)
            ln(-124f, -36.5f, -124f, -39f, 1, 1.1f)
            ln(-119.4f, -34.6f, -117.64f, -36.36f, 1, 1.1f)
        }
        "V" -> {
            rc(-76f, -16f, 36f, 14f, 2f, 2, 1f)
            rc(-76f, -16f, 36f, 14f, 2f, 0, 1f)
            pg(2, 1f, true, -76f, -16f, -75.55f, -17.56f, -74.22f, -19.04f, -72.07f, -20.36f, -69.22f, -21.47f, -65.81f, -22.31f, -62.01f, -22.82f, -58f, -23f, -53.99f, -22.82f, -50.19f, -22.31f, -46.78f, -21.47f, -43.93f, -20.36f, -41.78f, -19.04f, -40.45f, -17.56f, -40f, -16f)
            pg(0, 1f, true, -76f, -16f, -75.55f, -17.56f, -74.22f, -19.04f, -72.07f, -20.36f, -69.22f, -21.47f, -65.81f, -22.31f, -62.01f, -22.82f, -58f, -23f, -53.99f, -22.82f, -50.19f, -22.31f, -46.78f, -21.47f, -43.93f, -20.36f, -41.78f, -19.04f, -40.45f, -17.56f, -40f, -16f)
            pg(0, 1.6f, false, -65f, -23.5f, -64.66f, -25.05f, -63.66f, -26.44f, -62.11f, -27.55f, -60.16f, -28.26f, -58f, -28.5f, -55.84f, -28.26f, -53.89f, -27.55f, -52.34f, -26.44f, -51.34f, -25.05f, -51f, -23.5f)
            rc(-60f, -13f, 4f, 4f, 0.8f, 3, 1f)
            rc(-60f, -13f, 4f, 4f, 0.8f, 0, 1f)
            ln(-76f, -9f, -40f, -9f, 1, 1f)
            rc(-34f, -5f, 22f, 3f, 1.5f, 2, 1f)
            rc(-34f, -5f, 22f, 3f, 1.5f, 0, 1f)
            rc(-31f, -19f, 14f, 14f, 3f, 2, 1f)
            rc(-31f, -19f, 14f, 14f, 3f, 0, 1f)
            pg(0, 1.3f, false, -17f, -16.6f, -15.76f, -16.42f, -14.65f, -15.91f, -13.76f, -15.12f, -13.2f, -14.11f, -13f, -13f, -13.2f, -11.89f, -13.76f, -10.88f, -14.65f, -10.09f, -15.76f, -9.58f, -17f, -9.4f)
            ln(-29f, -16f, -19f, -16f, 1, 1f)
            pg(1, 1.1f, false, -27f, -21f, -26.31f, -21.59f, -25.77f, -22.19f, -25.51f, -22.81f, -25.58f, -23.44f, -25.96f, -24.08f, -26.54f, -24.74f, -27.19f, -25.4f, -27.74f, -26.05f, -28.06f, -26.69f, -28.06f, -27.32f, -27.74f, -27.93f, -27.16f, -28.53f, -26.46f, -29.12f, -25.79f, -29.71f, -25.3f, -30.31f, -25.1f, -30.93f)
            pg(1, 1.1f, false, -21.5f, -21f, -20.81f, -21.59f, -20.27f, -22.19f, -20.01f, -22.81f, -20.08f, -23.44f, -20.46f, -24.08f, -21.04f, -24.74f, -21.69f, -25.4f, -22.24f, -26.05f, -22.56f, -26.69f, -22.56f, -27.32f, -22.24f, -27.93f, -21.66f, -28.53f, -20.96f, -29.12f, -20.29f, -29.71f, -19.8f, -30.31f, -19.6f, -30.93f)
        }
    }
}

// ---------------------------------------------------------------- 12-hour time and date pickers

private val H12: java.time.format.DateTimeFormatter = java.time.format.DateTimeFormatter.ofPattern("h:mm a", Locale.US)
fun fmt12(t: java.time.LocalTime): String = t.format(H12)
fun fmt12(ms: Long): String = fmt12(ms.toZoned().toLocalTime())

fun pickTime(ctx: Context, initial: java.time.LocalTime, onPicked: (java.time.LocalTime) -> Unit) {
    android.app.TimePickerDialog(
        ctx, { _, h, m -> onPicked(java.time.LocalTime.of(h, m)) }, initial.hour, initial.minute, false,
    ).show()
}

fun pickDate(ctx: Context, initial: LocalDate, onPicked: (LocalDate) -> Unit) {
    android.app.DatePickerDialog(
        ctx, { _, y, mo, d -> onPicked(LocalDate.of(y, mo + 1, d)) },
        initial.year, initial.monthValue - 1, initial.dayOfMonth,
    ).show()
}

/** A tappable field that shows a time or date and opens a picker. */
@Composable
fun PickerField(label: String, value: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    OutlinedButton(onClick = onClick, modifier = modifier, shape = MaterialTheme.shapes.small) {
        Column(Modifier.fillMaxWidth()) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(value, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
        }
    }
}

fun epochMs(d: LocalDate, t: java.time.LocalTime): Long =
    d.atTime(t).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()

/** End time on the same day as the start, or the next day if it's earlier (past midnight). */
fun endMs(d: LocalDate, start: java.time.LocalTime, end: java.time.LocalTime): Long =
    if (end.isAfter(start)) epochMs(d, end) else epochMs(d.plusDays(1), end)

@Composable
fun EntryDialog(entry: Entry?, defaultDate: LocalDate, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val db = remember { Db.get(ctx) }
    val sites = remember { db.sites().filter { !it.ignored } }
    val known = remember { db.knownJobNames() }
    val wasTravel = entry != null && isDriveEntry(entry)
    var label by remember {
        mutableStateOf(entry?.let { if (wasTravel) jobOf(it.label) else it.label }?.takeIf { it != UNNAMED } ?: "")
    }
    var siteId by remember { mutableStateOf(entry?.siteId) }
    var date by remember { mutableStateOf(entry?.start?.toLocalDate() ?: defaultDate) }
    var start by remember { mutableStateOf(entry?.start?.toZoned()?.toLocalTime() ?: java.time.LocalTime.of(7, 0)) }
    var end by remember { mutableStateOf(entry?.end?.toZoned()?.toLocalTime() ?: java.time.LocalTime.of(15, 30)) }
    var endTouched by remember { mutableStateOf(false) }
    var note by remember { mutableStateOf(entry?.note ?: "") }
    val travelCats = setOf(Drives.PARTS_RUN, Drives.TRAVEL)
    var category by remember {
        mutableStateOf(entry?.category?.takeIf { it !in travelCats } ?: Prefs.defaultCategory(ctx).takeIf { it !in travelCats } ?: "O")
    }
    // null = regular work; "S" = Travel; "R" = Parts run
    var travelType by remember { mutableStateOf(entry?.category?.takeIf { it in travelCats }) }
    var saveAsSite by remember { mutableStateOf(entry != null && entry.siteId == null && entry.lat != null) }
    var showSuggestions by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val canSaveSite = entry?.lat != null && siteId == null && travelType == null
    val stillThere = entry?.ongoing == true && !endTouched
    val suggestions = remember(label, showSuggestions) {
        val q = label.trim()
        if (!showSuggestions || q.isEmpty()) emptyList()
        else known.filter { it.startsWith(q, ignoreCase = true) && !it.equals(q, ignoreCase = true) }.take(5)
    }

    val save: () -> Unit = save@{
        if (label.isBlank()) {
            error = "Give the site or job a name."
            return@save
        }
        val startMs = epochMs(date, start)
        val endMsVal = if (stillThere) maxOf(entry?.end ?: startMs, startMs) else endMs(date, start, end)
        var newSiteId = siteId
        val lat = entry?.lat
        val lng = entry?.lng
        if (canSaveSite && saveAsSite && lat != null && lng != null) {
            newSiteId = db.addSite(label.trim(), lat, lng, Prefs.radiusM(ctx).toDouble(), false, category)
        }
        val tt = travelType
        val updated = Entry(
            id = entry?.id ?: 0,
            siteId = if (tt != null) null else newSiteId,
            label = if (tt != null) travelPrefix(tt) + label.trim() else label.trim(),
            lat = lat, lng = lng,
            start = startMs, end = endMsVal, ongoing = stillThere, note = note.trim(),
            category = tt ?: category, breakMin = 0,
        )
        if (entry == null) db.insertEntry(updated) else db.updateEntry(updated)
        if (tt == null && newSiteId != null && newSiteId != entry?.siteId) db.site(newSiteId)?.let { db.assignUnnamedNear(it) }
        onDismiss()
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier.fillMaxWidth(0.95f),
        properties = DialogProperties(usePlatformDefaultWidth = false),
        title = { Text(if (entry == null) "Add entry" else "Edit entry", style = MaterialTheme.typography.titleMedium) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(
                    value = label,
                    onValueChange = {
                        label = it
                        siteId = null
                        showSuggestions = true
                    },
                    label = { Text(if (travelType != null) "Job it's for" else "Site / job name") },
                    singleLine = true, modifier = Modifier.fillMaxWidth(),
                )
                if (suggestions.isNotEmpty()) {
                    Card(
                        Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    ) {
                        suggestions.forEach { name ->
                            Text(
                                name,
                                Modifier.fillMaxWidth().clickable {
                                    label = name
                                    showSuggestions = false
                                    sites.firstOrNull { it.name.equals(name, ignoreCase = true) }?.let { st ->
                                        siteId = st.id
                                        st.category?.takeIf { it !in travelCats }?.let { category = it }
                                    }
                                }.padding(horizontal = 14.dp, vertical = 10.dp),
                                style = MaterialTheme.typography.bodyLarge,
                            )
                        }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    PickerField("Date", date.format(java.time.format.DateTimeFormatter.ofPattern("EEE M/d")), Modifier.weight(1f)) {
                        pickDate(ctx, date) { date = it }
                    }
                    PickerField("Start", fmt12(start), Modifier.weight(1f)) { pickTime(ctx, start) { start = it } }
                    PickerField("End", if (stillThere) "Still there" else fmt12(end), Modifier.weight(1f)) {
                        pickTime(ctx, end) {
                            end = it
                            endTouched = true
                        }
                    }
                }
                Box(Modifier.alpha(if (travelType != null) 0.4f else 1f)) {
                    CategoryPicker("Work type", category, exclude = travelCats) {
                        category = it
                        travelType = null
                    }
                }
                Text("Travel type", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = travelType == null, onClick = { travelType = null }, label = { Text("None") })
                    FilterChip(selected = travelType == Drives.TRAVEL, onClick = { travelType = Drives.TRAVEL }, label = { Text("Travel") })
                    FilterChip(
                        selected = travelType == Drives.PARTS_RUN, onClick = { travelType = Drives.PARTS_RUN },
                        label = { Text("Parts run") },
                    )
                }
                OutlinedTextField(
                    value = note, onValueChange = { note = it }, singleLine = true,
                    label = { Text("Note (optional)") }, modifier = Modifier.fillMaxWidth(),
                )
                if (canSaveSite) {
                    Row(
                        Modifier.clickable { saveAsSite = !saveAsSite },
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Checkbox(checked = saveAsSite, onCheckedChange = { saveAsSite = it })
                        Text("Save as a site, so future stops here are named automatically", style = MaterialTheme.typography.bodySmall)
                    }
                }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                if (entry != null) {
                    FlowRow {
                        TextButton(onClick = { db.deleteEntry(entry.id); onDismiss() }) {
                            Text("Delete entry", color = MaterialTheme.colorScheme.error)
                        }
                        val lat = entry.lat
                        val lng = entry.lng
                        if (lat != null && lng != null && entry.siteId == null && !wasTravel) {
                            TextButton(onClick = {
                                val id = db.addSite("Ignored place", lat, lng, Prefs.radiusM(ctx).toDouble(), true)
                                db.site(id)?.let { db.assignUnnamedNear(it) }
                                db.deleteEntry(entry.id)
                                onDismiss()
                            }) { Text("Ignore this place") }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = save) { Text("Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
fun TrackingCard() {
    val ctx = LocalContext.current
    var enabled by remember { mutableStateOf(Prefs.trackingEnabled(ctx)) }
    var tick by remember { mutableIntStateOf(0) }
    val version by Db.changes.collectAsState()
    val paused = remember(version, tick) { Prefs.pausedUntil(ctx) > System.currentTimeMillis() }
    LifecycleResumeEffect(Unit) {
        tick++
        onPauseOrDispose { }
    }
    val hasLoc = remember(tick) { Perms.hasLocation(ctx) }
    val hasBg = remember(tick) { Perms.hasBackground(ctx) }
    val batteryOk = remember(tick) {
        (ctx.getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(ctx.packageName)
    }

    val turnOn = {
        Prefs.setTrackingEnabled(ctx, true)
        enabled = true
        TrackingService.start(ctx)
    }
    val locLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        tick++
        if (Perms.hasLocation(ctx)) turnOn()
    }
    val bgLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        tick++
        if (!granted) openAppSettings(ctx)
    }

    // Make sure the service is running whenever the app is opened with tracking on.
    LaunchedEffect(Unit) {
        if (enabled && Perms.hasLocation(ctx)) {
            try {
                TrackingService.start(ctx)
            } catch (_: Exception) {
            }
        }
    }

    val today = remember(version) {
        val zone = ZoneId.systemDefault()
        val d = LocalDate.now()
        Db.get(ctx).entriesBetween(
            d.atStartOfDay(zone).toInstant().toEpochMilli(),
            d.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli(),
        )
    }
    val current = today.lastOrNull { it.ongoing }
    val todayStr = LocalDate.now().toString()
    val workStarted = remember(version, tick) { Prefs.workDay(ctx) == todayStr }
    val workStartAt = remember(version, tick) { Prefs.workStartMs(ctx) }
    val status = when {
        !enabled -> "Tracking is off. Turn it on to log your day automatically."
        !hasLoc -> "Location access is off, so nothing is being logged."
        paused -> "Done for today. Tracking starts again at ${fmtClockMin(Prefs.resumeMin(ctx))}."
        current != null -> "At ${current.label} since ${fmtTime(current.start)}"
        else -> "Watching for your next stop"
    }
    val branded = LocalBranded.current
    val onNavy = if (branded) Color.White else MaterialTheme.colorScheme.onSurface
    val softOnNavy = if (branded) Color(0xFFC9CFF0) else MaterialTheme.colorScheme.onSurfaceVariant
    val heroButton = if (branded) {
        ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = PrimeNavy)
    } else {
        ButtonDefaults.buttonColors()
    }

    Card(
        Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(
            containerColor = if (branded) PrimeNavy else MaterialTheme.colorScheme.surfaceContainerLowest,
            contentColor = onNavy,
        ),
        border = if (branded) null else androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
        Column(Modifier.padding(start = 20.dp, end = 16.dp, top = 16.dp, bottom = 16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    LocalDate.now().format(java.time.format.DateTimeFormatter.ofPattern("EEEE, MMMM d")),
                    Modifier.weight(1f), style = MaterialTheme.typography.labelLarge, color = softOnNavy,
                )
                Text(if (enabled) "Tracking" else "Off", style = MaterialTheme.typography.labelMedium, color = softOnNavy)
                Spacer(Modifier.width(8.dp))
                Switch(
                    checked = enabled,
                    onCheckedChange = { on ->
                        if (on) {
                            if (hasLoc) turnOn() else locLauncher.launch(Perms.foregroundRequest())
                        } else {
                            Prefs.setTrackingEnabled(ctx, false)
                            enabled = false
                            TrackingService.stop(ctx)
                        }
                    },
                    colors = if (branded) {
                        SwitchDefaults.colors(
                            checkedThumbColor = PrimeNavy, checkedTrackColor = Color.White, checkedBorderColor = Color.White,
                            uncheckedThumbColor = softOnNavy, uncheckedTrackColor = Color(0x22FFFFFF), uncheckedBorderColor = softOnNavy,
                        )
                    } else {
                        SwitchDefaults.colors()
                    },
                )
            }
            Text(
                fmtDur(today.sumOf { it.end - it.start }),
                style = MaterialTheme.typography.displaySmall, color = onNavy,
            )
            Text(status, style = MaterialTheme.typography.bodyMedium, color = softOnNavy)
            if (enabled && workStarted && !paused) {
                Text(
                    "Workday started ${fmtTime(workStartAt)}" + if (Prefs.workStartManual(ctx)) " (Start work)" else "",
                    style = MaterialTheme.typography.bodySmall, color = softOnNavy,
                )
            }
            if (branded) {
                Spacer(Modifier.height(14.dp))
                DoubleRule(thickness = 2)
                Spacer(Modifier.height(14.dp))
            } else {
                Spacer(Modifier.height(16.dp))
            }
            if (enabled && hasLoc) {
                if (paused) {
                    OutlinedButton(
                        onClick = { TrackingService.send(ctx, TrackingService.ACTION_RESUME) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = if (branded) ButtonDefaults.outlinedButtonColors(contentColor = Color.White) else ButtonDefaults.outlinedButtonColors(),
                        border = if (branded) androidx.compose.foundation.BorderStroke(1.dp, softOnNavy) else androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    ) { Text("Resume logging today") }
                } else if (!workStarted) {
                    Button(
                        onClick = { TrackingService.send(ctx, TrackingService.ACTION_START_WORK) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = heroButton,
                    ) { Text("Start work") }
                    Text(
                        "Going to the office? No need. Your day starts when you arrive.",
                        style = MaterialTheme.typography.bodySmall, color = softOnNavy,
                    )
                } else {
                    Button(
                        onClick = { TrackingService.send(ctx, TrackingService.ACTION_DONE) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = heroButton,
                    ) { Text("Done for today") }
                }
            } else if (!enabled) {
                Button(
                    onClick = { if (hasLoc) turnOn() else locLauncher.launch(Perms.foregroundRequest()) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = heroButton,
                ) { Text("Start tracking") }
            }
            if (enabled && !hasLoc) {
                Warning("Location permission is off.", "Allow", onNavy = branded) {
                    locLauncher.launch(Perms.foregroundRequest())
                }
            }
            if (enabled && hasLoc && !hasBg) {
                Warning("Set location to \"Allow all the time\" so tracking restarts after a reboot.", "Fix", onNavy = branded) {
                    bgLauncher.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
                }
            }
            if (enabled && !batteryOk) {
                Warning("Battery optimization can pause tracking when the screen is off.", "Fix", onNavy = branded) {
                    requestBatteryExemption(ctx)
                }
            }
        }
    }
}

@Composable
fun Warning(text: String, action: String, onNavy: Boolean = false, onClick: () -> Unit) {
    Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(
            text, Modifier.weight(1f),
            style = MaterialTheme.typography.bodySmall,
            color = if (onNavy) Color(0xFFFFC2C4) else MaterialTheme.colorScheme.error,
        )
        TextButton(
            onClick = onClick,
            colors = if (onNavy) ButtonDefaults.textButtonColors(contentColor = Color.White) else ButtonDefaults.textButtonColors(),
        ) { Text(action) }
    }
}

fun openAppSettings(ctx: Context) {
    ctx.startActivity(
        Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))
    )
}

@SuppressLint("BatteryLife")
fun requestBatteryExemption(ctx: Context) {
    try {
        ctx.startActivity(
            Intent(
                android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                Uri.parse("package:${ctx.packageName}"),
            )
        )
    } catch (_: Exception) {
        ctx.startActivity(Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
    }
}

// ---------------------------------------------------------------- Sites

@SuppressLint("MissingPermission")
fun currentLocation(ctx: Context, cb: (Pair<Double, Double>?) -> Unit) {
    try {
        LocationServices.getFusedLocationProviderClient(ctx)
            .getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, CancellationTokenSource().token)
            .addOnSuccessListener { loc -> cb(loc?.let { it.latitude to it.longitude }) }
            .addOnFailureListener { cb(null) }
    } catch (_: SecurityException) {
        cb(null)
    }
}

@Composable
fun SitesScreen() {
    val ctx = LocalContext.current
    val db = remember { Db.get(ctx) }
    val version by Db.changes.collectAsState()
    val sites = remember(version) { db.sites() }
    var editing by remember { mutableStateOf<Site?>(null) }
    var newLoc by remember { mutableStateOf<NewPlace?>(null) }
    var addressOpen by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        item {
            Text(
                "You don't need to set up job sites in advance: new places show up on your timesheet as " +
                    "\"Unnamed stop\" and you name them there. Saved sites name future stops automatically. " +
                    "Add home, church, and other personal places, then turn on \"Ignore this place\" so they never count.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        item {
            Button(
                enabled = !busy,
                onClick = {
                    msg = null
                    if (!Perms.hasLocation(ctx)) {
                        msg = "Turn on tracking first so the app has location access."
                    } else {
                        busy = true
                        currentLocation(ctx) { loc ->
                            busy = false
                            if (loc == null) {
                                msg = "Couldn't get a location fix. Try again in a moment."
                            } else {
                                newLoc = NewPlace(loc.first, loc.second, "")
                            }
                        }
                    }
                },
            ) { Text(if (busy) "Getting location…" else "Add my current location") }
        }
        item {
            OutlinedButton(onClick = { addressOpen = true }) { Text("Add a place by address") }
        }
        msg?.let { m -> item { Text(m, color = MaterialTheme.colorScheme.error) } }
        if (sites.isEmpty()) {
            item { Text("No saved sites yet.", style = MaterialTheme.typography.bodyMedium) }
        }
        items(sites, key = { it.id }) { s ->
            Card(onClick = { editing = s }, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                    Text(s.name, style = MaterialTheme.typography.titleMedium)
                    Text(
                        if (s.ignored) {
                            "Ignored · ${s.radius.toInt()} m radius"
                        } else {
                            "${Categories.labelOf(s.category)} · " +
                                (if (s.morningTravel) "morning drive counts · " else "") + "${s.radius.toInt()} m radius"
                        },
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
            }
        }
    }

    editing?.let { s -> SiteDialog(s, s.lat, s.lng) { editing = null } }
    newLoc?.let { p -> SiteDialog(null, p.lat, p.lng, p.name) { newLoc = null } }
    if (addressOpen) {
        AddressDialog(onDismiss = { addressOpen = false }) { place ->
            addressOpen = false
            newLoc = place
        }
    }
}

@Composable
fun SiteDialog(site: Site?, lat: Double, lng: Double, initialName: String = "", onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val db = remember { Db.get(ctx) }
    var name by remember { mutableStateOf(site?.name ?: initialName) }
    var radius by remember { mutableStateOf((site?.radius?.toInt() ?: Prefs.radiusM(ctx)).toString()) }
    var ignored by remember { mutableStateOf(site?.ignored ?: false) }
    var category by remember { mutableStateOf(site?.category ?: Prefs.defaultCategory(ctx)) }
    var morningTravel by remember { mutableStateOf(site?.morningTravel ?: false) }
    var error by remember { mutableStateOf<String?>(null) }

    val confirm: () -> Unit = confirm@{
        val r = radius.trim().toDoubleOrNull()
        val n = name.trim().ifBlank { if (ignored) "Ignored place" else "" }
        if (n.isBlank()) {
            error = "Give the site a name."
            return@confirm
        }
        if (r == null || r < 30 || r > 3000) {
            error = "Radius should be between 30 and 3000 m."
            return@confirm
        }
        val id = if (site == null) {
            db.addSite(n, lat, lng, r, ignored, category, morningTravel && !ignored)
        } else {
            db.updateSite(
                site.copy(name = n, radius = r, ignored = ignored, category = category, morningTravel = morningTravel && !ignored),
            )
            site.id
        }
        db.site(id)?.let { db.assignUnnamedNear(it) }
        onDismiss()
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (site == null) "New site" else "Edit site") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = name, onValueChange = { name = it }, label = { Text("Name") },
                    singleLine = true, modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = radius, onValueChange = { radius = it }, label = { Text("Radius (metres)") },
                    singleLine = true, modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                )
                if (!ignored) {
                    CategoryPicker("Usual work type here", category) { category = it }
                    Text("When this is my first stop of the day", style = MaterialTheme.typography.labelMedium)
                    Column {
                        Row(
                            Modifier.fillMaxWidth().clickable { morningTravel = false },
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            androidx.compose.material3.RadioButton(selected = !morningTravel, onClick = { morningTravel = false })
                            Text("Work starts when I arrive (drive here not counted)", style = MaterialTheme.typography.bodyMedium)
                        }
                        Row(
                            Modifier.fillMaxWidth().clickable { morningTravel = true },
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            androidx.compose.material3.RadioButton(selected = morningTravel, onClick = { morningTravel = true })
                            Text("Count my morning drive here as travel", style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Ignore this place")
                        Text(
                            "For home and other non-work spots. Stops here won't be logged.",
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                    Switch(checked = ignored, onCheckedChange = { ignored = it })
                }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                if (site != null) {
                    TextButton(onClick = { db.deleteSite(site.id); onDismiss() }) {
                        Text("Delete site", color = MaterialTheme.colorScheme.error)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = confirm) { Text("Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

// ---------------------------------------------------------------- Settings

@Composable
fun SettingsScreen() {
    val ctx = LocalContext.current
    var minStay by remember { mutableIntStateOf(Prefs.minStayMin(ctx)) }
    var radius by remember { mutableIntStateOf(Prefs.radiusM(ctx)) }
    var interval by remember { mutableIntStateOf(Prefs.intervalMin(ctx)) }
    var highAcc by remember { mutableStateOf(Prefs.highAccuracy(ctx)) }
    var name by remember { mutableStateOf(Prefs.name(ctx)) }
    var defaultCat by remember { mutableStateOf(Prefs.defaultCategory(ctx)) }
    var sat by remember { mutableStateOf(Prefs.includeSaturday(ctx)) }
    var sun by remember { mutableStateOf(Prefs.includeSunday(ctx)) }
    var remindOn by remember { mutableStateOf(Prefs.reminderOn(ctx)) }
    var cutoffOn by remember { mutableStateOf(Prefs.cutoffOn(ctx)) }
    var askDrives by remember { mutableStateOf(Prefs.askDrives(ctx)) }
    var startRemind by remember { mutableStateOf(Prefs.startRemindOn(ctx)) }
    var hoursOn by remember { mutableStateOf(Prefs.hoursOn(ctx)) }
    val restart: () -> Unit = {
        if (Prefs.trackingEnabled(ctx)) {
            try {
                TrackingService.start(ctx)
            } catch (_: Exception) {
            }
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp),
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("Appearance", style = MaterialTheme.typography.titleSmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ThemeMode.values().forEach { m ->
                    FilterChip(
                        selected = ThemeState.mode == m,
                        onClick = { ThemeState.set(ctx, m) },
                        label = { Text(m.label) },
                    )
                }
            }
        }
        OutlinedTextField(
            value = name,
            onValueChange = {
                name = it
                if (it.isNotBlank()) Prefs.setName(ctx, it)
            },
            label = { Text("Your name (printed on timesheets)") },
            isError = name.isBlank(),
            supportingText = { if (name.isBlank()) Text("Name can't be empty") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        CategoryPicker("Default work type for new places", defaultCat) {
            defaultCat = it
            Prefs.setDefaultCategory(ctx, it)
        }
        Column {
            Text("Weekend days on printed/exported timesheets", style = MaterialTheme.typography.titleSmall)
            SwitchRow("Include Saturday", sat) { sat = it; Prefs.setBool(ctx, "incSat", it) }
            SwitchRow("Include Sunday", sun) { sun = it; Prefs.setBool(ctx, "incSun", it) }
            Text(
                "These are the defaults. You can still change them each time you print or export.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        HorizontalDivider()
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("Start of the workday", style = MaterialTheme.typography.titleSmall)
            SwitchRow("Weekday \"Start work\" reminder", startRemind) {
                startRemind = it
                Prefs.setBool(ctx, "startRemindOn", it)
            }
            if (startRemind) TimeSetting("Remind me at", Prefs.startRemindMin(ctx)) { Prefs.setInt(ctx, "startRemindMin", it) }
            Text(
                "Your drive to the office isn't counted. Your day starts when you arrive. If you're heading " +
                    "straight to a job, tap Start work before you leave and the drive counts as travel. You can " +
                    "also set a saved place to always count the morning drive there.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(8.dp))
            Text("End of the workday", style = MaterialTheme.typography.titleSmall)
            SwitchRow("Reminder notification", remindOn) { remindOn = it; Prefs.setBool(ctx, "remindOn", it) }
            if (remindOn) TimeSetting("Remind me at", Prefs.reminderMin(ctx)) { Prefs.setInt(ctx, "remindMin", it) }
            SwitchRow("Stop logging new places late in the day", cutoffOn) { cutoffOn = it; Prefs.setBool(ctx, "cutoffOn", it) }
            if (cutoffOn) TimeSetting("No new places after", Prefs.cutoffMin(ctx)) { Prefs.setInt(ctx, "cutoffMin", it) }
            SwitchRow("Ask to log drives (parts run / travel)", askDrives) {
                askDrives = it
                Prefs.setBool(ctx, "askDrives", it)
            }
            Text(
                "Tap \"Done for today\" on the reminder (or the Timesheet tab) when you leave your last job " +
                    "or the office. Your day ends there, and the drive home and anything after it isn't logged.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(8.dp))
            Text("Tracking hours", style = MaterialTheme.typography.titleSmall)
            SwitchRow("Turn off tracking outside work hours", hoursOn) {
                hoursOn = it
                Prefs.setBool(ctx, "hoursOn", it)
                Prefs.refreshPause(ctx)
                restart()
            }
            if (hoursOn) {
                TimeSetting("Start tracking at", Prefs.hoursStartMin(ctx)) {
                    Prefs.setInt(ctx, "hoursStart", it)
                    Prefs.refreshPause(ctx)
                    restart()
                }
                TimeSetting("Stop tracking after", Prefs.hoursEndMin(ctx)) { Prefs.setInt(ctx, "hoursEnd", it); restart() }
            }
            Text(
                "Outside these hours tracking switches off and its notification goes away once you're home, " +
                    "at another ignored place, or done for the day. If you're still at a job, it keeps going until " +
                    "you leave. It switches back on at the start time, or when you tap Start work or open the app.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        HorizontalDivider()
        ChoiceRow("Log a stop after staying", listOf(5, 10, 15, 20, 30), minStay, { "$it min" }) {
            minStay = it; Prefs.setInt(ctx, "minStay", it)
        }
        ChoiceRow("Same-place radius", listOf(75, 100, 150, 250, 400), radius, { "$it m" }) {
            radius = it; Prefs.setInt(ctx, "radius", it)
        }
        ChoiceRow("Check location every", listOf(1, 2, 3, 5), interval, { "$it min" }) {
            interval = it; Prefs.setInt(ctx, "interval", it); restart()
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("High-accuracy GPS", style = MaterialTheme.typography.titleSmall)
                Text("More precise arrive/leave times, uses more battery.", style = MaterialTheme.typography.bodySmall)
            }
            Switch(checked = highAcc, onCheckedChange = {
                highAcc = it; Prefs.setBool(ctx, "highAcc", it); restart()
            })
        }
        HorizontalDivider()
        OutlinedButton(onClick = { exportCsv(ctx, Db.get(ctx).allEntries(), "timesheet-all.csv") }) {
            Text("Export all entries (CSV)")
        }
        Text(
            "How it works: while tracking is on, the app checks your location every few minutes. " +
                "When you stay within the radius for the set time, it logs a stop from when you arrived " +
                "until you leave. Times can be off by about one check interval, so tap any entry to adjust it. " +
                "Everything stays on your phone.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
fun ChoiceRow(title: String, options: List<Int>, selected: Int, label: (Int) -> String, onSelect: (Int) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(title, style = MaterialTheme.typography.titleSmall)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            options.forEach { o ->
                FilterChip(selected = o == selected, onClick = { onSelect(o) }, label = { Text(label(o)) })
            }
        }
    }
}

/** A tighter switch row for dialogs, so everything fits without scrolling. */
@Composable
fun CompactSwitchRow(text: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().height(40.dp).clickable { onChange(!checked) },
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(text, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
        Switch(checked = checked, onCheckedChange = onChange, modifier = Modifier.scale(0.8f))
    }
}

@Composable
fun SwitchRow(text: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(text, Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

/** Choose which days to include, sign, then print/save PDF or share the filled-in Excel form. */
@Composable
fun ExportDialog(weekStart: LocalDate, onEdit: () -> Unit, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val name = Prefs.name(ctx)
    val fri = true // Friday is always on the timesheet
    var sat by remember { mutableStateOf(Prefs.includeSaturday(ctx)) }
    var sun by remember { mutableStateOf(Prefs.includeSunday(ctx)) }
    var withSig by remember { mutableStateOf(Prefs.includeSignature(ctx)) }
    var initial by remember { mutableStateOf(Prefs.initialToolbox(ctx)) }
    var sigVersion by remember { mutableIntStateOf(0) }
    var signing by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val version by Db.changes.collectAsState()
    val days = remember(version) { Timesheet.loadWeek(ctx, weekStart) }
    val unnamed = days.indices.filter { Timesheet.included(it, fri, sat, sun) }
        .sumOf { i -> days[i].rows.count { it.name == UNNAMED } }
    val missingBreaks = days.indices.count { i ->
        Timesheet.included(i, fri, sat, sun) && days[i].rows.isNotEmpty() && !days[i].hasBreak
    }
    val satHours = days[5].total
    val sunHours = days[6].total
    val sigBitmap = remember(sigVersion) {
        val f = Signature.file(ctx)
        if (f.exists()) BitmapFactory.decodeFile(f.path)?.asImageBitmap() else null
    }

    fun saveChoice() {
        Prefs.setBool(ctx, "incSat", sat)
        Prefs.setBool(ctx, "incSun", sun)
        Prefs.setBool(ctx, "incSig", withSig)
        Prefs.setBool(ctx, "initToolbox", initial)
    }

    fun export(kind: String) {
                saveChoice()
                // Rebuilt from the database at the moment you tap, so it always has your latest changes.
                val days = Timesheet.loadWeek(ctx, weekStart)
                try {
                    when (kind) {
                        "pdf" -> Timesheet.sharePdf(
                            ctx, Timesheet.writePdf(ctx, name, weekStart, days, fri, sat, sun, withSig, initial), name, weekStart,
                        )
                        "print" -> Timesheet.printPdf(
                            ctx, Timesheet.writePdf(ctx, name, weekStart, days, fri, sat, sun, withSig, initial),
                        )
                        else -> Timesheet.shareXlsx(
                            ctx, Timesheet.writeXlsx(ctx, name, weekStart, days, fri, sat, sun, withSig, initial), name, weekStart,
                        )
                    }
                    onDismiss()
                } catch (e: Exception) {
                    error = "Couldn't create the timesheet: ${e.message}"
                }
            }

    AlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier.fillMaxWidth(0.94f),
        properties = DialogProperties(usePlatformDefaultWidth = false),
        title = { Text("Timesheet", style = MaterialTheme.typography.titleMedium) },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(2.dp),
            ) {
                Text("$name · Week starting ${weekStart.format(WEEK_FMT)}", style = MaterialTheme.typography.bodySmall)
                CompactSwitchRow(
                    "Include Saturday" + if (satHours > 0) " (${fmtNum(satHours)} h)" else "",
                    sat,
                ) { sat = it }
                CompactSwitchRow(
                    "Include Sunday" + if (sunHours > 0) " (${fmtNum(sunHours)} h)" else "",
                    sun,
                ) { sun = it }
                val shownTotal = round1(days.indices.filter { Timesheet.included(it, fri, sat, sun) }.sumOf { days[it].total })
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Total: ${fmtNum(shownTotal)} h", Modifier.weight(1f), style = MaterialTheme.typography.titleSmall)
                    TextButton(onClick = onEdit) { Text("Review / edit") }
                }
                CompactSwitchRow("Initial the tool box talk (${Prefs.initials(name)})", initial) { initial = it }
                if (sigBitmap != null) {
                    CompactSwitchRow("Add my signature", withSig) { withSig = it }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.weight(1f).height(40.dp).background(Color.White),
                            contentAlignment = Alignment.Center,
                        ) {
                            Image(sigBitmap, contentDescription = "Your signature", modifier = Modifier.fillMaxHeight())
                        }
                        TextButton(onClick = { signing = true }) { Text("Sign again") }
                    }
                } else {
                    OutlinedButton(onClick = { signing = true }, modifier = Modifier.fillMaxWidth()) { Text("Sign timesheet") }
                }

                if (unnamed > 0) {
                    Text(
                        "$unnamed line${if (unnamed > 1) "s are" else " is"} still \"$UNNAMED\". Name them first if you can.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                    )
                }
                if (missingBreaks > 0) {
                    Text(
                        "$missingBreaks day${if (missingBreaks > 1) "s have" else " has"} no break entered.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                    )
                }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }

            }
        },
        confirmButton = {
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(onClick = { export("pdf") }, modifier = Modifier.fillMaxWidth()) { Text("Send as PDF") }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { export("xlsx") }, modifier = Modifier.weight(1f)) { Text("Send Excel") }
                    OutlinedButton(onClick = { export("print") }, modifier = Modifier.weight(1f)) { Text("Print PDF") }
                }
                TextButton(onClick = onDismiss, modifier = Modifier.align(Alignment.End)) { Text("Close") }
            }
        },
    )

    if (signing) {
        SignatureDialog(onDismiss = { signing = false }) {
            signing = false
            withSig = true
            sigVersion++
        }
    }
}

/** Set the break/lunch length for one day. */
@Composable
fun BreakDialog(date: LocalDate, current: Int, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var text by remember { mutableStateOf(if (current > 0) current.toString() else "") }
    var error by remember { mutableStateOf<String?>(null) }
    val save: (Int) -> Unit = { mins ->
        Db.get(ctx).setBreak(date, mins)
        onDismiss()
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Break on ${date.format(DAY_FMT)}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(0, 15, 30, 45, 48, 60).forEach { m ->
                        FilterChip(
                            selected = text == m.toString() || (m == 0 && text.isBlank()),
                            onClick = { text = if (m == 0) "" else m.toString() },
                            label = { Text(if (m == 0) "None" else "$m min") },
                        )
                    }
                }
                OutlinedTextField(
                    value = text, onValueChange = { text = it },
                    label = { Text("Minutes") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                )
                Text(
                    "Moved out of that day's site hours and into the BREAK column.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(onClick = confirm@{
                val m = if (text.isBlank()) 0 else text.trim().toIntOrNull()
                if (m == null || m < 0 || m > 600) {
                    error = "Enter minutes between 0 and 600."
                    return@confirm
                }
                save(m)
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

// ---------------------------------------------------------------- Time settings

fun fmtClockMin(m: Int): String {
    val h = m / 60
    val h12 = if (h % 12 == 0) 12 else h % 12
    return "$h12:${"%02d".format(m % 60)} ${if (h < 12) "AM" else "PM"}"
}

/** Accepts "4:30 PM", "4:30pm", "16:30", "5 pm". Returns minutes after midnight. */
fun parseClock(s: String): Int? {
    val m = Regex("""^\s*(\d{1,2})(?::(\d{2}))?\s*(?:([aApP])\.?\s*[mM]?\.?)?\s*$""").find(s) ?: return null
    var h = m.groupValues[1].toInt()
    val min = m.groupValues[2].ifEmpty { "0" }.toInt()
    val ap = m.groupValues[3].lowercase()
    if (min > 59) return null
    if (ap.isNotEmpty()) {
        if (h !in 1..12) return null
        if (ap == "p" && h != 12) h += 12
        if (ap == "a" && h == 12) h = 0
    } else if (h > 23) {
        return null
    }
    return h * 60 + min
}

@Composable
fun TimeSetting(title: String, initial: Int, onSave: (Int) -> Unit) {
    var text by remember { mutableStateOf(fmtClockMin(initial)) }
    val parsed = parseClock(text)
    OutlinedTextField(
        value = text,
        onValueChange = {
            text = it
            parseClock(it)?.let(onSave)
        },
        label = { Text(title) },
        singleLine = true,
        isError = parsed == null,
        supportingText = { Text(if (parsed == null) "Use a time like 4:30 PM" else "Set to ${fmtClockMin(parsed)}") },
        modifier = Modifier.fillMaxWidth(),
    )
}

// ---------------------------------------------------------------- Add place by address

data class NewPlace(val lat: Double, val lng: Double, val name: String)

@Suppress("DEPRECATION")
fun geocode(ctx: Context, query: String, cb: (Pair<Double, Double>?) -> Unit) {
    val main = Handler(Looper.getMainLooper())
    Thread {
        val result = try {
            if (!Geocoder.isPresent()) {
                null
            } else {
                Geocoder(ctx, Locale.getDefault()).getFromLocationName(query, 1)
                    ?.firstOrNull()?.let { it.latitude to it.longitude }
            }
        } catch (_: Exception) {
            null
        }
        main.post { cb(result) }
    }.start()
}

@Composable
fun AddressDialog(onDismiss: () -> Unit, onFound: (NewPlace) -> Unit) {
    val ctx = LocalContext.current
    var name by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add a place by address") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = name, onValueChange = { name = it }, label = { Text("Name (e.g. Home, Church)") },
                    singleLine = true, modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = address, onValueChange = { address = it },
                    label = { Text("Address, city, state") }, modifier = Modifier.fillMaxWidth(),
                )
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(enabled = !busy && address.isNotBlank(), onClick = {
                busy = true
                error = null
                geocode(ctx, address.trim()) { r ->
                    busy = false
                    if (r == null) {
                        error = "Couldn't find that address. Try adding the city and state."
                    } else {
                        onFound(NewPlace(r.first, r.second, name.trim()))
                    }
                }
            }) { Text(if (busy) "Searching…" else "Find") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

// ---------------------------------------------------------------- Timesheet editor

/**
 * Review and edit the week, day by day. Everything here edits your actual entries (the same ones
 * as the Timesheet tab), so changes show up everywhere and in every export. Changes save as you make them.
 */
@Composable
fun SheetEditorDialog(weekStart: LocalDate, initialDay: Int, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val db = remember { Db.get(ctx) }
    val version by Db.changes.collectAsState()
    val zone = ZoneId.systemDefault()
    val from = weekStart.atStartOfDay(zone).toInstant().toEpochMilli()
    val to = weekStart.plusDays(7).atStartOfDay(zone).toInstant().toEpochMilli()
    val entries = remember(version) { db.entriesBetween(from, to) }
    val drives = remember(version) { db.drivesBetween(from, to).filter { it.status != Drive.LOGGED } }
    val breaks = remember(version) { db.breaksBetween(weekStart, weekStart.plusDays(7)) }
    val notes = remember(version) { db.notesBetween(weekStart, weekStart.plusDays(7)) }
    val days = remember(version) {
        Timesheet.buildWeek(weekStart, entries, Prefs.defaultCategory(ctx), breaks, notes)
    }
    var dayIdx by remember { mutableIntStateOf(initialDay.coerceIn(0, 6)) }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(Modifier.fillMaxSize().safeDrawingPadding()) {
                Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "Review timesheet · week of ${weekStart.format(WEEK_FMT)}",
                        Modifier.weight(1f).padding(start = 8.dp),
                        style = MaterialTheme.typography.titleMedium,
                    )
                    IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, "Close") }
                }
                FlowRow(
                    Modifier.padding(horizontal = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    days.forEachIndexed { i, d ->
                        FilterChip(
                            selected = i == dayIdx,
                            onClick = { dayIdx = i },
                            label = { Text(Timesheet.DAY_NAMES[i] + if (d.total > 0) " ${fmtNum(d.total)}" else "") },
                        )
                    }
                }
                val date = weekStart.plusDays(dayIdx.toLong())
                key(dayIdx) {
                    DayEditor(
                        date = date,
                        sheet = days[dayIdx],
                        entries = entries.filter { it.start.toLocalDate() == date }.sortedBy { it.start },
                        drives = drives.filter { it.start.toLocalDate() == date },
                        breakMin = breaks[date] ?: 0,
                        note = notes[date] ?: "",
                    )
                }
            }
        }
    }
}

@Composable
fun DayEditor(
    date: LocalDate, sheet: SheetDay, entries: List<Entry>, drives: List<Drive>, breakMin: Int, note: String,
) {
    val ctx = LocalContext.current
    val db = remember { Db.get(ctx) }
    var adding by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Entry?>(null) }
    var noteText by remember { mutableStateOf(note) }
    var customBreak by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text(date.format(java.time.format.DateTimeFormatter.ofPattern("EEEE, MMMM d")), style = MaterialTheme.typography.titleLarge)

        // What this day will look like on the timesheet
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row {
                    Column(Modifier.weight(1f)) {
                        Text("Start", style = MaterialTheme.typography.labelMedium)
                        Text(sheet.start?.let { decimalToClock(it) } ?: "–", style = MaterialTheme.typography.titleMedium)
                    }
                    Column(Modifier.weight(1f)) {
                        Text("Stop", style = MaterialTheme.typography.labelMedium)
                        Text(sheet.stop?.let { decimalToClock(it) } ?: "–", style = MaterialTheme.typography.titleMedium)
                    }
                    Column(Modifier.weight(1f)) {
                        Text("Total", style = MaterialTheme.typography.labelMedium)
                        Text("${fmtNum(sheet.total)} h", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                    }
                }
                if (sheet.rows.isNotEmpty()) HorizontalDivider()
                sheet.rows.forEach { row ->
                    Text(
                        "${row.name}: " + row.hours.entries.joinToString(" · ") { (col, h) ->
                            "${Categories.of(col)?.name?.lowercase()?.replaceFirstChar { it.uppercase() } ?: col} ${fmtNum(h)}"
                        },
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
            }
        }

        Text("Entries", style = MaterialTheme.typography.titleSmall)
        if (entries.isEmpty()) {
            Text("Nothing on this day yet.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        entries.forEach { e -> EntryEditCard(e) { editing = e } }
        drives.forEach { d -> DriveRow(d) }
        OutlinedButton(onClick = { adding = true }) { Text("+ Add entry") }

        Text("Break / lunch", style = MaterialTheme.typography.titleSmall)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val presets = listOf(0, 15, 30, 45, 48, 60)
            presets.forEach { m ->
                FilterChip(
                    selected = breakMin == m,
                    onClick = { db.setBreak(date, m) },
                    label = { Text(if (m == 0) "None" else "$m min") },
                )
            }
            FilterChip(
                selected = breakMin !in presets,
                onClick = { customBreak = true },
                label = { Text(if (breakMin !in presets) "$breakMin min" else "Other…") },
            )
        }

        OutlinedTextField(
            value = noteText,
            onValueChange = {
                noteText = it
                db.setDayNote(date, it)
            },
            label = { Text("Notes for this day") },
            modifier = Modifier.fillMaxWidth(),
        )
        Text(
            "Changes save automatically and show up on the Timesheet tab and in every PDF and Excel you send.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }

    if (adding) EntryDialog(null, date) { adding = false }
    editing?.let { e -> EntryDialog(e, date) { editing = null } }
    if (customBreak) BreakDialog(date, breakMin) { customBreak = false }
}

/** One entry with its times on a normal 12-hour clock; picking a time saves it straight away. */
@Composable
fun EntryEditCard(e: Entry, onEdit: () -> Unit) {
    val ctx = LocalContext.current
    val db = remember { Db.get(ctx) }
    var error by remember(e) { mutableStateOf<String?>(null) }
    var splitting by remember { mutableStateOf(false) }
    val date = e.start.toLocalDate()
    val startT = e.start.toZoned().toLocalTime()
    val endT = e.end.toZoned().toLocalTime()

    Card(onClick = onEdit, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(e.label, Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                Text(fmtDur(e.end - e.start), style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PickerField("Start", fmt12(startT), Modifier.weight(1f)) {
                    pickTime(ctx, startT) { t ->
                        val ns = epochMs(date, t)
                        if (!e.ongoing && ns >= e.end) {
                            error = "Start has to be before the end time."
                        } else {
                            error = null
                            db.updateEntry(e.copy(start = ns))
                        }
                    }
                }
                PickerField("End", if (e.ongoing) "Still there" else fmt12(endT), Modifier.weight(1f)) {
                    pickTime(ctx, endT) { t ->
                        error = null
                        db.updateEntry(e.copy(end = endMs(date, startT, t), ongoing = false))
                    }
                }
            }
            CategoryPicker("Work type", e.category ?: Prefs.defaultCategory(ctx)) { db.updateEntry(e.copy(category = it)) }
            error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            FlowRow {
                TextButton(onClick = { splitting = true }) { Text("Split into tasks") }
                TextButton(onClick = onEdit) { Text("Edit details") }
            }
        }
    }
    if (splitting) SplitDialog(e) { splitting = false }
}

class TaskPart(cat: String, hours: String) {
    var cat by mutableStateOf(cat)
    var hours by mutableStateOf(hours)
}

/**
 * Split one stop into several tasks. All the time starts on the job's own work type; each task you
 * add takes its hours out of that (e.g. Install duct keeps the rest, Insulating 3 h, Piping 1.5 h).
 * Each task becomes its own entry back to back, all on the same job line of the timesheet.
 */
@Composable
fun SplitDialog(e: Entry, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val db = remember { Db.get(ctx) }
    val totalH = (e.end - e.start) / 3_600_000.0
    val jobCat = remember {
        e.category ?: e.siteId?.let { db.site(it)?.category } ?: Prefs.defaultCategory(ctx)
    }
    var main by remember { mutableStateOf(jobCat) }
    // A sensible first pick for the new task: anything other than the job's own work type.
    val otherCat = remember { Categories.all.first { it.col != jobCat && it.col != Categories.BREAK }.col }
    val extras = remember { mutableStateListOf(TaskPart(otherCat, "")) }
    var error by remember { mutableStateOf<String?>(null) }
    val given = extras.sumOf { it.hours.trim().toDoubleOrNull() ?: 0.0 }
    val remaining = totalH - given

    val save: () -> Unit = save@{
        if (e.ongoing) {
            error = "You're still at this stop. You can split it once you've left."
            return@save
        }
        val hrs = extras.map { it.hours.trim().toDoubleOrNull() }
        if (hrs.any { it == null || it <= 0.0 }) {
            error = "Enter how many hours you spent on each added task."
            return@save
        }
        if (remaining < 0.05) {
            error = "That's more than the ${fmtNum(totalH)} h you were there."
            return@save
        }
        val extraMs = hrs.map { Math.round(it!! * 3_600_000.0) }
        // The job's own work type first, then each added task, back to back, ending exactly when you left.
        var t = e.end - extraMs.sum()
        db.updateEntry(e.copy(category = main, end = t))
        extras.forEachIndexed { i, p ->
            val end = if (i == extras.lastIndex) e.end else t + extraMs[i]
            db.insertEntry(e.copy(id = 0, category = p.cat, start = t, end = end, note = ""))
            t = end
        }
        onDismiss()
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Split ${e.label}") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    "${fmt12(e.start)} – ${fmt12(e.end)} · ${fmtNum(totalH)} h. All of it starts on this job's work type. " +
                        "Add the other tasks you did and how long; the rest stays on the job's work type.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(Modifier.weight(1f)) { CategoryPicker("This job", main) { main = it } }
                    Text(
                        "${fmtNum(remaining.coerceAtLeast(0.0))} h",
                        Modifier.width(88.dp), style = MaterialTheme.typography.titleMedium,
                        color = if (remaining < 0.05) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                    )
                }
                extras.forEachIndexed { i, p ->
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Box(Modifier.weight(1f)) { CategoryPicker(if (i == 0) "Also did" else "", p.cat) { p.cat = it } }
                        OutlinedTextField(
                            value = p.hours, onValueChange = { p.hours = it }, label = { Text("Hours") },
                            singleLine = true, modifier = Modifier.width(88.dp),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        )
                        if (extras.size > 1) {
                            IconButton(onClick = { extras.removeAt(i) }) { Icon(Icons.Default.Close, "Remove task") }
                        }
                    }
                }
                TextButton(onClick = { extras.add(TaskPart(otherCat, "")) }) { Text("+ Add another task") }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = { TextButton(onClick = save) { Text("Split") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

// ---------------------------------------------------------------- Signature

private val INK = Color(0xFF0F1950)

@Composable
fun SignatureDialog(onDismiss: () -> Unit, onSaved: () -> Unit) {
    val ctx = LocalContext.current
    val density = LocalDensity.current
    val strokes = remember { mutableStateListOf<List<Offset>>() }
    var current by remember { mutableStateOf<List<Offset>>(emptyList()) }
    var error by remember { mutableStateOf<String?>(null) }

    // Turn the phone sideways while signing, for a wide signature; put it back afterwards.
    val activity = ctx as? android.app.Activity
    androidx.compose.runtime.DisposableEffect(Unit) {
        val before = activity?.requestedOrientation
        activity?.requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        onDispose {
            activity?.requestedOrientation = before ?: android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 8.dp), shape = MaterialTheme.shapes.large) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Sign with your finger", style = MaterialTheme.typography.titleMedium)
                Box(
                    Modifier.fillMaxWidth().height(170.dp).background(Color.White).border(1.dp, Color.Gray),
                ) {
                    Canvas(
                        Modifier.fillMaxSize().pointerInput(Unit) {
                            detectDragGestures(
                                onDragStart = { current = listOf(it) },
                                onDragEnd = {
                                    if (current.size > 1) strokes.add(current)
                                    current = emptyList()
                                },
                                onDragCancel = { current = emptyList() },
                            ) { change, _ ->
                                change.consume()
                                current = current + change.position
                            }
                        },
                    ) {
                        drawLine(
                            Color.LightGray, Offset(24f, size.height * 0.75f),
                            Offset(size.width - 24f, size.height * 0.75f), strokeWidth = 2f,
                        )
                        val w = 3.dp.toPx()
                        (strokes + listOf(current)).forEach { pts ->
                            if (pts.size > 1) {
                                val path = Path().apply {
                                    moveTo(pts[0].x, pts[0].y)
                                    pts.drop(1).forEach { lineTo(it.x, it.y) }
                                }
                                drawPath(path, INK, style = Stroke(width = w, cap = StrokeCap.Round, join = StrokeJoin.Round))
                            }
                        }
                    }
                }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { strokes.clear() }) { Text("Clear") }
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    Button(onClick = {
                        if (strokes.isEmpty()) {
                            error = "Sign in the white box first."
                        } else {
                            saveSignature(ctx, strokes.toList(), with(density) { 3.dp.toPx() })
                            onSaved()
                        }
                    }) { Text("Use signature") }
                }
            }
        }
    }
}

/** Crops the strokes to their bounds and saves a transparent PNG for the timesheet. */
fun saveSignature(ctx: Context, strokes: List<List<Offset>>, strokePx: Float) {
    val all = strokes.flatten()
    val pad = strokePx * 2
    val minX = all.minOf { it.x } - pad
    val minY = all.minOf { it.y } - pad
    val w = (all.maxOf { it.x } + pad - minX).toInt().coerceAtLeast(1)
    val h = (all.maxOf { it.y } + pad - minY).toInt().coerceAtLeast(1)
    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val canvas = android.graphics.Canvas(bmp)
    val paint = android.graphics.Paint().apply {
        color = android.graphics.Color.rgb(15, 25, 80)
        strokeWidth = strokePx
        style = android.graphics.Paint.Style.STROKE
        strokeCap = android.graphics.Paint.Cap.ROUND
        strokeJoin = android.graphics.Paint.Join.ROUND
        isAntiAlias = true
    }
    strokes.forEach { pts ->
        val path = android.graphics.Path()
        path.moveTo(pts[0].x - minX, pts[0].y - minY)
        pts.drop(1).forEach { path.lineTo(it.x - minX, it.y - minY) }
        canvas.drawPath(path, paint)
    }
    Signature.file(ctx).outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
}
