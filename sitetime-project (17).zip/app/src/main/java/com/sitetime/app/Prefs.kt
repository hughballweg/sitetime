package com.sitetime.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import androidx.core.content.edit

object Prefs {
    private fun p(c: Context) = c.getSharedPreferences("settings", Context.MODE_PRIVATE)

    /** Location history: the tracking service runs and saves your location during tracking hours. */
    fun trackingEnabled(c: Context) = p(c).getBoolean("tracking", false)
    fun setTrackingEnabled(c: Context, v: Boolean) = p(c).edit { putBoolean("tracking", v) }

    /** "Track day": stops and drives are turned into timesheet entries. Off = location is only saved. */
    fun logOn(c: Context) = p(c).getBoolean("logOn", trackingEnabled(c))
    fun setLogOn(c: Context, v: Boolean) = p(c).edit { putBoolean("logOn", v) }

    /**
     * One-time setup for the location-history update: history is saved every day 4:00 AM – 8:00 PM,
     * and the old tracking switch becomes "Track day".
     */
    fun migrate(c: Context) {
        val sp = p(c)
        if (sp.getBoolean("mig9", false)) return
        sp.edit {
            putBoolean("logOn", sp.getBoolean("tracking", false))
            putBoolean("tracking", true)
            putBoolean("hoursOn", true)
            putInt("hoursStart", 4 * 60)
            putInt("hoursEnd", 20 * 60)
            putBoolean("mig9", true)
        }
    }

    /** Minutes you must stay in one place before it is logged. */
    fun minStayMin(c: Context) = p(c).getInt("minStay", 10)

    /** How far (metres) you can wander and still count as "the same place". */
    fun radiusM(c: Context) = p(c).getInt("radius", 150)

    /** How often to check location, in minutes. */
    fun intervalMin(c: Context) = p(c).getInt("interval", 2)

    fun highAccuracy(c: Context) = p(c).getBoolean("highAcc", false)

    /** Name printed on timesheets. Blank until the first-run prompt is answered. */
    fun name(c: Context) = p(c).getString("name", "") ?: ""
    fun setName(c: Context, v: String) = p(c).edit { putString("name", v.trim()) }

    /** Work type given to new stops at places that aren't saved sites. */
    fun defaultCategory(c: Context) = p(c).getString("defaultCat", "O") ?: "O"
    fun setDefaultCategory(c: Context, v: String) = p(c).edit { putString("defaultCat", v) }

    fun includeFriday(c: Context) = p(c).getBoolean("incFri", false)
    // Saturday and Sunday are chosen separately (the old combined weekend setting is the starting value).
    fun includeSaturday(c: Context) = p(c).getBoolean("incSat", p(c).getBoolean("incWknd", false))
    fun includeSunday(c: Context) = p(c).getBoolean("incSun", p(c).getBoolean("incWknd", false))

    /** End-of-day reminder (minutes after midnight). Default 4:30 PM. */
    fun reminderOn(c: Context) = p(c).getBoolean("remindOn", true)
    fun reminderMin(c: Context) = p(c).getInt("remindMin", 16 * 60 + 30)
    fun lastReminderDay(c: Context) = p(c).getString("remindDay", "") ?: ""
    fun setLastReminderDay(c: Context, v: String) = p(c).edit { putString("remindDay", v) }

    /** No new places are logged after this time of day. Default 5:30 PM. */
    fun cutoffOn(c: Context) = p(c).getBoolean("cutoffOn", true)
    fun cutoffMin(c: Context) = p(c).getInt("cutoffMin", 17 * 60 + 30)

    /** Set by "Done for today": nothing is logged until this time (next morning). */
    fun pausedUntil(c: Context) = p(c).getLong("pausedUntil", 0L)
    fun setPausedUntil(c: Context, v: Long) = p(c).edit { putLong("pausedUntil", v) }

    /** Ask after each drive between work places whether to log it as a parts run or travel. */
    fun askDrives(c: Context) = p(c).getBoolean("askDrives", true)

    // ---- Workday start ----
    /** Weekday reminder with a "Start work" button (minutes after midnight). Default 6:00 AM. */
    fun startRemindOn(c: Context) = p(c).getBoolean("startRemindOn", true)
    fun startRemindMin(c: Context) = p(c).getInt("startRemindMin", 6 * 60)
    fun lastStartRemindDay(c: Context) = p(c).getString("startRemindDay", "") ?: ""
    fun setLastStartRemindDay(c: Context, v: String) = p(c).edit { putString("startRemindDay", v) }

    /** The day the workday was started, when, and whether you started it yourself with "Start work". */
    fun workDay(c: Context) = p(c).getString("workDay", "") ?: ""
    fun workStartMs(c: Context) = p(c).getLong("workStartMs", 0L)
    fun workStartManual(c: Context) = p(c).getBoolean("workStartManual", false)
    fun setWorkStart(c: Context, day: String, ms: Long, manual: Boolean) = p(c).edit {
        putString("workDay", day)
        putLong("workStartMs", ms)
        putBoolean("workStartManual", manual)
    }

    /** The day you first arrived at a work place (not home/church/etc.). */
    fun arrivedDay(c: Context) = p(c).getString("arrivedDay", "") ?: ""
    fun setArrivedDay(c: Context, v: String) = p(c).edit { putString("arrivedDay", v) }

    /** Map tab: satellite with labels (true) or the regular street map. */
    fun mapSatellite(c: Context) = p(c).getBoolean("mapSatellite", true)
    fun setMapSatellite(c: Context, v: Boolean) = p(c).edit { putBoolean("mapSatellite", v) }

    // ---- Tracking hours ----
    /** Outside these hours tracking shuts off (no notification) unless you're at a job. Default 4:00 AM – 8:00 PM. */
    fun hoursOn(c: Context) = p(c).getBoolean("hoursOn", true)
    fun hoursStartMin(c: Context) = p(c).getInt("hoursStart", 4 * 60)
    fun hoursEndMin(c: Context) = p(c).getInt("hoursEnd", 20 * 60)
    fun inTrackingHours(c: Context, ms: Long): Boolean {
        val z = ms.toZoned()
        val m = z.hour * 60 + z.minute
        return m >= hoursStartMin(c) && m < hoursEndMin(c)
    }

    /** Time of day tracking starts again after "Done for today". */
    fun resumeMin(c: Context) = if (hoursOn(c)) hoursStartMin(c) else DAY_START_MIN

    /** After the start time changes in Settings, move an active "Done for today" to the new time. */
    fun refreshPause(c: Context) {
        val now = System.currentTimeMillis()
        if (pausedUntil(c) > now) setPausedUntil(c, nextMorning(c, now))
    }

    /** True while tracking is shut off for the night and waiting for the morning alarm. */
    fun resting(c: Context) = p(c).getBoolean("resting", false)
    fun setResting(c: Context, v: Boolean) = p(c).edit { putBoolean("resting", v) }

    /** Day lists: newest stop at the top (default) or earliest at the top. */
    fun newestFirst(c: Context) = p(c).getBoolean("newestFirst", true)

    fun themeMode(c: Context) = p(c).getString("theme", "LIGHT") ?: "LIGHT"
    fun setThemeMode(c: Context, v: String) = p(c).edit { putString("theme", v) }

    /** Put your initials on the weekly tool box talk line. */
    fun initialToolbox(c: Context) = p(c).getBoolean("initToolbox", false)

    /** "Hugh Ballweg" -> "HB" (first letter of each word, up to three). */
    fun initials(name: String) =
        name.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }.take(3).joinToString("") { it.first().uppercase() }

    fun includeSignature(c: Context) = p(c).getBoolean("incSig", true)

    fun setInt(c: Context, key: String, v: Int) = p(c).edit { putInt(key, v) }
    fun setBool(c: Context, key: String, v: Boolean) = p(c).edit { putBoolean(key, v) }
}

object Perms {
    private fun granted(c: Context, p: String) =
        ContextCompat.checkSelfPermission(c, p) == PackageManager.PERMISSION_GRANTED

    fun hasLocation(c: Context) =
        granted(c, Manifest.permission.ACCESS_FINE_LOCATION) ||
            granted(c, Manifest.permission.ACCESS_COARSE_LOCATION)

    fun hasBackground(c: Context) =
        Build.VERSION.SDK_INT < 29 || granted(c, Manifest.permission.ACCESS_BACKGROUND_LOCATION)

    fun foregroundRequest(): Array<String> {
        val list = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
        )
        if (Build.VERSION.SDK_INT >= 33) list.add(Manifest.permission.POST_NOTIFICATIONS)
        return list.toTypedArray()
    }
}
