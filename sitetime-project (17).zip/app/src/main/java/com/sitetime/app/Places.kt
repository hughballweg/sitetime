package com.sitetime.app

import android.content.Context
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate
import java.time.ZoneId

/**
 * Names unnamed stops after the business you stopped at (e.g. a hardware store), using Google's
 * Places API (New) Nearby Search with the same key as the map. Each stop is checked once; a stop
 * you've named yourself is never changed. Needs "Places API (New)" enabled for the key.
 */
object Places {
    /** SHA-1 of app/debug.keystore, sent so the Android-restricted key is accepted. */
    private const val CERT_SHA1 = "BE881E0F594628C268468A4BD65F5F4FE76877C8"
    private const val RADIUS_M = 50.0
    private const val MAX_PER_RUN = 25
    private val lock = Any()

    /** Results that are just roads, addresses or areas, not a business. */
    private val NOT_A_BUSINESS = setOf(
        "route", "street_address", "premise", "subpremise", "locality", "sublocality", "political",
        "neighborhood", "postal_code", "plus_code", "geocode", "intersection", "country",
        "administrative_area_level_1", "administrative_area_level_2", "administrative_area_level_3",
        "parking", "parking_lot",
    )

    /** Checks unnamed stops between [from] and [to]. Call off the main thread (it uses the network). */
    fun nameUnnamed(ctx: Context, from: Long, to: Long) {
        if (BuildConfig.MAPS_API_KEY.isBlank()) return
        synchronized(lock) {
            val db = Db.get(ctx)
            for (e in db.unnamedToLookUp(from, to).take(MAX_PER_RUN)) {
                val lat = e.lat ?: continue
                val lng = e.lng ?: continue
                val name = try {
                    nearestBusiness(ctx, lat, lng)
                } catch (ex: Exception) {
                    // No signal, or the Places API isn't switched on yet: try again next time.
                    return
                }
                db.setLookedUp(e.id, name)
            }
        }
    }

    fun nameUnnamedDay(ctx: Context, day: LocalDate) {
        val zone = ZoneId.systemDefault()
        nameUnnamed(
            ctx,
            day.atStartOfDay(zone).toInstant().toEpochMilli(),
            day.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli(),
        )
    }

    /** The closest business within [RADIUS_M] of the spot, or null if there isn't one. */
    private fun nearestBusiness(ctx: Context, lat: Double, lng: Double): String? {
        val body = JSONObject()
            .put("maxResultCount", 5)
            .put("rankPreference", "DISTANCE")
            .put(
                "locationRestriction",
                JSONObject().put(
                    "circle",
                    JSONObject()
                        .put("center", JSONObject().put("latitude", lat).put("longitude", lng))
                        .put("radius", RADIUS_M),
                ),
            )
        val conn = URL("https://places.googleapis.com/v1/places:searchNearby").openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 10_000
            conn.readTimeout = 10_000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("X-Goog-Api-Key", BuildConfig.MAPS_API_KEY)
            conn.setRequestProperty("X-Goog-FieldMask", "places.displayName,places.types")
            conn.setRequestProperty("X-Android-Package", ctx.packageName)
            conn.setRequestProperty("X-Android-Cert", CERT_SHA1)
            conn.outputStream.use { it.write(body.toString().toByteArray()) }
            if (conn.responseCode != 200) throw IOException("Places API answered ${conn.responseCode}")
            val json = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
            val places = json.optJSONArray("places") ?: return null
            for (i in 0 until places.length()) {
                val place = places.getJSONObject(i)
                val typesJson = place.optJSONArray("types")
                val types = if (typesJson == null) emptyList() else (0 until typesJson.length()).map { typesJson.getString(it) }
                if (types.isNotEmpty() && types.all { it in NOT_A_BUSINESS }) continue
                val name = place.optJSONObject("displayName")?.optString("text").orEmpty().trim()
                if (name.isNotBlank()) return name
            }
            return null
        } finally {
            conn.disconnect()
        }
    }
}
