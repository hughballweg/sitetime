package com.sitetime.app

import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import androidx.core.content.contentValuesOf
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update

class Db private constructor(ctx: Context) : SQLiteOpenHelper(ctx, "sitetime.db", null, 5) {

    companion object {
        @Volatile
        private var instance: Db? = null

        fun get(ctx: Context): Db =
            instance ?: synchronized(this) {
                instance ?: Db(ctx.applicationContext).also { instance = it }
            }

        /** Bumped on every write so the UI knows to reload. */
        val changes = MutableStateFlow(0)

        private const val ECOLS = "id, site_id, label, lat, lng, start_ms, end_ms, ongoing, note, category, break_min"
        private const val BREAKS_TABLE =
            "CREATE TABLE IF NOT EXISTS day_breaks (day TEXT PRIMARY KEY, minutes INTEGER NOT NULL)"
        private const val SHEETS_TABLE =
            "CREATE TABLE IF NOT EXISTS day_sheets (day TEXT PRIMARY KEY, json TEXT NOT NULL)"
        private const val DRIVES_TABLE =
            "CREATE TABLE IF NOT EXISTS drives (id INTEGER PRIMARY KEY AUTOINCREMENT, start_ms INTEGER NOT NULL, " +
                "end_ms INTEGER NOT NULL, from_label TEXT NOT NULL, to_label TEXT NOT NULL, " +
                "status INTEGER NOT NULL DEFAULT 0, entry_id INTEGER)"
        private const val NOTES_TABLE =
            "CREATE TABLE IF NOT EXISTS day_notes (day TEXT PRIMARY KEY, note TEXT NOT NULL)"
        private const val SCOLS = "id, name, lat, lng, radius, ignored, category"
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE sites (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, " +
                "lat REAL NOT NULL, lng REAL NOT NULL, radius REAL NOT NULL, ignored INTEGER NOT NULL DEFAULT 0, category TEXT)"
        )
        db.execSQL(
            "CREATE TABLE entries (id INTEGER PRIMARY KEY AUTOINCREMENT, site_id INTEGER, label TEXT NOT NULL, " +
                "lat REAL, lng REAL, start_ms INTEGER NOT NULL, end_ms INTEGER NOT NULL, " +
                "ongoing INTEGER NOT NULL DEFAULT 0, note TEXT NOT NULL DEFAULT '', " +
                "category TEXT, break_min INTEGER NOT NULL DEFAULT 0)"
        )
        db.execSQL("CREATE INDEX entries_start ON entries(start_ms)")
        db.execSQL(BREAKS_TABLE)
        db.execSQL(SHEETS_TABLE)
        db.execSQL(DRIVES_TABLE)
        db.execSQL(NOTES_TABLE)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE sites ADD COLUMN category TEXT")
            db.execSQL("ALTER TABLE entries ADD COLUMN category TEXT")
            db.execSQL("ALTER TABLE entries ADD COLUMN break_min INTEGER NOT NULL DEFAULT 0")
        }
        if (oldVersion < 3) db.execSQL(BREAKS_TABLE)
        if (oldVersion < 4) db.execSQL(SHEETS_TABLE)
        if (oldVersion < 5) {
            db.execSQL(DRIVES_TABLE)
            db.execSQL(NOTES_TABLE)
            // Hand-edited sheet copies froze a day and hid later changes; the sheet is now built
            // from your entries every time, so retire those copies.
            db.execSQL("DELETE FROM day_sheets")
        }
    }

    private fun bump() = changes.update { it + 1 }

    /** Lets screens refresh after changes that aren't database writes (e.g. pausing). */
    fun touch() = bump()

    // ---------- Drives ----------

    private fun Cursor.toDrive() = Drive(
        id = getLong(0), start = getLong(1), end = getLong(2), from = getString(3), to = getString(4),
        status = getInt(5), entryId = if (isNull(6)) null else getLong(6),
    )

    fun addDrive(start: Long, end: Long, from: String, to: String): Long =
        writableDatabase.insert(
            "drives", null,
            contentValuesOf("start_ms" to start, "end_ms" to end, "from_label" to from, "to_label" to to, "status" to Drive.PENDING),
        ).also { bump() }

    fun drive(id: Long): Drive? =
        readableDatabase.rawQuery(
            "SELECT id, start_ms, end_ms, from_label, to_label, status, entry_id FROM drives WHERE id = ?",
            arrayOf(id.toString()),
        ).use { c -> if (c.moveToFirst()) c.toDrive() else null }

    fun drivesBetween(from: Long, to: Long): List<Drive> =
        readableDatabase.rawQuery(
            "SELECT id, start_ms, end_ms, from_label, to_label, status, entry_id FROM drives " +
                "WHERE start_ms >= ? AND start_ms < ? ORDER BY start_ms",
            arrayOf(from.toString(), to.toString()),
        ).use { c -> buildList { while (c.moveToNext()) add(c.toDrive()) } }

    fun setDriveStatus(id: Long, status: Int, entryId: Long?) {
        writableDatabase.update(
            "drives", contentValuesOf("status" to status, "entry_id" to entryId),
            "id = ?", arrayOf(id.toString()),
        )
        bump()
    }

    // ---------- Day notes ----------

    fun notesBetween(from: java.time.LocalDate, to: java.time.LocalDate): Map<java.time.LocalDate, String> =
        readableDatabase.rawQuery(
            "SELECT day, note FROM day_notes WHERE day >= ? AND day < ?",
            arrayOf(from.toString(), to.toString()),
        ).use { c ->
            buildMap { while (c.moveToNext()) put(java.time.LocalDate.parse(c.getString(0)), c.getString(1)) }
        }

    fun setDayNote(day: java.time.LocalDate, note: String) {
        if (note.isBlank()) {
            writableDatabase.delete("day_notes", "day = ?", arrayOf(day.toString()))
        } else {
            writableDatabase.insertWithOnConflict(
                "day_notes", null, contentValuesOf("day" to day.toString(), "note" to note),
                SQLiteDatabase.CONFLICT_REPLACE,
            )
        }
        bump()
    }

    // ---------- Hand-edited timesheet days (no longer used; kept so old databases open) ----------

    fun sheetsBetween(from: java.time.LocalDate, to: java.time.LocalDate): Map<java.time.LocalDate, String> =
        readableDatabase.rawQuery(
            "SELECT day, json FROM day_sheets WHERE day >= ? AND day < ?",
            arrayOf(from.toString(), to.toString()),
        ).use { c ->
            buildMap { while (c.moveToNext()) put(java.time.LocalDate.parse(c.getString(0)), c.getString(1)) }
        }

    /** Save a hand-edited day, or pass null to go back to the tracked data. */
    fun setSheet(day: java.time.LocalDate, json: String?) {
        if (json == null) {
            writableDatabase.delete("day_sheets", "day = ?", arrayOf(day.toString()))
        } else {
            writableDatabase.insertWithOnConflict(
                "day_sheets", null, contentValuesOf("day" to day.toString(), "json" to json),
                SQLiteDatabase.CONFLICT_REPLACE,
            )
        }
        bump()
    }

    // ---------- Sites ----------

    private fun Cursor.toSite() = Site(
        id = getLong(0), name = getString(1), lat = getDouble(2), lng = getDouble(3),
        radius = getDouble(4), ignored = getInt(5) != 0,
        category = if (isNull(6)) null else getString(6),
    )

    fun sites(): List<Site> =
        readableDatabase.rawQuery("SELECT $SCOLS FROM sites ORDER BY ignored, name COLLATE NOCASE", null)
            .use { c -> buildList { while (c.moveToNext()) add(c.toSite()) } }

    fun site(id: Long): Site? =
        readableDatabase.rawQuery("SELECT $SCOLS FROM sites WHERE id = ?", arrayOf(id.toString()))
            .use { c -> if (c.moveToFirst()) c.toSite() else null }

    fun addSite(
        name: String, lat: Double, lng: Double, radius: Double, ignored: Boolean, category: String? = null,
    ): Long =
        writableDatabase.insert(
            "sites", null,
            contentValuesOf(
                "name" to name, "lat" to lat, "lng" to lng,
                "radius" to radius, "ignored" to if (ignored) 1 else 0, "category" to category,
            ),
        ).also { bump() }

    fun updateSite(s: Site) {
        val db = writableDatabase
        db.update(
            "sites",
            contentValuesOf(
                "name" to s.name, "radius" to s.radius, "ignored" to if (s.ignored) 1 else 0, "category" to s.category,
            ),
            "id = ?", arrayOf(s.id.toString()),
        )
        db.update("entries", contentValuesOf("label" to s.name), "site_id = ?", arrayOf(s.id.toString()))
        bump()
    }

    fun deleteSite(id: Long) {
        val db = writableDatabase
        db.delete("sites", "id = ?", arrayOf(id.toString()))
        db.update("entries", contentValuesOf("site_id" to null), "site_id = ?", arrayOf(id.toString()))
        bump()
    }

    /** The closest saved site whose radius contains this point, if any. */
    fun findSiteFor(lat: Double, lng: Double): Site? =
        sites()
            .map { it to distanceM(lat, lng, it.lat, it.lng) }
            .filter { (s, d) -> d <= s.radius }
            .minByOrNull { it.second }
            ?.first

    /** Names (or, for ignored places, removes) unnamed stops that fall inside this site. */
    fun assignUnnamedNear(site: Site) {
        val db = writableDatabase
        val unnamed = db.rawQuery(
            "SELECT $ECOLS FROM entries WHERE site_id IS NULL AND lat IS NOT NULL AND label = ?",
            arrayOf(UNNAMED),
        ).use { c -> buildList { while (c.moveToNext()) add(c.toEntry()) } }
        for (e in unnamed) {
            val lat = e.lat ?: continue
            val lng = e.lng ?: continue
            if (distanceM(site.lat, site.lng, lat, lng) > site.radius) continue
            if (site.ignored) {
                db.delete("entries", "id = ?", arrayOf(e.id.toString()))
            } else {
                val values = contentValuesOf("site_id" to site.id, "label" to site.name)
                if (site.category != null) values.put("category", site.category)
                db.update("entries", values, "id = ?", arrayOf(e.id.toString()))
            }
        }
        bump()
    }

    // ---------- Daily breaks ----------

    /** Break minutes per day, for days from [from] up to (not including) [to]. */
    fun breaksBetween(from: java.time.LocalDate, to: java.time.LocalDate): Map<java.time.LocalDate, Int> =
        readableDatabase.rawQuery(
            "SELECT day, minutes FROM day_breaks WHERE day >= ? AND day < ?",
            arrayOf(from.toString(), to.toString()),
        ).use { c ->
            buildMap { while (c.moveToNext()) put(java.time.LocalDate.parse(c.getString(0)), c.getInt(1)) }
        }

    fun setBreak(day: java.time.LocalDate, minutes: Int) {
        if (minutes <= 0) {
            writableDatabase.delete("day_breaks", "day = ?", arrayOf(day.toString()))
        } else {
            writableDatabase.insertWithOnConflict(
                "day_breaks", null, contentValuesOf("day" to day.toString(), "minutes" to minutes),
                SQLiteDatabase.CONFLICT_REPLACE,
            )
        }
        bump()
    }

    // ---------- Entries ----------

    private fun Cursor.toEntry() = Entry(
        id = getLong(0),
        siteId = if (isNull(1)) null else getLong(1),
        label = getString(2),
        lat = if (isNull(3)) null else getDouble(3),
        lng = if (isNull(4)) null else getDouble(4),
        start = getLong(5),
        end = getLong(6),
        ongoing = getInt(7) != 0,
        note = getString(8),
        category = if (isNull(9)) null else getString(9),
        breakMin = getInt(10),
    )

    private fun Entry.values() = contentValuesOf(
        "site_id" to siteId, "label" to label, "lat" to lat, "lng" to lng,
        "start_ms" to start, "end_ms" to end, "ongoing" to if (ongoing) 1 else 0, "note" to note,
        "category" to category, "break_min" to breakMin,
    )

    /** Entries that start within [from, to). */
    fun entriesBetween(from: Long, to: Long): List<Entry> =
        readableDatabase.rawQuery(
            "SELECT $ECOLS FROM entries WHERE start_ms >= ? AND start_ms < ? ORDER BY start_ms",
            arrayOf(from.toString(), to.toString()),
        ).use { c -> buildList { while (c.moveToNext()) add(c.toEntry()) } }

    fun allEntries(): List<Entry> =
        readableDatabase.rawQuery("SELECT $ECOLS FROM entries ORDER BY start_ms", null)
            .use { c -> buildList { while (c.moveToNext()) add(c.toEntry()) } }

    fun entry(id: Long): Entry? =
        readableDatabase.rawQuery("SELECT $ECOLS FROM entries WHERE id = ?", arrayOf(id.toString()))
            .use { c -> if (c.moveToFirst()) c.toEntry() else null }

    fun insertEntry(e: Entry): Long =
        writableDatabase.insert("entries", null, e.values()).also { bump() }

    fun updateEntry(e: Entry) {
        writableDatabase.update("entries", e.values(), "id = ?", arrayOf(e.id.toString()))
        bump()
    }

    fun deleteEntry(id: Long) {
        val db = writableDatabase
        db.delete("entries", "id = ?", arrayOf(id.toString()))
        // A logged drive whose entry was deleted goes back to "not logged".
        db.update(
            "drives", contentValuesOf("status" to Drive.SKIPPED, "entry_id" to null),
            "entry_id = ?", arrayOf(id.toString()),
        )
        bump()
    }

    fun setEntryEnd(id: Long, end: Long, ongoing: Boolean) {
        writableDatabase.update(
            "entries", contentValuesOf("end_ms" to end, "ongoing" to if (ongoing) 1 else 0),
            "id = ?", arrayOf(id.toString()),
        )
        bump()
    }

    /** Marks any "ongoing" stop as finished, except the one currently being tracked. */
    fun closeStaleOngoing(exceptId: Long) {
        writableDatabase.update(
            "entries", contentValuesOf("ongoing" to 0),
            "ongoing = 1 AND id != ?", arrayOf(exceptId.toString()),
        )
        bump()
    }
}
