package com.sitetime.app

import android.content.Context
import android.content.Intent
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.content.FileProvider
import java.io.ByteArrayOutputStream
import java.io.File
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import kotlin.math.ceil
import kotlin.math.roundToLong

/** One line on a day: a site and its hours per work-type column. */
class SheetRow(val name: String) {
    val hours = linkedMapOf<String, Double>()
    val total get() = round1(hours.values.sum())
}

class SheetDay(val date: LocalDate, val rows: List<SheetRow>, val start: Double?, val stop: Double?, val notes: String) {
    val total get() = round1(rows.sumOf { it.total })
}

fun round1(x: Double): Double = (x * 10).roundToLong() / 10.0

/**
 * Clock time as the form wants it: hour in 24h plus tenths, where
 * :01-:06 = .1, :07-:12 = .2 ... :49-:54 = .9 and :55-:59 rolls to the next hour.
 */
fun decimalTime(ms: Long, dayStart: LocalDate): Double {
    val z = ms.toZoned()
    val dayOffset = (z.toLocalDate().toEpochDay() - dayStart.toEpochDay()) * 24
    return dayOffset + z.hour + ceil(z.minute / 6.0) / 10.0
}

fun fmtNum(x: Double): String = String.format(Locale.US, "%.1f", x)

val WEEK_FMT: DateTimeFormatter = DateTimeFormatter.ofPattern("M/d/yy")

object Timesheet {
    val DAY_NAMES = listOf("MON", "TUE", "WED", "THUR", "FRI", "SAT", "SUN")
    private val BASE_ROWS = listOf(4, 13, 22, 42, 51, 81, 90) // day header row of each block
    private const val ROWS_PER_DAY = 6

    fun buildWeek(
        weekStart: LocalDate, entries: List<Entry>, defaultCat: String, breaks: Map<LocalDate, Int>,
    ): List<SheetDay> =
        (0 until 7).map { i ->
            val date = weekStart.plusDays(i.toLong())
            val dayEntries = entries.filter { it.start.toLocalDate() == date }.sortedBy { it.start }
            val rows = linkedMapOf<String, SheetRow>()
            var start: Double? = null
            var stop: Double? = null
            for (e in dayEntries) {
                val s = decimalTime(e.start, date)
                val t = decimalTime(e.end, date)
                val hrs = round1((t - s).coerceAtLeast(0.0))
                val row = rows.getOrPut(e.label) { SheetRow(e.label) }
                val cat = e.category ?: defaultCat
                if (hrs > 0) row.hours[cat] = round1((row.hours[cat] ?: 0.0) + hrs)
                start = minOf(start ?: s, s)
                stop = maxOf(stop ?: t, t)
            }
            applyBreak(rows.values.toList(), breaks[date] ?: 0)
            // The form has 6 lines per day; fold any extra sites into the last line.
            var list = rows.values.toList()
            if (list.size > ROWS_PER_DAY) {
                val merged = SheetRow(list.drop(ROWS_PER_DAY - 1).joinToString(" / ") { it.name })
                list.drop(ROWS_PER_DAY - 1).forEach { r ->
                    r.hours.forEach { (k, v) -> merged.hours[k] = round1((merged.hours[k] ?: 0.0) + v) }
                }
                list = list.take(ROWS_PER_DAY - 1) + merged
            }
            val notes = dayEntries.map { it.note }.filter { it.isNotBlank() }.distinct().joinToString("; ")
            SheetDay(date, list, start, stop, notes)
        }

    /**
     * Your break happened while you were at a site, so the location data counted it as work.
     * Move it out of the work hours and into the BREAK column, taking it from the line with the
     * most hours first. The day's total stays the same, matching how the paper form is filled in.
     */
    private fun applyBreak(rows: List<SheetRow>, minutes: Int) {
        var left = round1(minutes / 60.0)
        if (left <= 0) return
        for (row in rows.sortedByDescending { it.total }) {
            while (left > 0) {
                val (cat, h) = row.hours.filterKeys { it != Categories.BREAK }.maxByOrNull { it.value } ?: break
                if (h <= 0) break
                val take = minOf(h, left)
                row.hours[cat] = round1(h - take)
                if (row.hours[cat] == 0.0) row.hours.remove(cat)
                row.hours[Categories.BREAK] = round1((row.hours[Categories.BREAK] ?: 0.0) + take)
                left = round1(left - take)
            }
            if (left <= 0) break
        }
    }

    fun included(dayIndex: Int, fri: Boolean, weekend: Boolean) = when (dayIndex) {
        4 -> fri
        5, 6 -> weekend
        else -> true
    }

    // ------------------------------------------------------------ Excel

    private sealed interface Cell
    private class Str(val text: String) : Cell
    private class Num(val value: Double) : Cell
    private class Formula(val f: String, val cached: Double) : Cell

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    fun writeXlsx(
        ctx: Context, name: String, weekStart: LocalDate, days: List<SheetDay>, fri: Boolean, weekend: Boolean,
    ): File {
        val cells = HashMap<String, Cell>()
        cells["H1"] = Str(name)
        cells["S1"] = Str(weekStart.format(WEEK_FMT))
        cells["P65"] = Str(name)

        val hiddenRows = HashSet<Int>()
        days.forEachIndexed { i, day ->
            val b = BASE_ROWS[i]
            if (!included(i, fri, weekend)) {
                hiddenRows.addAll(b..b + 8)
                return@forEachIndexed
            }
            if (day.rows.isEmpty()) return@forEachIndexed
            day.start?.let { cells["B$b"] = Num(it) }
            day.stop?.let { cells["C$b"] = Num(it) }
            cells["D$b"] = Formula("SUM(E${b + 1}:V${b + ROWS_PER_DAY})", day.total)
            // Monday's first line is labelled "PTO?" on the form, so it's used last.
            val lineRows = if (i == 0) (b + 2..b + 6).toList() + (b + 1) else (b + 1..b + 6).toList()
            day.rows.forEachIndexed { j, row ->
                val r = lineRows[j]
                cells["A$r"] = Str(row.name)
                row.hours.forEach { (col, h) -> cells["$col$r"] = Num(h) }
                cells["W$r"] = Formula("SUM(E$r:V$r)", row.total)
            }
            if (day.notes.isNotBlank()) cells["B${b + 7}"] = Str(day.notes)
            cells["W${b + 7}"] = Formula("SUM(W${b + 1}:W${b + 6})", day.total)
        }
        val weekendPageEmpty = !weekend
        if (weekendPageEmpty) hiddenRows.addAll(78..98)

        val cellRe = Regex(
            """<c r="([A-Z]+[0-9]+)"((?: [a-zA-Z:]+="[^"]*")*)\s*(?:/>|>(?:(?!</c>).)*</c>)""",
            RegexOption.DOT_MATCHES_ALL,
        )
        val styleRe = Regex(""" s="(\d+)"""")
        val rowRe = Regex("""<row r="(\d+)"""")

        val files = LinkedHashMap<String, ByteArray>()
        ZipInputStream(ctx.assets.open("timesheet_template.xlsx")).use { zin ->
            while (true) {
                val entry = zin.nextEntry ?: break
                val buf = ByteArrayOutputStream()
                zin.copyTo(buf)
                files[entry.name] = buf.toByteArray()
            }
        }
        var sheet = String(files.getValue("xl/worksheets/sheet1.xml"), Charsets.UTF_8)
        sheet = cellRe.replace(sheet) { m ->
            val ref = m.groupValues[1]
            val v = cells[ref] ?: return@replace m.value
            val st = styleRe.find(m.groupValues[2])?.let { " s=\"${it.groupValues[1]}\"" } ?: ""
            when (v) {
                is Str -> "<c r=\"$ref\"$st t=\"inlineStr\"><is><t xml:space=\"preserve\">${esc(v.text)}</t></is></c>"
                is Num -> "<c r=\"$ref\"$st><v>${fmtNum(v.value)}</v></c>"
                is Formula -> "<c r=\"$ref\"$st><f>${v.f}</f><v>${fmtNum(v.cached)}</v></c>"
            }
        }
        sheet = rowRe.replace(sheet) { m ->
            if (m.groupValues[1].toInt() in hiddenRows) "${m.value} hidden=\"1\"" else m.value
        }
        if (weekendPageEmpty) {
            sheet = sheet.replace(
                """<rowBreaks count="2" manualBreakCount="2"><brk id="38" max="16383" man="1" /><brk id="77" max="16383" man="1" /></rowBreaks>""",
                """<rowBreaks count="1" manualBreakCount="1"><brk id="38" max="16383" man="1" /></rowBreaks>""",
            )
        }
        files["xl/worksheets/sheet1.xml"] = sheet.toByteArray(Charsets.UTF_8)

        val dir = File(ctx.cacheDir, "exports").apply { mkdirs() }
        val file = File(dir, "${fileBase(name, weekStart)}.xlsx")
        ZipOutputStream(file.outputStream()).use { zout ->
            files.forEach { (n, bytes) ->
                zout.putNextEntry(ZipEntry(n))
                zout.write(bytes)
                zout.closeEntry()
            }
        }
        return file
    }

    fun fileBase(name: String, weekStart: LocalDate): String {
        val safe = name.replace(Regex("[^A-Za-z0-9]+"), "_").trim('_').ifBlank { "Timesheet" }
        return "Timesheet_${safe}_$weekStart"
    }

    fun shareXlsx(ctx: Context, file: File) {
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", file)
        val send = Intent(Intent.ACTION_SEND)
            .setType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
            .putExtra(Intent.EXTRA_STREAM, uri)
            .putExtra(Intent.EXTRA_SUBJECT, file.nameWithoutExtension.replace('_', ' '))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(Intent.createChooser(send, "Send timesheet"))
    }

    // ------------------------------------------------------------ Print / PDF

    fun html(name: String, weekStart: LocalDate, days: List<SheetDay>, fri: Boolean, weekend: Boolean): String {
        val cats = Categories.all
        val sb = StringBuilder()
        sb.append(
            """<!doctype html><html><head><meta charset="utf-8"><style>
            @page { size: letter landscape; margin: 0.3in; }
            body { font-family: Arial, Helvetica, sans-serif; font-size: 8px; color: #000; margin: 0; }
            .top { display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 4px; }
            .top b { font-size: 10px; } .top span { font-size: 11px; border-bottom: 1px solid #000; padding: 0 30px 1px 6px; }
            table { border-collapse: collapse; table-layout: fixed; width: 100%; margin-bottom: 10px; page-break-inside: avoid; }
            td, th { border: 1px solid #000; height: 13px; padding: 0 2px; overflow: hidden; white-space: nowrap; text-align: center; }
            th.cat { height: 78px; vertical-align: bottom; font-weight: normal; font-size: 7px; }
            th.cat div { writing-mode: vertical-rl; transform: rotate(180deg); white-space: normal; max-height: 76px; margin: 0 auto; }
            td.site { text-align: left; } .day td { font-weight: bold; background: #f2f2f2; }
            td.notes { text-align: left; white-space: normal; }
            .group th { font-size: 8px; }
            .page2 { page-break-before: always; }
            .foot { margin-top: 8px; font-size: 8px; }
            .sig { display: flex; gap: 40px; margin-top: 12px; align-items: flex-end; }
            .line { border-bottom: 1px solid #000; min-width: 180px; display: inline-block; padding: 0 4px; font-size: 10px; }
            </style></head><body>"""
        )
        sb.append("<div class=\"top\"><div><b>NAME:</b> <span>${esc(name)}</span></div>")
        sb.append("<div><b>WEEK STARTING:</b> <span>${weekStart.format(WEEK_FMT)}</span></div></div>")

        fun header() {
            sb.append("<colgroup><col style=\"width:9%\"><col style=\"width:3.6%\"><col style=\"width:3.6%\"><col style=\"width:3.6%\">")
            repeat(cats.size) { sb.append("<col>") }
            sb.append("<col style=\"width:3.6%\"></colgroup>")
            sb.append("<tr><th colspan=\"4\" style=\"border:none\"></th>")
            cats.forEach { sb.append("<th class=\"cat\"><div>${esc(it.name)}</div></th>") }
            sb.append("<th style=\"border:none\"></th></tr>")
            sb.append("<tr class=\"group\"><th>DATE</th><th>START</th><th>STOP</th><th>TOTAL</th>")
            sb.append("<th colspan=\"3\">SHOP</th><th colspan=\"10\">JOB SITE</th><th colspan=\"5\">OTHER</th><th>TOTAL</th></tr>")
        }

        val shown = days.indices.filter { included(it, fri, weekend) }
        var count = 0
        for (i in shown) {
            val day = days[i]
            if (count == 3) sb.append("<div class=\"page2\"></div>")
            sb.append("<table>")
            header()
            sb.append("<tr class=\"day\"><td class=\"site\">${DAY_NAMES[i]} ${day.date.monthValue}/${day.date.dayOfMonth}</td>")
            sb.append("<td>${day.start?.let { fmtNum(it) } ?: ""}</td><td>${day.stop?.let { fmtNum(it) } ?: ""}</td>")
            sb.append("<td>${if (day.rows.isEmpty()) "" else fmtNum(day.total)}</td>")
            repeat(cats.size) { sb.append("<td></td>") }
            sb.append("<td></td></tr>")
            for (j in 0 until ROWS_PER_DAY) {
                val row = day.rows.getOrNull(j)
                sb.append("<tr><td class=\"site\" colspan=\"4\">${esc(row?.name ?: "")}</td>")
                cats.forEach { c -> sb.append("<td>${row?.hours?.get(c.col)?.let { fmtNum(it) } ?: ""}</td>") }
                sb.append("<td>${row?.let { fmtNum(it.total) } ?: ""}</td></tr>")
            }
            sb.append("<tr><td class=\"notes\" colspan=\"18\">NOTES: ${esc(day.notes)}</td>")
            sb.append("<td colspan=\"4\" style=\"text-align:right\">TOTAL FOR DAY</td>")
            sb.append("<td>${if (day.rows.isEmpty()) "" else fmtNum(day.total)}</td></tr>")
            sb.append("</table>")
            count++
        }
        val weekTotal = round1(shown.sumOf { days[it].total })
        sb.append("<div class=\"foot\"><b>WEEK TOTAL: ${fmtNum(weekTotal)} hrs</b></div>")
        sb.append(
            "<div class=\"sig\"><div>RECEIVED WEEKLY TOOL BOX TALK <span class=\"line\"></span> INITIAL HERE</div>" +
                "<div>THE ABOVE INFORMATION IS TRUE AND ACCURATE <span class=\"line\">${esc(name)}</span></div>" +
                "<div><span class=\"line\"></span> SIGN HERE</div></div>"
        )
        sb.append("</body></html>")
        return sb.toString()
    }

    private var printView: WebView? = null

    /** Opens Android's print dialog, which can also save as PDF. Needs an Activity context. */
    fun print(ctx: Context, html: String, jobName: String) {
        val wv = WebView(ctx)
        wv.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String?) {
                val pm = ctx.getSystemService(Context.PRINT_SERVICE) as PrintManager
                pm.print(
                    jobName,
                    view.createPrintDocumentAdapter(jobName),
                    PrintAttributes.Builder()
                        .setMediaSize(PrintAttributes.MediaSize.NA_LETTER.asLandscape())
                        .build(),
                )
            }
        }
        wv.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
        printView = wv // keep alive until printing starts
    }
}
