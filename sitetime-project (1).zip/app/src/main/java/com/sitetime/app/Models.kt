package com.sitetime.app

import android.location.Location

const val UNNAMED = "Unnamed stop"

data class Site(
    val id: Long,
    val name: String,
    val lat: Double,
    val lng: Double,
    val radius: Double,
    val ignored: Boolean,
    val category: String? = null,
)

data class Entry(
    val id: Long,
    val siteId: Long?,
    val label: String,
    val lat: Double?,
    val lng: Double?,
    val start: Long,
    val end: Long,
    val ongoing: Boolean,
    val note: String,
    val category: String? = null,
    val breakMin: Int = 0,
)

/** A drive detected between two work places. */
data class Drive(
    val id: Long,
    val start: Long,
    val end: Long,
    val from: String,
    val to: String,
    val status: Int,
    val entryId: Long?,
) {
    companion object {
        const val PENDING = 0
        const val LOGGED = 1
        const val SKIPPED = 2
    }
}

fun distanceM(lat1: Double, lng1: Double, lat2: Double, lng2: Double): Float {
    val out = FloatArray(1)
    Location.distanceBetween(lat1, lng1, lat2, lng2, out)
    return out[0]
}
