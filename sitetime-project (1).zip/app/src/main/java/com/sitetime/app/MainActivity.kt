@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.sitetime.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.LifecycleResumeEffect
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.TemporalAdjusters

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { AppTheme { App() } }
    }
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val ctx = LocalContext.current
    val scheme = when {
        Build.VERSION.SDK_INT >= 31 && dark -> dynamicDarkColorScheme(ctx)
        Build.VERSION.SDK_INT >= 31 -> dynamicLightColorScheme(ctx)
        dark -> darkColorScheme()
        else -> lightColorScheme()
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

@Composable
fun App() {
    val ctx = LocalContext.current
    var needName by remember { mutableStateOf(Prefs.name(ctx).isBlank()) }
    if (needName) NameDialog { needName = false }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val tabs = listOf("Timesheet", "Sites", "Settings")
    val icons = listOf(Icons.Default.DateRange, Icons.Default.Place, Icons.Default.Settings)
    Scaffold(
        topBar = { TopAppBar(title = { Text("Site Time") }) },
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { i, t ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Icon(icons[i], contentDescription = null) },
                        label = { Text(t) },
                    )
                }
            }
        },
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> TimesheetScreen()
                1 -> SitesScreen()
                else -> SettingsScreen()
            }
        }
    }
}

/** Shown once on first launch. It can't be dismissed without a name. */
@Composable
fun NameDialog(onDone: () -> Unit) {
    val ctx = LocalContext.current
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = { },
        title = { Text("Welcome to Site Time") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Enter your name as it should appear on your timesheets. You can change it later in Settings.")
                OutlinedTextField(
                    value = name, onValueChange = { name = it }, label = { Text("Your name") },
                    singleLine = true, modifier = Modifier.fillMaxWidth(),
                )
            }
        },
        confirmButton = {
            TextButton(enabled = name.isNotBlank(), onClick = {
                Prefs.setName(ctx, name)
                onDone()
            }) { Text("Continue") }
        },
    )
}

@Composable
fun CategoryPicker(title: String, selected: String?, onSelect: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Column {
        Text(title, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Box {
            OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) {
                Text(Categories.labelOf(selected), maxLines = 1)
            }
            DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                Categories.all.forEach { c ->
                    DropdownMenuItem(text = { Text(c.label) }, onClick = { onSelect(c.col); open = false })
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Timesheet

@Composable
fun TimesheetScreen() {
    val ctx = LocalContext.current
    val db = remember { Db.get(ctx) }
    val version by Db.changes.collectAsState()
    val thisWeek = remember { LocalDate.now().with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY)) }
    var weekStart by remember { mutableStateOf(thisWeek) }
    val zone = ZoneId.systemDefault()
    val from = weekStart.atStartOfDay(zone).toInstant().toEpochMilli()
    val to = weekStart.plusDays(7).atStartOfDay(zone).toInstant().toEpochMilli()
    val entries = remember(version, from) { db.entriesBetween(from, to) }
    val breaks = remember(version, from) { db.breaksBetween(weekStart, weekStart.plusDays(7)) }
    var breakDay by remember { mutableStateOf<LocalDate?>(null) }
    val byDay = entries.groupBy { it.start.toLocalDate() }.toSortedMap()
    var editing by remember { mutableStateOf<Entry?>(null) }
    var adding by remember { mutableStateOf(false) }
    var exporting by remember { mutableStateOf(false) }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        item { TrackingCard() }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { weekStart = weekStart.minusWeeks(1) }) {
                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, "Previous week")
                }
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        if (weekStart == thisWeek) "This week" else "Week of ${weekStart.format(DAY_FMT)}",
                        style = MaterialTheme.typography.titleMedium,
                    )
                    Text(
                        "Total ${fmtDur(entries.sumOf { it.end - it.start })}",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
                IconButton(onClick = { weekStart = weekStart.plusWeeks(1) }) {
                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, "Next week")
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { adding = true }) {
                    Icon(Icons.Default.Add, null)
                    Spacer(Modifier.width(6.dp))
                    Text("Add entry")
                }
                Button(onClick = { exporting = true }) {
                    Icon(Icons.Default.Share, null)
                    Spacer(Modifier.width(6.dp))
                    Text("Timesheet")
                }
            }
        }
        if (entries.isEmpty()) {
            item {
                Text(
                    "Nothing logged this week. Once tracking is on, any place you stay " +
                        "${Prefs.minStayMin(ctx)}+ minutes shows up here automatically.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        for ((date, list) in byDay) {
            item(key = "day-$date") {
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        date.format(DAY_FMT), Modifier.weight(1f),
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.primary,
                    )
                    val mins = breaks[date] ?: 0
                    TextButton(onClick = { breakDay = date }) {
                        Text(if (mins > 0) "Break $mins min" else "Add break")
                    }
                    Text(
                        fmtDur(list.sumOf { it.end - it.start }),
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.primary,
                    )
                }
            }
            items(list, key = { it.id }) { e -> EntryRow(e) { editing = e } }
        }
    }

    editing?.let { e -> EntryDialog(e, e.start.toLocalDate()) { editing = null } }
    if (exporting) ExportDialog(weekStart, entries, breaks) { exporting = false }
    breakDay?.let { d -> BreakDialog(d, breaks[d] ?: 0) { breakDay = null } }
    if (adding) {
        val today = LocalDate.now()
        val default = if (!today.isBefore(weekStart) && today.isBefore(weekStart.plusDays(7))) today else weekStart
        EntryDialog(null, default) { adding = false }
    }
}

@Composable
fun EntryRow(e: Entry, onClick: () -> Unit) {
    val unnamed = e.siteId == null && e.lat != null && e.label == UNNAMED
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        colors = if (unnamed) CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer)
        else CardDefaults.cardColors(),
    ) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(e.label, style = MaterialTheme.typography.titleMedium)
                val times = "${fmtTime(e.start)} – ${if (e.ongoing) "now" else fmtTime(e.end)}"
                Text(
                    when {
                        unnamed -> "$times · tap to name"
                        e.note.isNotBlank() -> "$times · ${e.note}"
                        else -> times
                    },
                    style = MaterialTheme.typography.bodyMedium,
                )
                Text(
                    Categories.labelOf(e.category),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Text(fmtDur(e.end - e.start), style = MaterialTheme.typography.titleMedium)
        }
    }
}

@Composable
fun EntryDialog(entry: Entry?, defaultDate: LocalDate, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val db = remember { Db.get(ctx) }
    val sites = remember { db.sites().filter { !it.ignored } }
    var label by remember { mutableStateOf(entry?.label?.takeIf { it != UNNAMED } ?: "") }
    var siteId by remember { mutableStateOf(entry?.siteId) }
    var date by remember { mutableStateOf((entry?.start?.toLocalDate() ?: defaultDate).toString()) }
    var start by remember { mutableStateOf(entry?.let { fmtHm(it.start) } ?: "08:00") }
    var end by remember { mutableStateOf(entry?.let { fmtHm(it.end) } ?: "16:00") }
    var note by remember { mutableStateOf(entry?.note ?: "") }
    var category by remember { mutableStateOf(entry?.category ?: Prefs.defaultCategory(ctx)) }
    var saveAsSite by remember { mutableStateOf(entry != null && entry.siteId == null && entry.lat != null) }
    var pickOpen by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val canSaveSite = entry?.lat != null && siteId == null

    val save: () -> Unit = save@{
        val d = runCatching { LocalDate.parse(date.trim()) }.getOrNull()
        val st = parseHm(start)
        val en = parseHm(end)
        if (label.isBlank()) { error = "Give the site or job a name."; return@save }
        if (d == null || st == null || en == null) {
            error = "Check the date and times (e.g. 2026-11-10, 7:30, 16:45)."
            return@save
        }

        val zone = ZoneId.systemDefault()
        val startMs = d.atTime(st).atZone(zone).toInstant().toEpochMilli()
        var endDt = d.atTime(en)
        if (!endDt.isAfter(d.atTime(st))) endDt = endDt.plusDays(1) // past midnight
        val endMs = endDt.atZone(zone).toInstant().toEpochMilli()

        var newSiteId = siteId
        val lat = entry?.lat
        val lng = entry?.lng
        if (canSaveSite && saveAsSite && lat != null && lng != null) {
            newSiteId = db.addSite(label.trim(), lat, lng, Prefs.radiusM(ctx).toDouble(), false, category)
        }
        val updated = Entry(
            id = entry?.id ?: 0, siteId = newSiteId, label = label.trim(), lat = lat, lng = lng,
            start = startMs, end = endMs, ongoing = entry?.ongoing ?: false, note = note.trim(),
            category = category, breakMin = 0,
        )
        if (entry == null) db.insertEntry(updated) else db.updateEntry(updated)
        if (newSiteId != null && newSiteId != entry?.siteId) db.site(newSiteId)?.let { db.assignUnnamedNear(it) }
        onDismiss()
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (entry == null) "Add entry" else "Edit entry") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = label, onValueChange = { label = it; siteId = null },
                    label = { Text("Site / job name") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                )
                if (sites.isNotEmpty()) {
                    Box {
                        TextButton(onClick = { pickOpen = true }) { Text("Pick a saved site") }
                        DropdownMenu(expanded = pickOpen, onDismissRequest = { pickOpen = false }) {
                            sites.forEach { s ->
                                DropdownMenuItem(
                                    text = { Text(s.name) },
                                    onClick = {
                                        label = s.name
                                        siteId = s.id
                                        s.category?.let { category = it }
                                        pickOpen = false
                                    },
                                )
                            }
                        }
                    }
                }
                OutlinedTextField(
                    value = date, onValueChange = { date = it },
                    label = { Text("Date (YYYY-MM-DD)") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = start, onValueChange = { start = it }, label = { Text("Start") },
                        singleLine = true, modifier = Modifier.weight(1f),
                    )
                    OutlinedTextField(
                        value = end, onValueChange = { end = it }, label = { Text("End") },
                        singleLine = true, modifier = Modifier.weight(1f),
                    )
                }
                CategoryPicker("Work type", category) { category = it }
                if (entry?.ongoing == true) {
                    Text(
                        "You're still here, so the end time keeps updating until you leave.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
                OutlinedTextField(
                    value = note, onValueChange = { note = it },
                    label = { Text("Note (optional)") }, modifier = Modifier.fillMaxWidth(),
                )
                if (canSaveSite) {
                    Row(
                        Modifier.clickable { saveAsSite = !saveAsSite },
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Checkbox(checked = saveAsSite, onCheckedChange = { saveAsSite = it })
                        Text(
                            "Save as a site, so future stops here are named automatically",
                            style = MaterialTheme.typography.bodyMedium,
                        )
                    }
                }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                if (entry != null) {
                    FlowRow {
                        TextButton(onClick = { db.deleteEntry(entry.id); onDismiss() }) {
                            Text("Delete entry", color = MaterialTheme.colorScheme.error)
                        }
                        val lat = entry.lat
                        val lng = entry.lng
                        if (lat != null && lng != null && entry.siteId == null) {
                            TextButton(onClick = {
                                val id = db.addSite("Ignored place", lat, lng, Prefs.radiusM(ctx).toDouble(), true)
                                db.site(id)?.let { db.assignUnnamedNear(it) }
                                db.deleteEntry(entry.id)
                                onDismiss()
                            }) { Text("Ignore this place") }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = save) { Text("Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
fun TrackingCard() {
    val ctx = LocalContext.current
    var enabled by remember { mutableStateOf(Prefs.trackingEnabled(ctx)) }
    var tick by remember { mutableIntStateOf(0) }
    LifecycleResumeEffect(Unit) {
        tick++
        onPauseOrDispose { }
    }
    val hasLoc = remember(tick) { Perms.hasLocation(ctx) }
    val hasBg = remember(tick) { Perms.hasBackground(ctx) }
    val batteryOk = remember(tick) {
        (ctx.getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(ctx.packageName)
    }

    val turnOn = {
        Prefs.setTrackingEnabled(ctx, true)
        enabled = true
        TrackingService.start(ctx)
    }
    val locLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        tick++
        if (Perms.hasLocation(ctx)) turnOn()
    }
    val bgLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        tick++
        if (!granted) openAppSettings(ctx)
    }

    // Make sure the service is running whenever the app is opened with tracking on.
    LaunchedEffect(Unit) {
        if (enabled && Perms.hasLocation(ctx)) {
            try {
                TrackingService.start(ctx)
            } catch (_: Exception) {
            }
        }
    }

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Automatic tracking", style = MaterialTheme.typography.titleMedium)
                    Text(
                        if (enabled) "On. Stops of ${Prefs.minStayMin(ctx)}+ min are logged." else "Off",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
                Switch(checked = enabled, onCheckedChange = { on ->
                    if (on) {
                        if (hasLoc) turnOn() else locLauncher.launch(Perms.foregroundRequest())
                    } else {
                        Prefs.setTrackingEnabled(ctx, false)
                        enabled = false
                        TrackingService.stop(ctx)
                    }
                })
            }
            if (enabled && !hasLoc) {
                Warning("Location permission is off, so nothing is being tracked.", "Allow") {
                    locLauncher.launch(Perms.foregroundRequest())
                }
            }
            if (enabled && hasLoc && !hasBg) {
                Warning("Set location to \"Allow all the time\" so tracking restarts after a reboot.", "Fix") {
                    bgLauncher.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
                }
            }
            if (enabled && !batteryOk) {
                Warning("Battery optimization can pause tracking when the screen is off.", "Fix") {
                    requestBatteryExemption(ctx)
                }
            }
        }
    }
}

@Composable
fun Warning(text: String, action: String, onClick: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
            text, Modifier.weight(1f),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.error,
        )
        TextButton(onClick = onClick) { Text(action) }
    }
}

fun openAppSettings(ctx: Context) {
    ctx.startActivity(
        Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))
    )
}

@SuppressLint("BatteryLife")
fun requestBatteryExemption(ctx: Context) {
    try {
        ctx.startActivity(
            Intent(
                android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                Uri.parse("package:${ctx.packageName}"),
            )
        )
    } catch (_: Exception) {
        ctx.startActivity(Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
    }
}

// ---------------------------------------------------------------- Sites

@SuppressLint("MissingPermission")
fun currentLocation(ctx: Context, cb: (Pair<Double, Double>?) -> Unit) {
    try {
        LocationServices.getFusedLocationProviderClient(ctx)
            .getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, CancellationTokenSource().token)
            .addOnSuccessListener { loc -> cb(loc?.let { it.latitude to it.longitude }) }
            .addOnFailureListener { cb(null) }
    } catch (_: SecurityException) {
        cb(null)
    }
}

@Composable
fun SitesScreen() {
    val ctx = LocalContext.current
    val db = remember { Db.get(ctx) }
    val version by Db.changes.collectAsState()
    val sites = remember(version) { db.sites() }
    var editing by remember { mutableStateOf<Site?>(null) }
    var newLoc by remember { mutableStateOf<Pair<Double, Double>?>(null) }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        item {
            Text(
                "You don't need to set up job sites in advance: new places show up on your timesheet as " +
                    "\"Unnamed stop\" and you name them there. Saved sites name future stops automatically. " +
                    "Mark places like home as ignored so they never appear.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        item {
            Button(
                enabled = !busy,
                onClick = {
                    msg = null
                    if (!Perms.hasLocation(ctx)) {
                        msg = "Turn on tracking first so the app has location access."
                    } else {
                        busy = true
                        currentLocation(ctx) { loc ->
                            busy = false
                            if (loc == null) msg = "Couldn't get a location fix. Try again in a moment."
                            else newLoc = loc
                        }
                    }
                },
            ) { Text(if (busy) "Getting location…" else "Add my current location") }
        }
        msg?.let { m -> item { Text(m, color = MaterialTheme.colorScheme.error) } }
        if (sites.isEmpty()) {
            item { Text("No saved sites yet.", style = MaterialTheme.typography.bodyMedium) }
        }
        items(sites, key = { it.id }) { s ->
            Card(onClick = { editing = s }, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                    Text(s.name, style = MaterialTheme.typography.titleMedium)
                    Text(
                        if (s.ignored) "Ignored · ${s.radius.toInt()} m radius"
                        else "${Categories.labelOf(s.category)} · ${s.radius.toInt()} m radius",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
            }
        }
    }

    editing?.let { s -> SiteDialog(s, s.lat, s.lng) { editing = null } }
    newLoc?.let { (lat, lng) -> SiteDialog(null, lat, lng) { newLoc = null } }
}

@Composable
fun SiteDialog(site: Site?, lat: Double, lng: Double, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val db = remember { Db.get(ctx) }
    var name by remember { mutableStateOf(site?.name ?: "") }
    var radius by remember { mutableStateOf((site?.radius?.toInt() ?: Prefs.radiusM(ctx)).toString()) }
    var ignored by remember { mutableStateOf(site?.ignored ?: false) }
    var category by remember { mutableStateOf(site?.category ?: Prefs.defaultCategory(ctx)) }
    var error by remember { mutableStateOf<String?>(null) }

    val confirm: () -> Unit = confirm@{
        val r = radius.trim().toDoubleOrNull()
        val n = name.trim().ifBlank { if (ignored) "Ignored place" else "" }
        if (n.isBlank()) {
            error = "Give the site a name."
            return@confirm
        }
        if (r == null || r < 30 || r > 3000) {
            error = "Radius should be between 30 and 3000 m."
            return@confirm
        }
        val id = if (site == null) {
            db.addSite(n, lat, lng, r, ignored, category)
        } else {
            db.updateSite(site.copy(name = n, radius = r, ignored = ignored, category = category))
            site.id
        }
        db.site(id)?.let { db.assignUnnamedNear(it) }
        onDismiss()
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (site == null) "New site" else "Edit site") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = name, onValueChange = { name = it }, label = { Text("Name") },
                    singleLine = true, modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = radius, onValueChange = { radius = it }, label = { Text("Radius (metres)") },
                    singleLine = true, modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                )
                if (!ignored) CategoryPicker("Usual work type here", category) { category = it }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Ignore this place")
                        Text(
                            "For home and other non-work spots. Stops here won't be logged.",
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                    Switch(checked = ignored, onCheckedChange = { ignored = it })
                }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                if (site != null) {
                    TextButton(onClick = { db.deleteSite(site.id); onDismiss() }) {
                        Text("Delete site", color = MaterialTheme.colorScheme.error)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = confirm) { Text("Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

// ---------------------------------------------------------------- Settings

@Composable
fun SettingsScreen() {
    val ctx = LocalContext.current
    var minStay by remember { mutableIntStateOf(Prefs.minStayMin(ctx)) }
    var radius by remember { mutableIntStateOf(Prefs.radiusM(ctx)) }
    var interval by remember { mutableIntStateOf(Prefs.intervalMin(ctx)) }
    var highAcc by remember { mutableStateOf(Prefs.highAccuracy(ctx)) }
    var name by remember { mutableStateOf(Prefs.name(ctx)) }
    var defaultCat by remember { mutableStateOf(Prefs.defaultCategory(ctx)) }
    var fri by remember { mutableStateOf(Prefs.includeFriday(ctx)) }
    var weekend by remember { mutableStateOf(Prefs.includeWeekend(ctx)) }
    val restart: () -> Unit = {
        if (Prefs.trackingEnabled(ctx)) {
            try {
                TrackingService.start(ctx)
            } catch (_: Exception) {
            }
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp),
    ) {
        OutlinedTextField(
            value = name,
            onValueChange = {
                name = it
                if (it.isNotBlank()) Prefs.setName(ctx, it)
            },
            label = { Text("Your name (printed on timesheets)") },
            isError = name.isBlank(),
            supportingText = { if (name.isBlank()) Text("Name can't be empty") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        CategoryPicker("Default work type for new places", defaultCat) {
            defaultCat = it
            Prefs.setDefaultCategory(ctx, it)
        }
        Column {
            Text("Days on printed/exported timesheets", style = MaterialTheme.typography.titleSmall)
            SwitchRow("Include Friday", fri) { fri = it; Prefs.setBool(ctx, "incFri", it) }
            SwitchRow("Include Saturday & Sunday", weekend) { weekend = it; Prefs.setBool(ctx, "incWknd", it) }
            Text(
                "These are the defaults. You can still change them each time you print or export.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        HorizontalDivider()
        ChoiceRow("Log a stop after staying", listOf(5, 10, 15, 20, 30), minStay, { "$it min" }) {
            minStay = it; Prefs.setInt(ctx, "minStay", it)
        }
        ChoiceRow("Same-place radius", listOf(75, 100, 150, 250, 400), radius, { "$it m" }) {
            radius = it; Prefs.setInt(ctx, "radius", it)
        }
        ChoiceRow("Check location every", listOf(1, 2, 3, 5), interval, { "$it min" }) {
            interval = it; Prefs.setInt(ctx, "interval", it); restart()
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("High-accuracy GPS", style = MaterialTheme.typography.titleSmall)
                Text("More precise arrive/leave times, uses more battery.", style = MaterialTheme.typography.bodySmall)
            }
            Switch(checked = highAcc, onCheckedChange = {
                highAcc = it; Prefs.setBool(ctx, "highAcc", it); restart()
            })
        }
        HorizontalDivider()
        OutlinedButton(onClick = { exportCsv(ctx, Db.get(ctx).allEntries(), "timesheet-all.csv") }) {
            Text("Export all entries (CSV)")
        }
        Text(
            "How it works: while tracking is on, the app checks your location every few minutes. " +
                "When you stay within the radius for the set time, it logs a stop from when you arrived " +
                "until you leave. Times can be off by about one check interval, so tap any entry to adjust it. " +
                "Everything stays on your phone.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
fun ChoiceRow(title: String, options: List<Int>, selected: Int, label: (Int) -> String, onSelect: (Int) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(title, style = MaterialTheme.typography.titleSmall)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            options.forEach { o ->
                FilterChip(selected = o == selected, onClick = { onSelect(o) }, label = { Text(label(o)) })
            }
        }
    }
}

@Composable
fun SwitchRow(text: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(text, Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

/** Choose which days to include, then print/save PDF or share the filled-in Excel form. */
@Composable
fun ExportDialog(weekStart: LocalDate, entries: List<Entry>, breaks: Map<LocalDate, Int>, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val name = Prefs.name(ctx)
    var fri by remember { mutableStateOf(Prefs.includeFriday(ctx)) }
    var weekend by remember { mutableStateOf(Prefs.includeWeekend(ctx)) }
    var error by remember { mutableStateOf<String?>(null) }
    val days = remember(entries, breaks) {
        Timesheet.buildWeek(weekStart, entries, Prefs.defaultCategory(ctx), breaks)
    }
    val missingBreaks = days.indices.count { i ->
        Timesheet.included(i, fri, weekend) && days[i].rows.isNotEmpty() && (breaks[days[i].date] ?: 0) == 0
    }
    val unnamed = entries.count { it.siteId == null && it.label == UNNAMED }
    val friHours = days[4].total
    val weekendHours = round1(days[5].total + days[6].total)

    fun saveChoice() {
        Prefs.setBool(ctx, "incFri", fri)
        Prefs.setBool(ctx, "incWknd", weekend)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Timesheet") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("$name · Week starting ${weekStart.format(WEEK_FMT)}", style = MaterialTheme.typography.bodyMedium)
                SwitchRow(
                    "Include Friday" + if (friHours > 0) " (${fmtNum(friHours)} h logged)" else "",
                    fri,
                ) { fri = it }
                SwitchRow(
                    "Include Sat & Sun" + if (weekendHours > 0) " (${fmtNum(weekendHours)} h logged)" else "",
                    weekend,
                ) { weekend = it }
                val shownTotal = round1(days.indices.filter { Timesheet.included(it, fri, weekend) }.sumOf { days[it].total })
                Text("Total on this timesheet: ${fmtNum(shownTotal)} h", style = MaterialTheme.typography.titleSmall)
                if (unnamed > 0) {
                    Text(
                        "$unnamed unnamed stop${if (unnamed > 1) "s" else ""} this week will print as \"$UNNAMED\".",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                    )
                }
                if (missingBreaks > 0) {
                    Text(
                        "$missingBreaks day${if (missingBreaks > 1) "s have" else " has"} no break entered.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                    )
                }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            Row {
                TextButton(onClick = {
                    saveChoice()
                    try {
                        val file = Timesheet.writeXlsx(ctx, name, weekStart, days, fri, weekend)
                        Timesheet.shareXlsx(ctx, file)
                        onDismiss()
                    } catch (e: Exception) {
                        error = "Couldn't create the Excel file: ${e.message}"
                    }
                }) { Text("Excel") }
                TextButton(onClick = {
                    saveChoice()
                    Timesheet.print(
                        ctx,
                        Timesheet.html(name, weekStart, days, fri, weekend),
                        Timesheet.fileBase(name, weekStart),
                    )
                    onDismiss()
                }) { Text("Print / PDF") }
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

/** Set the break/lunch length for one day. */
@Composable
fun BreakDialog(date: LocalDate, current: Int, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var text by remember { mutableStateOf(if (current > 0) current.toString() else "") }
    var error by remember { mutableStateOf<String?>(null) }
    val save: (Int) -> Unit = { mins ->
        Db.get(ctx).setBreak(date, mins)
        onDismiss()
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Break on ${date.format(DAY_FMT)}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(0, 15, 30, 45, 48, 60).forEach { m ->
                        FilterChip(
                            selected = text == m.toString() || (m == 0 && text.isBlank()),
                            onClick = { text = if (m == 0) "" else m.toString() },
                            label = { Text(if (m == 0) "None" else "$m min") },
                        )
                    }
                }
                OutlinedTextField(
                    value = text, onValueChange = { text = it },
                    label = { Text("Minutes") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                )
                Text(
                    "Moved out of that day's site hours and into the BREAK column.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(onClick = confirm@{
                val m = if (text.isBlank()) 0 else text.trim().toIntOrNull()
                if (m == null || m < 0 || m > 600) {
                    error = "Enter minutes between 0 and 600."
                    return@confirm
                }
                save(m)
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}
