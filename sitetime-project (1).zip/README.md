# Site Time

Android app that logs a timesheet from where you go. While tracking is on, it
checks location every few minutes; any place you stay for the set time (default
10 min, within 150 m) becomes a timesheet entry from arrival to departure.

- New places appear as "Unnamed stop". Tap to name them; tick "Save as a site"
  so future visits are named automatically.
- "Ignore this place" (e.g. home) stops it from ever being logged.
- Edit or add entries by hand, browse by week, export CSV.
- All data stays on the phone (SQLite). No accounts, no servers.

Build: Kotlin + Jetpack Compose, AGP 8.7, Gradle 8.9, minSdk 26 (Android 8+).
`gradle assembleDebug` produces app/build/outputs/apk/debug/app-debug.apk.
The included app/debug.keystore keeps the signature stable so updates install
over the previous version without losing data.

## Timesheet export
The Timesheet button fills in the company form (app/src/main/assets/timesheet_template.xlsx,
built from MENS_TIMESHEET.xlsx with Sat/Sun added on page 3) with your name, the week-starting
Monday, start/stop times in decimal hours using the form's 6-minute rounding, hours per work-type
column, breaks, and notes. Friday and Sat/Sun can be included or left off each time. "Print / PDF"
opens Android's print dialog, which can also save a PDF.
